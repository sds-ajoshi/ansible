# OpenShift Compliance Playbook

Ansible playbook system for auditing and remediating OpenShift 4.20 cluster compliance against CIS Level 2 Benchmark and Hitachi CPSSR v4.0 standards.

## Overview

This playbook automates the detection of compliance gaps and applies remediation actions to achieve 95% compliance targets:
- **CIS Level 2**: 79/83 controls (95.2%)
- **CPSSR v4.0**: 29/31 requirements (93.5%)

The playbook provides two modes of operation:
- **Audit Mode**: Identifies compliance gaps without making changes
- **Remediation Mode**: Automatically applies security controls to achieve compliance

## Features

- **Comprehensive Auditing**: Checks network policies, seccomp profiles, RBAC configurations, service accounts, and namespace protection
- **Automated Remediation**: Applies fixes to non-compliant resources
- **Detailed Reporting**: Generates timestamped compliance reports in Markdown format
- **Idempotent Operations**: Safe to run multiple times without unintended changes
- **Error Handling**: Continues processing on individual resource failures
- **Namespace Filtering**: Automatically excludes system namespaces from audits and remediations

## Prerequisites

### Required Tools

- **Ansible Core**: 2.15 or higher
- **Python**: 3.8 or higher
- **OpenShift CLI** (`oc`): For cluster authentication
- **jq**: Command-line JSON processor

### Required Ansible Collections

Install the Kubernetes core collection:

```bash
ansible-galaxy collection install kubernetes.core
```

### Required Python Packages

Install Python dependencies:

```bash
pip install kubernetes PyYAML jinja2
```

### OpenShift Cluster Access

- Active OpenShift 4.20 cluster
- Cluster-admin or equivalent permissions
- Active `oc login` session before running the playbook

## Installation

1. Clone this repository:
   ```bash
   git clone <repository-url>
   cd openshift-compliance-playbook
   ```

2. Install Ansible collections:
   ```bash
   ansible-galaxy collection install kubernetes.core
   ```

3. Install Python dependencies:
   ```bash
   pip install kubernetes PyYAML jinja2
   ```

4. Copy example configuration files:
   ```bash
   cp inventory/hosts.yml.example inventory/hosts.yml
   cp group_vars/all.yml.example group_vars/all.yml
   ```

5. Log in to your OpenShift cluster:
   ```bash
   oc login https://api.cluster.example.com:6443
   ```

## Configuration

### Inventory Configuration

The `inventory/hosts.yml` file configures the connection to your OpenShift cluster. By default, the playbook uses your current `oc login` session.

**Basic configuration** (uses current kubeconfig):
```yaml
all:
  hosts:
    localhost:
      ansible_connection: local
      ansible_python_interpreter: "{{ ansible_playbook_python }}"
```

**Advanced configuration** (custom kubeconfig or context):
```yaml
all:
  hosts:
    localhost:
      ansible_connection: local
      ansible_python_interpreter: "{{ ansible_playbook_python }}"
  
  vars:
    # Specify a custom kubeconfig path
    k8s_kubeconfig: "/path/to/kubeconfig"
    
    # Specify a custom context
    k8s_context: "default/api-cluster-example-com:6443/admin"
    
    # Validate SSL certificates (default: true)
    k8s_validate_certs: true
```

See `inventory/hosts.yml.example` for all available options.

### Global Variables Configuration

The `group_vars/all.yml` file contains global configuration settings. Key settings include:

**Namespace Filtering**:
```yaml
namespace_filter:
  exclude_prefixes:
    - "openshift-"
    - "kube-"
  exclude_names:
    - "default"
```

**Compliance Targets**:
```yaml
compliance_targets:
  cis_level_2:
    total_controls: 83
    target_controls: 79
    target_percentage: 95.2
  cpssr_v4:
    total_requirements: 31
    target_requirements: 29
    target_percentage: 93.5
```

**Network Policy Configuration**:
```yaml
network_policy:
  name: "default-deny-ingress"
  policy_types:
    - "Ingress"
```

See `group_vars/all.yml.example` for all available configuration options.

## Usage

### Audit Mode (Default)

Run compliance audit without making changes:

```bash
ansible-playbook playbook.yml
```

Or explicitly specify audit mode:

```bash
ansible-playbook playbook.yml -e playbook_mode=audit
```

**What happens in audit mode:**
1. Validates cluster connectivity and permissions
2. Audits network policies in all user namespaces
3. Audits seccomp profiles on all pods
4. Audits RBAC configurations (cluster-admin bindings and wildcard permissions)
5. Audits service account token mounting
6. Audits default namespace protection
7. Generates compliance reports in `reports/` directory

### Remediation Mode

Run compliance audit and apply remediations:

```bash
ansible-playbook playbook.yml -e playbook_mode=remediate
```

**What happens in remediation mode:**
1. Runs pre-remediation audit (same as audit mode)
2. Applies remediation actions:
   - Creates default-deny NetworkPolicies in non-compliant namespaces
   - Patches default service accounts to disable token mounting
   - Creates ResourceQuota in default namespace
3. Runs post-remediation audit to validate changes
4. Generates comparison reports showing before/after compliance status

### Specifying Inventory

If your inventory file is in a non-standard location:

```bash
ansible-playbook -i /path/to/inventory/hosts.yml playbook.yml
```

### Verbose Output

For detailed execution information:

```bash
ansible-playbook playbook.yml -v    # Verbose
ansible-playbook playbook.yml -vv   # More verbose
ansible-playbook playbook.yml -vvv  # Very verbose (debug)
```

## Compliance Controls

The playbook audits and remediates the following compliance controls:

### Network Security
- **Control**: Default-deny NetworkPolicies in all user namespaces
- **Remediation**: Creates NetworkPolicy named `default-deny-ingress` with empty `podSelector` and `policyTypes: [Ingress]`
- **Satisfies**: CIS 5.3.2, CPSSR 4.02.L

### Pod Security
- **Control**: Seccomp profile compliance (RuntimeDefault)
- **Remediation**: Audit only (manual remediation required)
- **Satisfies**: CIS 5.7.2, CPSSR 4.02.D

### RBAC Hardening
- **Control**: Audit cluster-admin bindings and wildcard permissions
- **Remediation**: Audit only (manual review required)
- **Satisfies**: CIS 5.1.1, 5.1.3, CPSSR 1.07

### Service Account Security
- **Control**: Disable automatic token mounting on default service accounts
- **Remediation**: Patches service accounts to set `automountServiceAccountToken: false`
- **Satisfies**: CIS 5.1.5, 5.1.6

### Namespace Protection
- **Control**: Protect default namespace with ResourceQuota
- **Remediation**: Creates ResourceQuota named `prevent-deployments` with `pods: "0"`, `services: "0"`
- **Satisfies**: CIS 5.7.4

## Reports

Reports are generated in the `reports/` directory with timestamps:

### Compliance Summary Report
**Filename**: `compliance-summary-report-<timestamp>.md`

Contains:
- Overall compliance status
- Compliance percentages for each category
- Counts of compliant and non-compliant resources
- Progress toward CIS Level 2 and CPSSR v4.0 targets
- Detailed findings for each compliance area

### RBAC Audit Report
**Filename**: `rbac-audit-report-<timestamp>.md`

Contains:
- All cluster-admin ClusterRoleBindings with subject details
- Custom ClusterRoles with wildcard permissions
- Recommendations for RBAC hardening

### Report Format

Reports are generated in Markdown format for easy viewing and version control. Example:

```markdown
# OpenShift Compliance Summary Report

**Generated**: 2025-11-20T10:30:00Z
**Mode**: remediate

## Overall Compliance

- **CIS Level 2**: 75/83 controls (90.4%)
- **CPSSR v4.0**: 28/31 requirements (90.3%)

## Network Policies

- **Total Namespaces**: 25
- **Compliant**: 20
- **Non-Compliant**: 5
- **Remediated**: 5
- **Failed**: 0
```

## Project Structure

```
openshift-compliance-playbook/
├── playbook.yml                    # Main playbook entry point
├── inventory/
│   ├── hosts.yml                   # OpenShift cluster connection (gitignored)
│   └── hosts.yml.example           # Example inventory configuration
├── group_vars/
│   ├── all.yml                     # Global variables (gitignored)
│   └── all.yml.example             # Example configuration
├── roles/
│   ├── preflight/                  # Validation and prerequisites
│   ├── audit_network_policies/     # Network policy compliance audit
│   ├── audit_seccomp/              # Seccomp profile compliance audit
│   ├── audit_rbac/                 # RBAC compliance audit
│   ├── audit_service_accounts/     # Service account token audit
│   ├── audit_default_namespace/    # Default namespace protection audit
│   ├── remediate_network_policies/ # Network policy remediation
│   ├── remediate_service_accounts/ # Service account remediation
│   ├── remediate_default_namespace/# Default namespace remediation
│   ├── reporting/                  # Report generation and summary
│   └── common/                     # Common utilities and filters
├── templates/
│   ├── network_policy_default_deny.yml.j2
│   ├── resource_quota_default_ns.yml.j2
│   ├── rbac_audit_report.md.j2
│   └── compliance_summary_report.md.j2
├── tests/
│   └── test_namespace_filter.py   # Unit tests
└── reports/                        # Generated audit reports (gitignored)
```

## Idempotency

The playbook is designed to be idempotent and safe to run multiple times:

- **Resource State Checking**: Before applying changes, checks if resources already exist in the desired state
- **Skip Compliant Resources**: Resources already in the desired state are skipped
- **Consistent Final State**: Multiple executions produce the same final state
- **Categorized Results**: Reports categorize resources as: changed, already compliant, or failed

Example output:
```
Network Policy Remediation Results:
- Changed: 3 namespaces
- Already Compliant: 20 namespaces
- Failed: 0 namespaces
```

## Error Handling

The playbook implements robust error handling:

### Critical Errors (Fail Immediately)
- Cluster connectivity failures
- Insufficient permissions
- Missing required tools or collections
- Invalid configuration

### Resource-Level Errors (Log and Continue)
- Individual NetworkPolicy creation failures
- Individual service account patch failures
- Individual resource query failures

**Error Reporting**:
- All errors are logged with details
- Failed resources are collected for reporting
- Error messages include actionable information

Example:
```
FAILED: NetworkPolicy creation in namespace 'app-prod'
Error: API server returned 403: Forbidden
Action: Verify cluster-admin permissions
```

## Troubleshooting

### Preflight Validation Failures

**Error**: "Unable to connect to OpenShift cluster API"
- **Solution**: Ensure you are logged in with `oc login` and have network connectivity

**Error**: "Insufficient permissions"
- **Solution**: Ensure your user has cluster-admin or equivalent permissions

**Error**: "Required tool not found: jq"
- **Solution**: Install jq: `sudo apt-get install jq` (Ubuntu/Debian) or `brew install jq` (macOS)

### Remediation Failures

**Error**: "CNI does not support NetworkPolicies"
- **Solution**: Verify your cluster's CNI plugin supports NetworkPolicies (OpenShift SDN or OVN-Kubernetes)

**Error**: "Failed to patch service account"
- **Solution**: Check namespace exists and service account is not protected by admission controllers

### Report Generation Issues

**Error**: "Permission denied: reports/"
- **Solution**: Ensure the reports directory is writable: `chmod 755 reports/`

## Development and Testing

### Running Unit Tests

```bash
# Run namespace filter tests
python -m pytest tests/test_namespace_filter.py -v
```

### Running with Molecule (if configured)

```bash
# Run full test suite
molecule test

# Run specific scenario
molecule test -s default
```

### Linting

```bash
# Lint Ansible playbooks
ansible-lint playbook.yml

# Lint Python code
pylint roles/common/filter_plugins/namespace_filter.py
```

## Security Considerations

- **Credentials**: Never commit `inventory/hosts.yml` or `group_vars/all.yml` with credentials
- **Permissions**: Requires cluster-admin permissions - use with caution
- **Audit First**: Always run in audit mode first to review changes before remediation
- **Backup**: Consider backing up critical resources before running remediation
- **Testing**: Test in non-production environments first

## Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

[Add your license here]

## Support

For issues and questions:
- Review this documentation
- Check the generated reports for detailed findings
- Contact your cluster administrator
- Open an issue in the project repository

## Acknowledgments

This playbook implements compliance controls based on:
- CIS Kubernetes Benchmark v1.8
- Hitachi CPSSR v4.0
- OpenShift 4.20 security best practices
