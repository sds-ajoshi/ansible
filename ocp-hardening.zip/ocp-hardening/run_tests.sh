#!/bin/bash
# Simple test runner script

echo "Running namespace filter tests..."
python3 tests/test_namespace_filter.py

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ All tests passed successfully!"
    exit 0
else
    echo ""
    echo "❌ Some tests failed!"
    exit 1
fi
