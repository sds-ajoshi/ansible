# Task 16 Implementation: Mode Selection and Execution Flow

## Overview

This document describes the implementation of mode selection and execution flow in the main playbook (`playbook.yml`).

## Requirements Addressed

- **Requirement 10.1**: Audit mode executes without remediation
- **Requirement 10.2**: Remediation mode executes audit then remediation
- **Requirement 10.3**: Default mode is audit-only
- **Requirement 10.4**: Generate pre and post remediation reports
- **Requirement 10.5**: Display comparison summary

## Implementation Details

### Mode Selection (Requirement 10.3)

The playbook supports two modes via the `mode` variable:
- `audit` (default): Performs compliance audit only
- `remediate`: Performs audit, remediation, and post-remediation validation

```yaml
vars:
  playbook_mode: "{{ mode | default('audit') }}"
```

### Execution Flow

#### Audit Mode (Requirements 10.1, 10.3)

When invoked without specifying a mode or with `mode=audit`:

```bash
ansible-playbook playbook.yml
# or
ansible-playbook playbook.yml -e "mode=audit"
```

**Execution sequence:**
1. Preflight validation
2. Initial audit phase (all audit roles)
3. Final report generation (audit-only report)

**No remediation actions are performed.**

#### Remediation Mode (Requirements 10.2, 10.4, 10.5)

When invoked with `mode=remediate`:

```bash
ansible-playbook playbook.yml -e "mode=remediate"
```

**Execution sequence:**
1. Preflight validation
2. Initial audit phase (all audit roles)
3. **Pre-remediation report generation** (Requirement 10.4)
4. Store pre-remediation results for comparison
5. Apply remediation actions:
   - Network policy remediation
   - Service account remediation
   - Default namespace remediation
6. Post-remediation audit (re-run audit roles)
7. **Display comparison summary** (Requirement 10.5)
8. **Post-remediation report generation** (Requirement 10.4)

### Comparison Summary (Requirement 10.5)

The playbook displays a detailed comparison showing:
- Network Policies: before/after non-compliant counts, remediated count, failed count
- Service Accounts: before/after non-compliant counts, remediated count, failed count
- Default Namespace: before/after compliance status, remediation status

Example output:
```
==========================================
=== REMEDIATION COMPARISON SUMMARY ===
==========================================

Network Policies:
  Before: 5 non-compliant namespaces
  After:  0 non-compliant namespaces
  Remediated: 5 namespaces
  Failed: 0 namespaces

Service Accounts:
  Before: 7 non-compliant accounts
  After:  0 non-compliant accounts
  Remediated: 7 accounts
  Failed: 0 accounts

Default Namespace:
  Before: Non-compliant
  After:  Compliant
  Remediated: Yes

==========================================
```

### Report Generation (Requirement 10.4)

The playbook generates reports with appropriate phase indicators:

- **Audit mode**: Single report with phase `audit-only`
- **Remediation mode**: 
  - Pre-remediation report with phase `pre-remediation`
  - Post-remediation report with phase `post-remediation`

The `report_phase` variable is passed to the reporting role to distinguish between report types.

## Verification

### Syntax Check
```bash
ansible-playbook playbook.yml --syntax-check
```

### List Tasks
```bash
ansible-playbook playbook.yml --list-tasks
```

### Dry Run (Check Mode)
```bash
# Audit mode
ansible-playbook playbook.yml --check

# Remediation mode
ansible-playbook playbook.yml -e "mode=remediate" --check
```

## Conditional Execution

All remediation-related tasks use the condition:
```yaml
when: playbook_mode == 'remediate'
```

This ensures:
- Audit mode skips all remediation blocks
- Remediation mode executes all blocks
- Default behavior is audit-only (safe by default)

## Implementation Status

✅ All requirements (10.1-10.5) have been implemented and verified.
