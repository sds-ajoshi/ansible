# Implementation Plan

- [x] 1. Set up project structure and configuration files








  - Create directory structure for roles, templates, inventory, and reports
  - Create `playbook.yml` main entry point with mode selection logic
  - Create `inventory/hosts.yml` for OpenShift cluster connection configuration
  - Create `group_vars/all.yml` with global variables (namespace filters, report directory, etc.)
  - Set up `.gitignore` to exclude generated reports and sensitive inventory data
  - _Requirements: 10.1, 10.2, 10.3_

- [x] 2. Implement preflight validation role





  - Create `roles/preflight/tasks/main.yml` with validation tasks
  - Add task to verify OpenShift cluster API connectivity using `k8s_cluster_info` module
  - Add task to check user permissions (cluster-admin or equivalent)
  - Add task to validate required command-line tools (`oc`, `jq`) are available
  - Add task to validate `kubernetes.core` Ansible collection is installed
  - Set `preflight_passed` fact on success, fail with clear error message on failure
  - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5_

- [ ]* 2.1 Write property test for preflight validation
  - **Property 26: Preflight validation checks all requirements**
  - **Validates: Requirements 11.1, 11.2, 11.3**

- [ ]* 2.2 Write property test for preflight failure messaging
  - **Property 27: Preflight failure provides clear error message**
  - **Validates: Requirements 11.4**

- [ ]* 2.3 Write unit tests for preflight role
  - Test with valid cluster connection
  - Test with invalid credentials
  - Test with missing command-line tools
  - Test with insufficient permissions
  - _Requirements: 11.1, 11.2, 11.3, 11.4_

- [x] 3. Implement namespace filtering logic





  - Create `roles/common/filter_plugins/namespace_filter.py` custom filter
  - Implement logic to exclude namespaces starting with `openshift-`, `kube-`, and namespace named `default`
  - Return list of user namespace names
  - _Requirements: 1.1, 1.5_

- [ ]* 3.1 Write property test for namespace filtering
  - **Property 1: Namespace filtering excludes system namespaces**
  - **Validates: Requirements 1.1, 1.5**

- [ ]* 3.2 Write unit tests for namespace filtering
  - Test with cluster containing only system namespaces
  - Test with cluster containing only user namespaces
  - Test with mixed namespace types
  - Test with edge case namespace names
  - _Requirements: 1.1, 1.5_
-

- [x] 4. Implement network policy audit role




  - Create `roles/audit_network_policies/tasks/main.yml`
  - Add task to retrieve all namespaces using `k8s_info` module
  - Add task to filter to user namespaces using custom filter
  - Add task to check each user namespace for NetworkPolicy named `default-deny-ingress`
  - Collect non-compliant namespaces into `network_policy_gaps` fact
  - Collect compliant namespaces into `network_policy_compliant` fact
  - Set `network_policy_total` fact with total count
  - Add timestamp to audit results
  - _Requirements: 1.1, 1.2, 1.3, 1.5_

- [ ]* 4.1 Write property test for network policy audit detection
  - **Property 2: Network policy audit identifies all non-compliant namespaces**
  - **Validates: Requirements 1.2, 1.3**

- [ ]* 4.2 Write unit tests for network policy audit
  - Test with compliant namespaces
  - Test with non-compliant namespaces
  - Test with mixed compliance states
  - _Requirements: 1.1, 1.2, 1.3_

- [x] 5. Implement seccomp profile audit role




  - Create `roles/audit_seccomp/tasks/main.yml`
  - Add task to retrieve all pods from user namespaces using `k8s_info` module
  - Add task to parse pod specifications for `securityContext.seccompProfile.type`
  - Check both pod-level and container-level security contexts
  - Collect non-compliant pods into `seccomp_gaps` fact with namespace, pod name, and profile status
  - Set `seccomp_compliant_count` and `seccomp_total_count` facts
  - Add timestamp to audit results
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [ ]* 5.1 Write property test for seccomp audit coverage
  - **Property 8: Seccomp audit retrieves all pods from user namespaces**
  - **Validates: Requirements 3.1**

- [ ]* 5.2 Write property test for seccomp security context checking
  - **Property 9: Seccomp audit checks both pod and container security contexts**
  - **Validates: Requirements 3.2, 3.3**

- [ ]* 5.3 Write unit tests for seccomp audit
  - Test with pods having RuntimeDefault at pod level
  - Test with pods having RuntimeDefault at container level
  - Test with pods missing seccomp profiles
  - Test with mixed configurations
  - _Requirements: 3.1, 3.2, 3.3_

- [x] 6. Implement RBAC audit role




  - Create `roles/audit_rbac/tasks/main.yml`
  - Add task to retrieve all ClusterRoleBindings using `k8s_info` module
  - Filter for bindings with `roleRef.name == "cluster-admin"`
  - Collect bindings into `rbac_cluster_admin_bindings` fact with subject details
  - Add task to retrieve all ClusterRoles using `k8s_info` module
  - Filter to custom roles (exclude `cluster-admin`, `admin`, `edit`)
  - Parse rules to find wildcard characters (`*`) in apiGroups, resources, or verbs
  - Collect wildcard roles into `rbac_wildcard_roles` fact
  - Set `rbac_audit_timestamp` fact
  - _Requirements: 4.1, 4.2, 4.3_

- [ ]* 6.1 Write property test for RBAC cluster-admin binding retrieval
  - **Property 11: RBAC audit retrieves all cluster-admin bindings**
  - **Validates: Requirements 4.1**

- [ ]* 6.2 Write property test for RBAC wildcard detection
  - **Property 12: RBAC audit identifies wildcard permissions in custom roles**
  - **Validates: Requirements 4.2, 4.3**

- [ ]* 6.3 Write unit tests for RBAC audit
  - Test with various ClusterRoleBinding configurations
  - Test with custom roles containing wildcards
  - Test with system roles (should be excluded)
  - _Requirements: 4.1, 4.2, 4.3_

- [x] 7. Implement service account audit role




  - Create `roles/audit_service_accounts/tasks/main.yml`
  - Add task to retrieve all namespaces and filter to user namespaces
  - Add task to query for service account named `default` in each user namespace
  - Check `automountServiceAccountToken` field value
  - Mark as non-compliant if field is not set to `false` (either `true` or `null`)
  - Collect non-compliant service accounts into `sa_token_gaps` fact
  - Collect compliant namespaces into `sa_token_compliant` fact
  - Set `sa_token_total` fact
  - Add timestamp to audit results
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [ ]* 7.1 Write property test for service account audit retrieval
  - **Property 14: Service account audit retrieves default accounts from user namespaces**
  - **Validates: Requirements 5.1**

- [ ]* 7.2 Write property test for service account compliance determination
  - **Property 15: Service account compliance determination**
  - **Validates: Requirements 5.2, 5.3**

- [ ]* 7.3 Write unit tests for service account audit
  - Test with `automountServiceAccountToken: false`
  - Test with `automountServiceAccountToken: true`
  - Test with `automountServiceAccountToken` not set (null)
  - _Requirements: 5.1, 5.2, 5.3_

- [x] 8. Implement default namespace audit role




  - Create `roles/audit_default_namespace/tasks/main.yml`
  - Add task to query for ResourceQuota named `prevent-deployments` in `default` namespace
  - Validate hard quota values: `pods: "0"`, `services: "0"`
  - Set `default_ns_compliant` fact (boolean)
  - Set `default_ns_quota_exists` fact (boolean)
  - Set `default_ns_quota_correct` fact (boolean)
  - Add timestamp to audit results
  - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [ ]* 8.1 Write unit tests for default namespace audit
  - Test with ResourceQuota present and correct
  - Test with ResourceQuota present but incorrect
  - Test with ResourceQuota missing
  - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [x] 9. Checkpoint - Ensure all audit roles are working



  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Create Jinja2 templates for Kubernetes resources




  - Create `templates/network_policy_default_deny.yml.j2` with empty podSelector and Ingress policyType
  - Create `templates/resource_quota_default_ns.yml.j2` with hard quotas for pods, services, replicationcontrollers, and resourcequotas
  - Create `templates/rbac_audit_report.md.j2` for RBAC findings
  - Create `templates/compliance_summary_report.md.j2` for overall compliance summary
  - _Requirements: 2.2, 8.2, 4.4, 4.5, 9.1, 9.2, 9.3, 9.4, 9.5_

- [ ]* 10.1 Write property test for NetworkPolicy template configuration
  - **Property 5: Created network policies have correct configuration**
  - **Validates: Requirements 2.2**

- [ ]* 10.2 Write unit tests for templates
  - Test NetworkPolicy template rendering
  - Test ResourceQuota template rendering
  - Test report template rendering with various data
  - _Requirements: 2.2, 8.2_


- [x] 11. Implement network policy remediation role




  - Create `roles/remediate_network_policies/tasks/main.yml`
  - Add task to verify CNI support by querying `network.config.openshift.io/cluster` resource
  - Add task to loop through `network_policy_gaps` fact
  - For each namespace, apply NetworkPolicy using `k8s` module with `state: present`
  - Use `network_policy_default_deny.yml.j2` template
  - Add task to validate successful creation by querying the created resource
  - Implement error handling: log errors and continue processing remaining namespaces
  - Collect remediation results into `network_policy_remediated` and `network_policy_failed` facts
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

- [ ]* 11.1 Write property test for network policy remediation coverage
  - **Property 4: Network policy remediation creates policies in all non-compliant namespaces**
  - **Validates: Requirements 2.1, 2.3**

- [ ]* 11.2 Write property test for network policy remediation validation
  - **Property 6: Network policy remediation validates successful creation**
  - **Validates: Requirements 2.4**

- [ ]* 11.3 Write property test for network policy error handling
  - **Property 7: Network policy remediation continues on error**
  - **Validates: Requirements 2.5**

- [ ]* 11.4 Write unit tests for network policy remediation
  - Test creation in empty namespace
  - Test when policy already exists (idempotency)
  - Test error handling when API call fails



  - _Requirements: 2.1, 2.2, 2.4, 2.5_

- [x] 12. Implement service account remediation role


  - Create `roles/remediate_service_accounts/tasks/main.yml`
  - Add task to loop through `sa_token_gaps` fact
  - For each service account, patch using `k8s` module
  - Set `automountServiceAccountToken: false` in patch
  - Use `merge` patch strategy for idempotent updates
  - Add task to validate successful patch by querying updated resource
  - Implement error handling: log errors and continue processing remaining service accounts
  - Collect remediation results into `sa_token_remediated` and `sa_token_failed` facts
  - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [ ]* 12.1 Write property test for service account remediation coverage
  - **Property 17: Service account remediation patches all non-compliant accounts**
  - **Validates: Requirements 6.1, 6.2**

- [ ]* 12.2 Write property test for service account remediation validation
  - **Property 18: Service account remediation validates successful patches**
  - **Validates: Requirements 6.3**

- [ ]* 12.3 Write property test for service account error handling
  - **Property 19: Service account remediation continues on error**
  - **Validates: Requirements 6.4**

- [ ]* 12.4 Write unit tests for service account remediation
  - Test patching service account
  - Test when already patched (idempotency)
  - Test error handling when API call fails
  - _Requirements: 6.1, 6.2, 6.3, 6.4_
-

- [x] 13. Implement default namespace remediation role




  - Create `roles/remediate_default_namespace/tasks/main.yml`
  - Add task to check if ResourceQuota already exists with correct configuration
  - If not compliant, apply ResourceQuota using `k8s` module with `state: present`
  - Use `resource_quota_default_ns.yml.j2` template
  - Add task to validate successful creation
  - Set `default_ns_remediated` fact (boolean)
  - Set `default_ns_remediation_error` fact if remediation failed
  - _Requirements: 8.1, 8.2, 8.3, 8.4_

- [ ]* 13.1 Write unit tests for default namespace remediation
  - Test creation when ResourceQuota missing
  - Test when ResourceQuota already exists (idempotency)
  - Test error handling
  - _Requirements: 8.1, 8.2, 8.3, 8.4_
-

- [x] 14. Checkpoint - Ensure all remediation roles are working




  - Ensure all tests pass, ask the user if questions arise.

- [x] 15. Implement reporting role





  - Create `roles/reporting/tasks/main.yml`
  - Add task to create reports directory if it doesn't exist
  - Add task to generate RBAC audit report using `rbac_audit_report.md.j2` template
  - Add task to generate compliance summary report using `compliance_summary_report.md.j2` template
  - Add task to calculate compliance percentages for each category
  - Add task to calculate progress toward CIS Level 2 (79/83 controls) and CPSSR v4.0 (29/31 requirements)
  - Add task to display summary to console using `debug` module
  - Include timestamp in report filenames
  - _Requirements: 4.4, 4.5, 9.1, 9.2, 9.3, 9.4, 9.5_

- [ ]* 15.1 Write property test for compliance summary report completeness
  - **Property 20: Compliance summary report contains all required sections**
  - **Validates: Requirements 9.1, 9.2, 9.3, 9.4, 9.5**

- [ ]* 15.2 Write property test for RBAC report naming and content
  - **Property 13: RBAC report has correct filename and content**
  - **Validates: Requirements 4.4, 4.5**

- [ ]* 15.3 Write unit tests for reporting role
  - Test report generation with various compliance states
  - Test report file naming and timestamps
  - Test compliance percentage calculations
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 16. Implement mode selection and execution flow in main playbook





  - Update `playbook.yml` to support `playbook_mode` variable (audit/remediate)
  - Set default mode to `audit` if not specified
  - Implement conditional execution of remediation roles based on mode
  - Implement pre-remediation audit execution
  - Implement post-remediation audit execution for validation
  - Implement comparison summary for remediation mode
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [ ]* 16.1 Write property test for audit mode behavior
  - **Property 21: Audit mode executes without remediation**
  - **Validates: Requirements 10.1**

- [ ]* 16.2 Write property test for remediation mode behavior
  - **Property 22: Remediation mode executes both audit and remediation**
  - **Validates: Requirements 10.2**

- [ ]* 16.3 Write property test for default mode
  - **Property 23: Default mode is audit-only**
  - **Validates: Requirements 10.3**

- [ ]* 16.4 Write property test for remediation mode reporting
  - **Property 24: Remediation mode generates pre and post reports**
  - **Validates: Requirements 10.4**

- [ ]* 16.5 Write property test for remediation comparison summary
  - **Property 25: Remediation mode displays comparison summary**
  - **Validates: Requirements 10.5**

- [ ]* 16.6 Write unit tests for mode selection
  - Test audit-only mode execution
  - Test remediation mode execution
  - Test default mode behavior
  - _Requirements: 10.1, 10.2, 10.3_
-

- [x] 17. Implement idempotency checks in remediation roles




  - Update network policy remediation to check if policy already exists with correct configuration
  - Update service account remediation to check if already patched
  - Update default namespace remediation to check if ResourceQuota already exists
  - Ensure all remediation actions use Ansible modules with idempotent operations
  - Update reporting to categorize resources as: changed, already compliant, or failed
  - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5_

- [ ]* 17.1 Write property test for remediation state checking
  - **Property 29: Remediation checks existing resource state**
  - **Validates: Requirements 12.1**

- [ ]* 17.2 Write property test for idempotent skipping
  - **Property 30: Idempotent remediation skips compliant resources**
  - **Validates: Requirements 12.2**

- [ ]* 17.3 Write property test for idempotency
  - **Property 31: Multiple executions produce identical final state**
  - **Validates: Requirements 12.3**

- [ ]* 17.4 Write property test for resource categorization
  - **Property 32: Execution report categorizes all resources**
  - **Validates: Requirements 12.5**

- [ ]* 17.5 Write unit tests for idempotency
  - Test re-running remediation on already-compliant cluster
  - Test that multiple executions produce same final state
  - _Requirements: 12.1, 12.2, 12.3_

- [x] 18. Create documentation and usage examples







  - Create `README.md` with overview, prerequisites, and usage instructions
  - Document how to run in audit mode: `ansible-playbook playbook.yml`
  - Document how to run in remediation mode: `ansible-playbook playbook.yml -e playbook_mode=remediate`
  - Document inventory configuration requirements
  - Document required Ansible collections and Python dependencies
  - Create example inventory file with comments
  - Create example group_vars file with comments
  - Document report output locations and formats
  - _Requirements: All_

- [ ] 19. Final checkpoint - End-to-end integration testing
  - Ensure all tests pass, ask the user if questions arise.
