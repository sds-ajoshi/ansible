# Design Document

## Overview

This design specifies an Ansible playbook system for auditing and remediating OpenShift 4.20 cluster compliance against CIS Level 2 Benchmark and Hitachi CPSSR v4.0 standards. The solution consists of a main playbook that orchestrates audit and remediation tasks, role-based task organization, Jinja2 templates for Kubernetes resources, and comprehensive reporting capabilities. The playbook leverages the `kubernetes.core` Ansible collection for OpenShift API interactions and implements idempotent operations to ensure safe repeated execution.

## Architecture

### Component Structure

```
openshift-compliance-playbook/
├── playbook.yml                    # Main playbook entry point
├── inventory/
│   └── hosts.yml                   # OpenShift cluster connection details
├── group_vars/
│   └── all.yml                     # Global variables and configuration
├── roles/
│   ├── preflight/                  # Validation and prerequisites
│   ├── audit_network_policies/     # Network policy compliance audit
│   ├── audit_seccomp/              # Seccomp profile compliance audit
│   ├── audit_rbac/                 # RBAC compliance audit
│   ├── audit_service_accounts/     # Service account token audit
│   ├── audit_default_namespace/    # Default namespace protection audit
│   ├── remediate_network_policies/ # Network policy remediation
│   ├── remediate_service_accounts/ # Service account remediation
│   ├── remediate_default_namespace/# Default namespace remediation
│   └── reporting/                  # Report generation and summary
├── templates/
│   ├── network_policy_default_deny.yml.j2
│   ├── resource_quota_default_ns.yml.j2
│   ├── rbac_audit_report.md.j2
│   └── compliance_summary_report.md.j2
└── reports/                        # Generated audit reports (created at runtime)
```

### Execution Flow

1. **Preflight Validation**: Verify cluster connectivity, permissions, and required tools
2. **Audit Phase**: Execute all audit roles to collect compliance data
3. **Decision Point**: Based on mode (audit/remediate), either stop or continue
4. **Remediation Phase**: Apply fixes to non-compliant resources
5. **Post-Remediation Audit**: Re-run audits to validate remediation effectiveness
6. **Reporting**: Generate comprehensive compliance reports

### Technology Stack

- **Ansible Core**: 2.15+
- **Ansible Collection**: `kubernetes.core` (v2.4.0+)
- **Python Dependencies**: `kubernetes`, `PyYAML`, `jinja2`
- **OpenShift CLI**: `oc` command-line tool
- **Required Tools**: `jq` for JSON processing in validation tasks

## Components and Interfaces

### Main Playbook (playbook.yml)

The main playbook orchestrates execution flow and role invocation:

```yaml
- hosts: localhost
  gather_facts: no
  vars:
    mode: "{{ playbook_mode | default('audit') }}"
    report_dir: "./reports"
    timestamp: "{{ ansible_date_time.iso8601_basic_short }}"
  
  tasks:
    - name: Include preflight validation
      include_role:
        name: preflight
    
    - name: Execute audit phase
      include_role:
        name: "{{ item }}"
      loop:
        - audit_network_policies
        - audit_seccomp
        - audit_rbac
        - audit_service_accounts
        - audit_default_namespace
    
    - name: Execute remediation phase
      when: mode == 'remediate'
      block:
        - name: Apply remediations
          include_role:
            name: "{{ item }}"
          loop:
            - remediate_network_policies
            - remediate_service_accounts
            - remediate_default_namespace
        
        - name: Re-run audits for validation
          include_role:
            name: "{{ item }}"
          loop:
            - audit_network_policies
            - audit_service_accounts
            - audit_default_namespace
    
    - name: Generate compliance reports
      include_role:
        name: reporting
```

### Preflight Role

**Purpose**: Validate environment before execution

**Tasks**:
- Test OpenShift cluster API connectivity using `k8s_cluster_info` module
- Verify current user has sufficient permissions (cluster-admin or equivalent)
- Check for required command-line tools (`oc`, `jq`)
- Validate Ansible collection dependencies

**Interface**:
- Input: None (uses connection configuration from inventory)
- Output: Sets `preflight_passed` fact (boolean)
- Failure Mode: Fails playbook execution with descriptive error message

### Audit Network Policies Role

**Purpose**: Identify user namespaces lacking default-deny ingress policies

**Tasks**:
1. Retrieve all namespaces using `k8s_info` module
2. Filter to user namespaces (exclude `openshift-*`, `kube-*`, `default`)
3. For each user namespace, query for NetworkPolicy named `default-deny-ingress`
4. Collect non-compliant namespaces into `network_policy_gaps` fact

**Interface**:
- Input: None
- Output: 
  - `network_policy_gaps`: List of namespace names without default-deny policies
  - `network_policy_compliant`: List of compliant namespace names
  - `network_policy_total`: Total count of user namespaces

### Audit Seccomp Role

**Purpose**: Identify pods not using RuntimeDefault seccomp profiles

**Tasks**:
1. Retrieve all pods from user namespaces using `k8s_info` module
2. Parse pod specifications to extract seccomp profile settings
3. Check both pod-level and container-level `securityContext.seccompProfile.type`
4. Collect non-compliant pods into `seccomp_gaps` fact

**Interface**:
- Input: None
- Output:
  - `seccomp_gaps`: List of dicts with namespace, pod name, and profile status
  - `seccomp_compliant_count`: Count of compliant pods
  - `seccomp_total_count`: Total pods audited

### Audit RBAC Role

**Purpose**: Identify excessive cluster-admin bindings and wildcard permissions

**Tasks**:
1. Retrieve all ClusterRoleBindings using `k8s_info` module
2. Filter for bindings with `roleRef.name == "cluster-admin"`
3. Retrieve all ClusterRoles using `k8s_info` module
4. Identify custom roles (exclude system roles: `cluster-admin`, `admin`, `edit`)
5. Parse rules to find wildcard characters (`*`) in apiGroups, resources, or verbs
6. Collect findings into structured facts

**Interface**:
- Input: None
- Output:
  - `rbac_cluster_admin_bindings`: List of cluster-admin bindings with subjects
  - `rbac_wildcard_roles`: List of custom roles with wildcard permissions
  - `rbac_audit_timestamp`: ISO 8601 timestamp

### Audit Service Accounts Role

**Purpose**: Identify default service accounts with automatic token mounting enabled

**Tasks**:
1. Retrieve all namespaces and filter to user namespaces
2. For each user namespace, query for service account named `default`
3. Check `automountServiceAccountToken` field value
4. Collect non-compliant service accounts into `sa_token_gaps` fact

**Interface**:
- Input: None
- Output:
  - `sa_token_gaps`: List of dicts with namespace and token mounting status
  - `sa_token_compliant`: List of compliant namespaces
  - `sa_token_total`: Total service accounts audited

### Audit Default Namespace Role

**Purpose**: Verify default namespace has ResourceQuota preventing workload deployment

**Tasks**:
1. Query for ResourceQuota named `prevent-deployments` in `default` namespace
2. Validate hard quota values: `pods: "0"`, `services: "0"`
3. Set compliance status fact

**Interface**:
- Input: None
- Output:
  - `default_ns_compliant`: Boolean indicating compliance status
  - `default_ns_quota_exists`: Boolean indicating if ResourceQuota exists
  - `default_ns_quota_correct`: Boolean indicating if configuration is correct

### Remediate Network Policies Role

**Purpose**: Create default-deny ingress NetworkPolicies in non-compliant namespaces

**Tasks**:
1. Verify CNI support by querying `network.config.openshift.io/cluster` resource
2. For each namespace in `network_policy_gaps`, apply NetworkPolicy from template
3. Use `k8s` module with `state: present` for idempotent creation
4. Validate successful creation by querying the created resource
5. Collect remediation results (success/failure per namespace)

**Interface**:
- Input: `network_policy_gaps` fact from audit role
- Output:
  - `network_policy_remediated`: List of successfully remediated namespaces
  - `network_policy_failed`: List of failed remediations with error messages

### Remediate Service Accounts Role

**Purpose**: Disable automatic token mounting on default service accounts

**Tasks**:
1. For each service account in `sa_token_gaps`, patch using `k8s` module
2. Set `automountServiceAccountToken: false` in patch
3. Use `merge` patch strategy for idempotent updates
4. Validate successful patch by querying updated resource
5. Collect remediation results

**Interface**:
- Input: `sa_token_gaps` fact from audit role
- Output:
  - `sa_token_remediated`: List of successfully remediated service accounts
  - `sa_token_failed`: List of failed remediations with error messages

### Remediate Default Namespace Role

**Purpose**: Create ResourceQuota in default namespace to prevent workload deployment

**Tasks**:
1. Check if ResourceQuota already exists with correct configuration
2. If not compliant, apply ResourceQuota from template using `k8s` module
3. Use `state: present` for idempotent creation
4. Validate successful creation

**Interface**:
- Input: `default_ns_compliant` fact from audit role
- Output:
  - `default_ns_remediated`: Boolean indicating successful remediation
  - `default_ns_remediation_error`: Error message if remediation failed

### Reporting Role

**Purpose**: Generate comprehensive compliance reports

**Tasks**:
1. Create reports directory if it doesn't exist
2. Generate RBAC audit report using `rbac_audit_report.md.j2` template
3. Generate compliance summary report using `compliance_summary_report.md.j2` template
4. Calculate compliance percentages for each category
5. Display summary to console using `debug` module

**Interface**:
- Input: All audit and remediation facts from previous roles
- Output:
  - `reports/rbac-audit-report-<timestamp>.md`
  - `reports/compliance-summary-report-<timestamp>.md`
  - Console output with compliance summary

## Data Models

### Namespace Filter Criteria

```yaml
user_namespace_filter:
  exclude_prefixes:
    - "openshift-"
    - "kube-"
  exclude_names:
    - "default"
```

### Network Policy Gap Entry

```yaml
network_policy_gap:
  namespace: "my-app-namespace"
  has_default_deny: false
  audit_timestamp: "2025-11-20T10:30:00Z"
```

### Seccomp Gap Entry

```yaml
seccomp_gap:
  namespace: "my-app-namespace"
  pod_name: "my-pod-12345"
  pod_seccomp: "Unconfined"
  container_seccomp: "RuntimeDefault"
  compliant: false
```

### RBAC Cluster Admin Binding

```yaml
rbac_cluster_admin_binding:
  name: "custom-admin-binding"
  subjects:
    - kind: "User"
      name: "admin@example.com"
    - kind: "Group"
      name: "cluster-admins"
  roleRef:
    name: "cluster-admin"
    kind: "ClusterRole"
```

### RBAC Wildcard Role

```yaml
rbac_wildcard_role:
  name: "overly-permissive-role"
  wildcards:
    - field: "apiGroups"
      rule_index: 0
    - field: "resources"
      rule_index: 1
    - field: "verbs"
      rule_index: 0
  rules: [...]  # Full rules array for reference
```

### Service Account Token Gap Entry

```yaml
sa_token_gap:
  namespace: "my-app-namespace"
  service_account: "default"
  automount_token: true  # or null if not set
  compliant: false
```

### Remediation Result

```yaml
remediation_result:
  resource_type: "NetworkPolicy"
  namespace: "my-app-namespace"
  resource_name: "default-deny-ingress"
  action: "created"  # or "already_exists", "failed"
  error_message: null  # or error string if failed
```

### Compliance Summary

```yaml
compliance_summary:
  timestamp: "2025-11-20T10:30:00Z"
  mode: "remediate"
  network_policies:
    total_namespaces: 25
    compliant: 20
    non_compliant: 5
    remediated: 5
    failed: 0
  service_accounts:
    total: 25
    compliant: 18
    non_compliant: 7
    remediated: 7
    failed: 0
  default_namespace:
    compliant: true
    remediated: false
  rbac:
    cluster_admin_bindings: 3
    wildcard_roles: 2
  seccomp:
    total_pods: 150
    compliant: 120
    non_compliant: 30
  cis_progress:
    target: 79
    current: 75
    percentage: 94.9
  cpssr_progress:
    target: 29
    current: 28
    percentage: 96.6
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Namespace filtering excludes system namespaces

*For any* set of namespaces in an OpenShift cluster, the namespace filter should exclude all namespaces starting with `openshift-`, `kube-`, and the namespace named `default`, returning only user namespaces.

**Validates: Requirements 1.1, 1.5**

### Property 2: Network policy audit identifies all non-compliant namespaces

*For any* user namespace without a NetworkPolicy named `default-deny-ingress`, the audit should include that namespace in the `network_policy_gaps` fact.

**Validates: Requirements 1.2, 1.3**

### Property 3: Network policy report contains required fields

*For any* generated network policy audit report, the report should contain timestamp, namespace names, and compliance status for each namespace.

**Validates: Requirements 1.4**

### Property 4: Network policy remediation creates policies in all non-compliant namespaces

*For any* set of non-compliant namespaces, the remediation should create a NetworkPolicy named `default-deny-ingress` in each namespace (after CNI verification).

**Validates: Requirements 2.1, 2.3**

### Property 5: Created network policies have correct configuration

*For any* NetworkPolicy created by the remediation, it should have an empty `podSelector` and `policyTypes` containing `Ingress`.

**Validates: Requirements 2.2**

### Property 6: Network policy remediation validates successful creation

*For any* NetworkPolicy created during remediation, the playbook should query the resource to validate successful creation.

**Validates: Requirements 2.4**

### Property 7: Network policy remediation continues on error

*For any* error encountered while creating a NetworkPolicy, the playbook should log the error and continue processing remaining namespaces.

**Validates: Requirements 2.5**

### Property 8: Seccomp audit retrieves all pods from user namespaces

*For any* OpenShift cluster state, the seccomp audit should retrieve all pods from all user namespaces (excluding system namespaces).

**Validates: Requirements 3.1**

### Property 9: Seccomp audit checks both pod and container security contexts

*For any* pod specification, the audit should check `seccompProfile.type` in both the pod-level `securityContext` and each container's `securityContext`.

**Validates: Requirements 3.2, 3.3**

### Property 10: Seccomp report contains required fields

*For any* generated seccomp audit report, the report should include namespace, pod name, and seccomp profile status for each non-compliant pod.

**Validates: Requirements 3.4, 3.5**

### Property 11: RBAC audit retrieves all cluster-admin bindings

*For any* OpenShift cluster, the RBAC audit should retrieve all ClusterRoleBindings where `roleRef.name` equals `cluster-admin`.

**Validates: Requirements 4.1**

### Property 12: RBAC audit identifies wildcard permissions in custom roles

*For any* ClusterRole that is not a system role (`cluster-admin`, `admin`, `edit`), the audit should identify if it contains wildcard characters (`*`) in apiGroups, resources, or verbs.

**Validates: Requirements 4.2, 4.3**

### Property 13: RBAC report has correct filename and content

*For any* RBAC audit execution, the generated report should be named `rbac-audit-report-<timestamp>.md` and contain all cluster-admin bindings with subject details and all custom roles with wildcard permissions.

**Validates: Requirements 4.4, 4.5**

### Property 14: Service account audit retrieves default accounts from user namespaces

*For any* OpenShift cluster, the service account audit should retrieve all service accounts named `default` from user namespaces only.

**Validates: Requirements 5.1**

### Property 15: Service account compliance determination

*For any* default service account where `automountServiceAccountToken` is not set to `false` (either `true` or `null`), the audit should mark it as non-compliant.

**Validates: Requirements 5.2, 5.3**

### Property 16: Service account report contains required fields

*For any* generated service account audit report, the report should include namespace, service account name, and token mounting status.

**Validates: Requirements 5.4, 5.5**

### Property 17: Service account remediation patches all non-compliant accounts

*For any* set of non-compliant default service accounts, the remediation should patch each account to set `automountServiceAccountToken` to `false`.

**Validates: Requirements 6.1, 6.2**

### Property 18: Service account remediation validates successful patches

*For any* service account patched during remediation, the playbook should query the resource to validate the patch was successfully applied.

**Validates: Requirements 6.3**

### Property 19: Service account remediation continues on error

*For any* error encountered while patching a service account, the playbook should log the error and continue processing remaining service accounts.

**Validates: Requirements 6.4**

### Property 20: Compliance summary report contains all required sections

*For any* generated compliance summary report, it should include timestamp, total namespaces audited, compliance percentages, findings for all categories (network policies, seccomp, RBAC, service accounts, default namespace), counts of compliant and non-compliant resources, and progress toward CIS Level 2 and CPSSR v4.0 targets.

**Validates: Requirements 9.1, 9.2, 9.3, 9.4, 9.5**

### Property 21: Audit mode executes without remediation

*For any* playbook execution in audit mode, all audit tasks should execute but no remediation actions should be applied.

**Validates: Requirements 10.1**

### Property 22: Remediation mode executes both audit and remediation

*For any* playbook execution in remediation mode, audit tasks should execute first, followed by remediation actions for non-compliant resources.

**Validates: Requirements 10.2**

### Property 23: Default mode is audit-only

*For any* playbook execution without a specified mode parameter, the playbook should execute in audit-only mode.

**Validates: Requirements 10.3**

### Property 24: Remediation mode generates pre and post reports

*For any* playbook execution in remediation mode, both pre-remediation and post-remediation audit reports should be generated.

**Validates: Requirements 10.4**

### Property 25: Remediation mode displays comparison summary

*For any* playbook execution in remediation mode, the final output should display a summary comparing pre-remediation and post-remediation compliance status.

**Validates: Requirements 10.5**

### Property 26: Preflight validation checks all requirements

*For any* playbook execution, the preflight validation should verify OpenShift cluster API connectivity, user permissions (cluster-admin or equivalent), and availability of required command-line tools.

**Validates: Requirements 11.1, 11.2, 11.3**

### Property 27: Preflight failure provides clear error message

*For any* preflight validation failure (missing permissions or tools), the playbook should fail with a clear error message listing the specific requirements that are not met.

**Validates: Requirements 11.4**

### Property 28: Successful preflight allows execution to proceed

*For any* successful preflight validation, the playbook should proceed to execute audit and remediation tasks.

**Validates: Requirements 11.5**

### Property 29: Remediation checks existing resource state

*For any* remediation action, the playbook should first check if the resource already exists in the desired state before attempting modification.

**Validates: Requirements 12.1**

### Property 30: Idempotent remediation skips compliant resources

*For any* resource already in the desired state, the remediation should skip modification and report the resource as already compliant.

**Validates: Requirements 12.2**

### Property 31: Multiple executions produce identical final state

*For any* cluster state, executing the playbook multiple times in remediation mode should produce the same final state (idempotency).

**Validates: Requirements 12.3**

### Property 32: Execution report categorizes all resources

*For any* playbook execution, the final report should categorize resources into three groups: changed, already compliant, and failed.

**Validates: Requirements 12.5**

## Error Handling

### Error Handling Strategy

The playbook implements a "fail-fast for critical errors, continue for resource-level errors" strategy:

**Critical Errors (Fail Immediately)**:

- Preflight validation failures (no cluster connectivity, insufficient permissions, missing tools)
- Invalid inventory or configuration
- Missing required Ansible collections
- Template rendering failures

**Resource-Level Errors (Log and Continue)**:

- Individual NetworkPolicy creation failures
- Individual service account patch failures
- Individual resource query failures during audit
- Report generation failures for specific sections

### Error Data Structures

All resource-level errors are collected into structured facts for reporting:

```yaml
error_entry:
  resource_type: "NetworkPolicy"
  namespace: "my-app-namespace"
  resource_name: "default-deny-ingress"
  operation: "create"
  error_message: "API server returned 403: Forbidden"
  timestamp: "2025-11-20T10:30:00Z"
```

### Error Reporting

- All errors are logged to Ansible output with appropriate severity levels
- Resource-level errors are included in the compliance summary report
- Failed remediations are tracked separately from successful ones
- Error messages include actionable information (e.g., required permissions, API endpoints)

### Retry Logic

The playbook does not implement automatic retries for the following reasons:

- Ansible modules (`k8s`, `k8s_info`) have built-in retry logic for transient failures
- Idempotent design allows safe manual re-execution
- Cluster-level issues (API unavailability) should be resolved before re-running

### Rollback Strategy

The playbook does not implement automatic rollback because:

- All changes are additive (creating NetworkPolicies, ResourceQuotas, patching service accounts)
- Changes improve security posture and should not be reverted
- Manual rollback can be performed using standard `oc delete` commands if needed
- Idempotent design ensures re-running after manual cleanup is safe

## Testing Strategy

### Dual Testing Approach

This playbook will be validated using both unit testing and property-based testing to ensure comprehensive coverage:

- **Unit tests** verify specific examples, edge cases, and integration points
- **Property-based tests** verify universal properties hold across all inputs
- Together they provide comprehensive coverage: unit tests catch concrete bugs, property tests verify general correctness

### Unit Testing

**Framework**: Molecule (Ansible testing framework)

**Test Scenarios**:

1. **Preflight Validation Tests**:
   - Test with valid cluster connection
   - Test with invalid credentials
   - Test with missing command-line tools
   - Test with insufficient permissions

2. **Namespace Filtering Tests**:
   - Test with cluster containing only system namespaces
   - Test with cluster containing only user namespaces
   - Test with mixed namespace types
   - Test with edge case namespace names (e.g., `openshift`, `kube`, `default-app`)

3. **Audit Role Tests**:
   - Test network policy audit with compliant namespaces
   - Test network policy audit with non-compliant namespaces
   - Test seccomp audit with mixed pod configurations
   - Test RBAC audit with various binding configurations
   - Test service account audit with various token mounting configurations
   - Test default namespace audit with and without ResourceQuota

4. **Remediation Role Tests**:
   - Test network policy creation in empty namespace
   - Test network policy creation when policy already exists
   - Test service account patching
   - Test ResourceQuota creation in default namespace
   - Test error handling when API calls fail

5. **Reporting Tests**:
   - Test report generation with various compliance states
   - Test report file naming and timestamps
   - Test compliance percentage calculations

6. **Mode Selection Tests**:
   - Test audit-only mode execution
   - Test remediation mode execution
   - Test default mode behavior

**Test Environment**: Molecule will use Kind (Kubernetes in Docker) to create ephemeral test clusters

### Property-Based Testing

**Framework**: Hypothesis (Python property-based testing library) with custom Ansible test harness

**Configuration**: Each property-based test will run a minimum of 100 iterations to ensure thorough coverage of the input space.

**Test Tagging**: Each property-based test will be tagged with a comment explicitly referencing the correctness property from this design document using the format: `**Feature: openshift-compliance-playbook, Property {number}: {property_text}**`

**Property Test Implementations**:

1. **Property 1 Test**: Generate random sets of namespaces with various prefixes and verify filtering logic
   - **Feature: openshift-compliance-playbook, Property 1: Namespace filtering excludes system namespaces**

2. **Property 2 Test**: Generate random namespace configurations with and without NetworkPolicies and verify audit detection
   - **Feature: openshift-compliance-playbook, Property 2: Network policy audit identifies all non-compliant namespaces**

3. **Property 3 Test**: Generate audit reports and parse to verify all required fields are present
   - **Feature: openshift-compliance-playbook, Property 3: Network policy report contains required fields**

4. **Property 5 Test**: Generate NetworkPolicies and verify configuration structure
   - **Feature: openshift-compliance-playbook, Property 5: Created network policies have correct configuration**

5. **Property 9 Test**: Generate random pod specifications and verify both security context levels are checked
   - **Feature: openshift-compliance-playbook, Property 9: Seccomp audit checks both pod and container security contexts**

6. **Property 12 Test**: Generate random ClusterRole definitions and verify wildcard detection
   - **Feature: openshift-compliance-playbook, Property 12: RBAC audit identifies wildcard permissions in custom roles**

7. **Property 15 Test**: Generate service accounts with various `automountServiceAccountToken` values and verify compliance determination
   - **Feature: openshift-compliance-playbook, Property 15: Service account compliance determination**

8. **Property 31 Test**: Execute remediation multiple times on the same cluster state and verify final state is identical (idempotency)
   - **Feature: openshift-compliance-playbook, Property 31: Multiple executions produce identical final state**

**Generator Strategies**:

- Namespace generators will create realistic namespace names with various prefixes
- Pod generators will create specifications with various seccomp profile configurations
- RBAC generators will create ClusterRoles with various permission patterns
- Service account generators will create accounts with various token mounting configurations

### Integration Testing

**Approach**: End-to-end testing on real OpenShift clusters (test environments)

**Test Cases**:

1. Full audit-only execution on a non-compliant cluster
2. Full remediation execution on a non-compliant cluster
3. Re-running remediation on an already-compliant cluster (idempotency validation)
4. Execution with partial failures (some namespaces inaccessible)

**Validation**:

- Verify all reports are generated with correct content
- Verify all remediations are applied correctly
- Verify cluster state matches expected compliance posture
- Verify no unintended side effects on system namespaces

### Test Execution

**Local Development**:

```bash
# Run unit tests with Molecule
molecule test

# Run property-based tests
pytest tests/property_tests/ --hypothesis-show-statistics

# Run integration tests (requires OpenShift cluster)
./tests/integration/run_integration_tests.sh
```

**CI/CD Pipeline**:

- Unit tests run on every commit
- Property-based tests run on every pull request
- Integration tests run nightly on test clusters
- Full compliance validation run before releases

