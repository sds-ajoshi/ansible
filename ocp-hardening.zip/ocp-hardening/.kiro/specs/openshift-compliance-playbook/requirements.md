# Requirements Document

## Introduction

This specification defines an Ansible playbook system for auditing and remediating OpenShift 4.20 cluster compliance against CIS Level 2 Benchmark and Hitachi CPSSR v4.0 standards. The playbook will automate the detection of compliance gaps and apply remediation actions to achieve 95% compliance targets (CIS: 79/83 controls, CPSSR: 29/31 requirements). The system will generate audit reports, apply security controls to user namespaces, and validate remediation effectiveness.

## Glossary

- **OpenShift Cluster**: The target OpenShift 4.20 container platform environment
- **Ansible Playbook**: The automation tool that executes audit and remediation tasks
- **User Namespace**: Any Kubernetes namespace not prefixed with `openshift-`, `kube-`, or named `default`
- **System Namespace**: Kubernetes namespaces prefixed with `openshift-`, `kube-`, or the `default` namespace
- **NetworkPolicy**: Kubernetes resource that controls network traffic between pods
- **Seccomp Profile**: Linux security feature that restricts system calls available to containers
- **RBAC**: Role-Based Access Control for Kubernetes API authorization
- **Service Account**: Kubernetes identity used by pods to authenticate to the API server
- **SCC**: Security Context Constraints, OpenShift's pod security policy mechanism
- **CIS Benchmark**: Center for Internet Security security configuration standard
- **CPSSR**: Hitachi Compliance and Privacy Security Standards Requirements v4.0
- **Audit Report**: A timestamped document listing compliance findings and gaps
- **Remediation Action**: An automated fix applied to achieve compliance

## Requirements

### Requirement 1

**User Story:** As a cluster administrator, I want to audit network policy compliance across all user namespaces, so that I can identify which namespaces lack default-deny ingress policies.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes the network policy audit THEN the Ansible Playbook SHALL retrieve all user namespaces excluding system namespaces
2. WHEN the Ansible Playbook identifies user namespaces THEN the Ansible Playbook SHALL check each namespace for a NetworkPolicy named `default-deny-ingress`
3. WHEN the Ansible Playbook completes the network policy audit THEN the Ansible Playbook SHALL generate a report listing namespaces without default-deny policies
4. WHEN the Ansible Playbook generates the network policy audit report THEN the Ansible Playbook SHALL include timestamp, namespace names, and compliance status
5. WHEN the Ansible Playbook filters namespaces THEN the Ansible Playbook SHALL exclude namespaces starting with `openshift-`, `kube-`, and the namespace named `default`

### Requirement 2

**User Story:** As a cluster administrator, I want to automatically remediate missing network policies, so that all user namespaces have default-deny ingress protection.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes network policy remediation THEN the Ansible Playbook SHALL create a NetworkPolicy named `default-deny-ingress` in each non-compliant user namespace
2. WHEN the Ansible Playbook creates a NetworkPolicy THEN the Ansible Playbook SHALL configure it with empty `podSelector` and `policyTypes` containing `Ingress`
3. WHEN the Ansible Playbook applies network policies THEN the Ansible Playbook SHALL verify CNI support before applying policies
4. WHEN the Ansible Playbook completes network policy remediation THEN the Ansible Playbook SHALL validate that the NetworkPolicy was successfully created
5. WHEN the Ansible Playbook encounters an error creating a NetworkPolicy THEN the Ansible Playbook SHALL log the error and continue processing remaining namespaces

### Requirement 3

**User Story:** As a cluster administrator, I want to audit pod seccomp profile compliance, so that I can identify pods not using RuntimeDefault seccomp profiles.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes the seccomp audit THEN the Ansible Playbook SHALL retrieve all pods from all user namespaces
2. WHEN the Ansible Playbook examines pod specifications THEN the Ansible Playbook SHALL check for `seccompProfile.type` set to `RuntimeDefault` in pod securityContext
3. WHEN the Ansible Playbook examines pod specifications THEN the Ansible Playbook SHALL check for `seccompProfile.type` set to `RuntimeDefault` in container securityContext
4. WHEN the Ansible Playbook completes the seccomp audit THEN the Ansible Playbook SHALL generate a report listing pods without RuntimeDefault seccomp profiles
5. WHEN the Ansible Playbook generates the seccomp audit report THEN the Ansible Playbook SHALL include namespace, pod name, and seccomp profile status

### Requirement 4

**User Story:** As a cluster administrator, I want to audit RBAC configurations, so that I can identify excessive cluster-admin bindings and wildcard permissions.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes the RBAC audit THEN the Ansible Playbook SHALL retrieve all ClusterRoleBindings with roleRef name `cluster-admin`
2. WHEN the Ansible Playbook examines ClusterRoles THEN the Ansible Playbook SHALL identify custom roles containing wildcard characters in apiGroups, resources, or verbs
3. WHEN the Ansible Playbook identifies wildcard permissions THEN the Ansible Playbook SHALL exclude system roles named `cluster-admin`, `admin`, or `edit`
4. WHEN the Ansible Playbook completes the RBAC audit THEN the Ansible Playbook SHALL generate a report named `rbac-audit-report.md` with timestamp
5. WHEN the Ansible Playbook generates the RBAC audit report THEN the Ansible Playbook SHALL list all cluster-admin bindings with subject details and all custom roles with wildcard permissions

### Requirement 5

**User Story:** As a cluster administrator, I want to audit service account token mounting configurations, so that I can identify default service accounts with automatic token mounting enabled.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes the service account audit THEN the Ansible Playbook SHALL retrieve all default service accounts from user namespaces
2. WHEN the Ansible Playbook examines service accounts THEN the Ansible Playbook SHALL check the `automountServiceAccountToken` field value
3. WHEN the Ansible Playbook finds a default service account with `automountServiceAccountToken` not set to `false` THEN the Ansible Playbook SHALL mark it as non-compliant
4. WHEN the Ansible Playbook completes the service account audit THEN the Ansible Playbook SHALL generate a report listing non-compliant service accounts
5. WHEN the Ansible Playbook generates the service account audit report THEN the Ansible Playbook SHALL include namespace, service account name, and token mounting status

### Requirement 6

**User Story:** As a cluster administrator, I want to automatically remediate service account token mounting, so that default service accounts have automatic token mounting disabled.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes service account remediation THEN the Ansible Playbook SHALL patch each non-compliant default service account
2. WHEN the Ansible Playbook patches a service account THEN the Ansible Playbook SHALL set `automountServiceAccountToken` to `false`
3. WHEN the Ansible Playbook completes service account remediation THEN the Ansible Playbook SHALL validate that the patch was successfully applied
4. WHEN the Ansible Playbook encounters an error patching a service account THEN the Ansible Playbook SHALL log the error and continue processing remaining service accounts

### Requirement 7

**User Story:** As a cluster administrator, I want to audit default namespace protection, so that I can verify the default namespace has a ResourceQuota preventing workload deployment.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes the default namespace audit THEN the Ansible Playbook SHALL check for a ResourceQuota named `prevent-deployments` in the default namespace
2. WHEN the Ansible Playbook examines the ResourceQuota THEN the Ansible Playbook SHALL verify the hard quota contains `pods: "0"` and `services: "0"`
3. WHEN the Ansible Playbook completes the default namespace audit THEN the Ansible Playbook SHALL report whether the ResourceQuota exists and is correctly configured
4. WHEN the ResourceQuota is missing or misconfigured THEN the Ansible Playbook SHALL mark the default namespace as non-compliant

### Requirement 8

**User Story:** As a cluster administrator, I want to automatically remediate default namespace protection, so that the default namespace has a ResourceQuota preventing workload deployment.

#### Acceptance Criteria

1. WHEN the Ansible Playbook executes default namespace remediation THEN the Ansible Playbook SHALL create a ResourceQuota named `prevent-deployments` in the default namespace
2. WHEN the Ansible Playbook creates the ResourceQuota THEN the Ansible Playbook SHALL set hard quotas for `pods: "0"`, `services: "0"`, `replicationcontrollers: "0"`, and `resourcequotas: "1"`
3. WHEN the Ansible Playbook completes default namespace remediation THEN the Ansible Playbook SHALL validate that the ResourceQuota was successfully created
4. WHEN the ResourceQuota already exists with correct configuration THEN the Ansible Playbook SHALL skip creation and report compliance

### Requirement 9

**User Story:** As a cluster administrator, I want to generate a comprehensive compliance summary report, so that I can review overall cluster compliance status and track progress toward targets.

#### Acceptance Criteria

1. WHEN the Ansible Playbook completes all audit tasks THEN the Ansible Playbook SHALL generate a summary report file named `compliance-summary-report.md`
2. WHEN the Ansible Playbook generates the summary report THEN the Ansible Playbook SHALL include timestamp, total namespaces audited, and compliance percentages
3. WHEN the Ansible Playbook generates the summary report THEN the Ansible Playbook SHALL list findings for network policies, seccomp profiles, RBAC, service accounts, and default namespace protection
4. WHEN the Ansible Playbook generates the summary report THEN the Ansible Playbook SHALL include counts of compliant and non-compliant resources for each category
5. WHEN the Ansible Playbook generates the summary report THEN the Ansible Playbook SHALL calculate and display progress toward CIS Level 2 and CPSSR v4.0 targets

### Requirement 10

**User Story:** As a cluster administrator, I want the playbook to support both audit-only and remediation modes, so that I can review findings before applying changes.

#### Acceptance Criteria

1. WHEN the Ansible Playbook is invoked with audit mode THEN the Ansible Playbook SHALL execute all audit tasks without applying remediation actions
2. WHEN the Ansible Playbook is invoked with remediation mode THEN the Ansible Playbook SHALL execute audit tasks followed by remediation actions for non-compliant resources
3. WHEN the Ansible Playbook is invoked without specifying a mode THEN the Ansible Playbook SHALL default to audit-only mode
4. WHEN the Ansible Playbook executes in remediation mode THEN the Ansible Playbook SHALL generate both pre-remediation and post-remediation audit reports
5. WHEN the Ansible Playbook completes in remediation mode THEN the Ansible Playbook SHALL display a summary comparing pre-remediation and post-remediation compliance status

### Requirement 11

**User Story:** As a cluster administrator, I want the playbook to validate OpenShift cluster connectivity and permissions before execution, so that I can identify configuration issues early.

#### Acceptance Criteria

1. WHEN the Ansible Playbook starts execution THEN the Ansible Playbook SHALL verify connectivity to the OpenShift cluster API
2. WHEN the Ansible Playbook verifies connectivity THEN the Ansible Playbook SHALL check that the current user has cluster-admin or equivalent permissions
3. WHEN the Ansible Playbook verifies connectivity THEN the Ansible Playbook SHALL validate that required command-line tools are available
4. WHEN the Ansible Playbook detects missing permissions or tools THEN the Ansible Playbook SHALL fail with a clear error message listing requirements
5. WHEN the Ansible Playbook completes validation successfully THEN the Ansible Playbook SHALL proceed with audit and remediation tasks

### Requirement 12

**User Story:** As a cluster administrator, I want the playbook to be idempotent, so that I can safely run it multiple times without causing unintended changes.

#### Acceptance Criteria

1. WHEN the Ansible Playbook applies a remediation action THEN the Ansible Playbook SHALL check if the resource already exists in the desired state
2. WHEN the Ansible Playbook finds a resource already in the desired state THEN the Ansible Playbook SHALL skip modification and report the resource as compliant
3. WHEN the Ansible Playbook is executed multiple times in remediation mode THEN the Ansible Playbook SHALL produce the same final state
4. WHEN the Ansible Playbook creates or modifies resources THEN the Ansible Playbook SHALL use Ansible modules that support idempotent operations
5. WHEN the Ansible Playbook completes execution THEN the Ansible Playbook SHALL report which resources were changed, which were already compliant, and which failed
