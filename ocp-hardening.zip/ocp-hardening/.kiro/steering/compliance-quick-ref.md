---
inclusion: always
---

# OpenShift Compliance Quick Reference

## Compliance Context

This OpenShift 4.20 cluster targets 95% compliance with CIS Level 2 Benchmark and Hitachi CPSSR v4.0. Current baseline: CIS 88% (73/83), CPSSR 90% (27/31).

## Core Compliance Patterns

### Network Security

- Apply default-deny NetworkPolicies to all user namespaces (exclude `openshift-*`, `kube-*`, `default`)
- NetworkPolicy name: `default-deny-ingress` with empty `podSelector` and `policyTypes: [Ingress]`
- Verify CNI support before applying: `oc get network.config.openshift.io cluster -o jsonpath='{.spec.networkType}'`
- Satisfies: CIS 5.3.2, CPSSR 4.02.L

### Pod Security

- All pods must use `seccompProfile.type: RuntimeDefault`
- Create SCC named `restricted-v2-seccomp` with seccomp enforcement
- Patch deployments: `spec.template.spec.securityContext.seccompProfile.type: RuntimeDefault`
- Disable host access: `allowHostDirVolumePlugin`, `allowHostIPC`, `allowHostNetwork`, `allowHostPID`, `allowHostPorts` all false
- Satisfies: CIS 5.7.2, CPSSR 4.02.D

### RBAC Hardening

- Audit all `cluster-admin` ClusterRoleBindings and document justification
- Identify wildcard permissions (`*` in verbs/resources/apiGroups) and document necessity
- Generate audit reports in `rbac-audit-report.md` with timestamp
- Only system roles should use wildcards; custom roles must be specific
- Satisfies: CIS 5.1.1, 5.1.3, CPSSR 1.07

### Service Account Security

- Disable automatic token mounting: `automountServiceAccountToken: false` on default ServiceAccounts
- Apply to all user namespaces (exclude system namespaces)
- Satisfies: CIS 5.1.5, 5.1.6

### Namespace Protection

- Protect `default` namespace with ResourceQuota: `pods: "0"`, `services: "0"`
- ResourceQuota name: `prevent-deployments`
- Satisfies: CIS 5.7.4

## Command Patterns

### Namespace Filtering

Exclude system namespaces in loops:

```bash
oc get ns -o json | jq -r '.items[] | select(.metadata.name | startswith("openshift") | not) | select(.metadata.name | startswith("kube-") | not) | select(.metadata.name != "default") | .metadata.name'
```

### Verification Commands

- Network policies: `oc get networkpolicies --all-namespaces`
- Seccomp profiles: `oc get pods --all-namespaces -o json | jq '.items[] | {name: .metadata.name, seccomp: .spec.securityContext.seccompProfile.type}'`
- Service accounts: `oc get sa default --all-namespaces -o json | jq '.items[] | {namespace: .metadata.namespace, automount: .automountServiceAccountToken}'`
- RBAC audit: `oc get clusterrolebinding -o json | jq -r '.items[] | select(.roleRef.name=="cluster-admin")'`

## Documented Compliance Gaps

These gaps are accepted due to infrastructure constraints:

1. **External Audit Log Forwarding** (CIS 1.2.19, CPSSR 2.03): No external logging platform available. Mitigation: Local logs at `/var/log/kube-apiserver/audit.log` with immutable audit rules.

2. **External Secret Storage** (CIS 5.4.2, CPSSR 3.05): No external KMS available. Mitigation: etcd encrypted at rest with TPM2 + LUKS2.

## Maintenance Schedule

- **Weekly**: Re-apply network policies to new namespaces, verify seccomp enforcement
- **Monthly**: Full RBAC audit export, network policy review export

## Validation Checklist

When validating compliance:

- Network policies exist in all user namespaces
- All pods have `RuntimeDefault` seccomp profile
- RBAC audit report exists and is current
- Default ServiceAccounts have token mounting disabled
- Default namespace has ResourceQuota preventing deployments
- SCCs are properly configured

Target state: 95% CIS Level 2 (79/83 controls), 95% CPSSR v4.0 (29/31 requirements)
