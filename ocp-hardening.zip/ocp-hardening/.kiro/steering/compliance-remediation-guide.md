---
inclusion: fileMatch
fileMatchPattern: ['**/*.yaml', '**/*.yml', '**/Dockerfile', '**/*.sh']
---

# OpenShift 4.20 Compliance Remediation Guide

Target: OpenShift 4.20 | CIS Level 2 (95%) | CPSSR v4.0 (95%)

## Core Compliance Requirements

When working with OpenShift resources, enforce these security controls:

### Network Policies (CIS 5.3.2, CPSSR 4.02.L)

- All user namespaces MUST have default-deny ingress NetworkPolicy
- Exclude system namespaces: `openshift-*`, `kube-*`, `default`
- Always create explicit allow policies for required traffic (DNS, ingress controller)

### Seccomp Profiles (CIS 5.7.2, CPSSR 4.02.D)

- All pods MUST use `seccompProfile.type: RuntimeDefault`
- Apply at both pod-level and container-level securityContext
- Use Security Context Constraints (SCC) for cluster-wide enforcement

### RBAC Hardening (CIS 5.1.1, 5.1.3, CPSSR 1.07)

- Minimize cluster-admin role usage (document all bindings)
- NO wildcards (`*`) in custom ClusterRoles for apiGroups, resources, or verbs
- System roles (cluster-admin, admin, edit) are acceptable exceptions
- Create least-privilege custom roles with explicit permissions

### Service Account Tokens (CIS 5.1.5, 5.1.6)

- Default service accounts MUST have `automountServiceAccountToken: false`
- Only enable token mounting explicitly when pods need Kubernetes API access
- Create custom service accounts with minimal RBAC permissions

### Default Namespace Protection (CIS 5.7.4)

- Prevent workload deployment to `default` namespace using ResourceQuota
- Set `pods: "0"` and `services: "0"` in quota spec

### Pod Security (CIS 5.2, CPSSR 4.02)

- Use `restricted-v2` SCC as default for authenticated users
- Enforce: `runAsNonRoot: true`, `allowPrivilegeEscalation: false`, drop ALL capabilities
- Never grant privileged SCC to user workloads

## Known Gaps (Document, Don't Fix)

- External audit log forwarding (CIS 1.2.19, CPSSR 2.03) - requires external platform
- External secret storage (CIS 5.4.2, CPSSR 3.05) - requires external KMS

## Implementation Patterns

### Network Policy Templates

Default-deny ingress (apply to all user namespaces):

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-ingress
  namespace: <NAMESPACE>
spec:
  podSelector: {}
  policyTypes:
  - Ingress
```

Allow DNS egress:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-dns
  namespace: <NAMESPACE>
spec:
  podSelector: {}
  policyTypes:
  - Egress
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          name: openshift-dns
    ports:
    - protocol: UDP
      port: 5353
```

Allow ingress from OpenShift router:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-from-openshift-ingress
  namespace: <NAMESPACE>
spec:
  podSelector:
    matchLabels:
      app: <APP_NAME>
  policyTypes:
  - Ingress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          network.openshift.io/policy-group: ingress
    ports:
    - protocol: TCP
      port: 8080
```

### Seccomp Profile Templates

Deployment with RuntimeDefault seccomp:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: example-app
spec:
  template:
    spec:
      securityContext:
        runAsNonRoot: true
        seccompProfile:
          type: RuntimeDefault
      containers:
      - name: app
        image: registry.redhat.io/ubi9/ubi-minimal:latest
        securityContext:
          allowPrivilegeEscalation: false
          runAsNonRoot: true
          capabilities:
            drop:
            - ALL
          seccompProfile:
            type: RuntimeDefault
```

### RBAC Templates

Least-privilege developer role (no wildcards):

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: developer-role
rules:
- apiGroups: [""]
  resources: ["pods", "pods/log"]
  verbs: ["get", "list", "watch", "create", "delete"]
- apiGroups: ["apps"]
  resources: ["deployments", "replicasets"]
  verbs: ["get", "list", "watch", "create", "update", "delete"]
- apiGroups: [""]
  resources: ["services"]
  verbs: ["get", "list", "watch", "create", "update", "delete"]
- apiGroups: [""]
  resources: ["configmaps"]
  verbs: ["get", "list", "watch"]
```

Read-only monitoring role:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: monitoring-reader
rules:
- apiGroups: [""]
  resources: ["pods", "services", "endpoints", "nodes"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["apps"]
  resources: ["deployments", "replicasets", "daemonsets", "statefulsets"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["metrics.k8s.io"]
  resources: ["pods", "nodes"]
  verbs: ["get", "list"]
```

### Service Account Templates

Default service account (disable token mounting):

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: default
  namespace: <NAMESPACE>
automountServiceAccountToken: false
```

Custom service account with explicit token mounting and minimal RBAC:

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: app-service-account
  namespace: <NAMESPACE>
automountServiceAccountToken: false
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: app-role
  namespace: <NAMESPACE>
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  verbs: ["get", "list"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: app-role-binding
  namespace: <NAMESPACE>
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: app-role
subjects:
- kind: ServiceAccount
  name: app-service-account
  namespace: <NAMESPACE>
```

Pod with explicit token mounting (only when needed):

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: app-with-k8s-api-access
spec:
  serviceAccountName: app-service-account
  automountServiceAccountToken: true
  containers:
  - name: app
    image: registry.redhat.io/ubi9/ubi-minimal:latest
```

### Default Namespace Protection

ResourceQuota to prevent workload deployment:

```yaml
apiVersion: v1
kind: ResourceQuota
metadata:
  name: prevent-deployments
  namespace: default
spec:
  hard:
    pods: "0"
    services: "0"
    replicationcontrollers: "0"
    resourcequotas: "1"
```

### Security Context Constraints (SCC)

OpenShift uses SCCs instead of Pod Security Policies. Default SCC for authenticated users:

- `restricted-v2`: Default for all user workloads
- `privileged`: System workloads only (never grant to users)
- `anyuid`: Special cases only (requires justification)

Expected system bindings (do not remove):

- `cluster-admin` (group: system:masters)
- `system:openshift:controller:cluster-policy-controller`
- `system:openshift:scc:privileged`

## Validation Commands

Check network policies:

```bash
oc get networkpolicies --all-namespaces
```

Verify seccomp profiles:

```bash
oc get pods -n <namespace> -o json | \
  jq '.items[] | {name: .metadata.name, seccomp: .spec.securityContext.seccompProfile.type}'
```

Audit cluster-admin bindings:

```bash
oc get clusterrolebinding -o json | \
  jq -r '.items[] | select(.roleRef.name=="cluster-admin") | {name: .metadata.name, subjects: .subjects}'
```

Check service account token mounting:

```bash
oc get sa default --all-namespaces -o json | \
  jq '.items[] | {namespace: .metadata.namespace, automount: .automountServiceAccountToken}'
```

Verify default namespace protection:

```bash
oc describe quota prevent-deployments -n default
```

## Automation Scripts

Apply network policies to all user namespaces:

```bash
NAMESPACES=$(oc get ns -o json | jq -r '.items[] | select(.metadata.name | startswith("openshift") | not) | select(.metadata.name | startswith("kube-") | not) | select(.metadata.name != "default") | .metadata.name')

for ns in $NAMESPACES; do
  oc apply -f - <<EOF
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-ingress
  namespace: $ns
spec:
  podSelector: {}
  policyTypes:
  - Ingress
EOF
done
```

Disable default service account token mounting:

```bash
NAMESPACES=$(oc get ns -o json | jq -r '.items[] | select(.metadata.name | startswith("openshift") | not) | select(.metadata.name | startswith("kube-") | not) | .metadata.name')

for ns in $NAMESPACES; do
  oc patch serviceaccount default -n $ns -p '{"automountServiceAccountToken": false}'
done
```
