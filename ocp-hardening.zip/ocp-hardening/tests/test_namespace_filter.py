#!/usr/bin/env python3
"""
Unit tests for the namespace filter plugin.

Tests the filter_user_namespaces custom filter to ensure it correctly
excludes system namespaces and returns only user namespaces.
Also tests the parse_seccomp_compliance filter for seccomp profile auditing.
"""

import sys
import os

# Add the filter plugin directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'roles', 'common', 'filter_plugins'))

from namespace_filter import FilterModule


def test_filter_with_namespace_objects():
    """Test filtering with namespace objects (dict format)."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['filter_user_namespaces']
    
    namespaces = [
        {'metadata': {'name': 'openshift-apiserver'}},
        {'metadata': {'name': 'kube-system'}},
        {'metadata': {'name': 'default'}},
        {'metadata': {'name': 'my-app'}},
        {'metadata': {'name': 'production'}},
        {'metadata': {'name': 'openshift-monitoring'}},
        {'metadata': {'name': 'kube-public'}},
    ]
    
    result = filter_func(namespaces)
    
    assert result == ['my-app', 'production'], f"Expected ['my-app', 'production'], got {result}"
    print("✓ Test with namespace objects passed")


def test_filter_with_string_names():
    """Test filtering with namespace name strings."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['filter_user_namespaces']
    
    namespaces = [
        'openshift-apiserver',
        'kube-system',
        'default',
        'my-app',
        'production',
        'openshift-monitoring',
        'kube-public',
    ]
    
    result = filter_func(namespaces)
    
    assert result == ['my-app', 'production'], f"Expected ['my-app', 'production'], got {result}"
    print("✓ Test with string names passed")


def test_filter_with_edge_cases():
    """Test filtering with edge case namespace names."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['filter_user_namespaces']
    
    namespaces = [
        'openshift',  # Does not start with 'openshift-', should be included
        'kube',       # Does not start with 'kube-', should be included
        'default-app', # Not exactly 'default', should be included
        'my-openshift-app',  # Contains 'openshift' but doesn't start with 'openshift-'
        'openshift-test',    # Starts with 'openshift-', should be excluded
        'kube-test',         # Starts with 'kube-', should be excluded
    ]
    
    result = filter_func(namespaces)
    
    expected = ['openshift', 'kube', 'default-app', 'my-openshift-app']
    assert result == expected, f"Expected {expected}, got {result}"
    print("✓ Test with edge cases passed")


def test_filter_with_empty_list():
    """Test filtering with empty namespace list."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['filter_user_namespaces']
    
    result = filter_func([])
    
    assert result == [], f"Expected [], got {result}"
    print("✓ Test with empty list passed")


def test_filter_with_none():
    """Test filtering with None input."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['filter_user_namespaces']
    
    result = filter_func(None)
    
    assert result == [], f"Expected [], got {result}"
    print("✓ Test with None input passed")


def test_filter_with_mixed_formats():
    """Test filtering with mixed namespace formats."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['filter_user_namespaces']
    
    namespaces = [
        {'metadata': {'name': 'openshift-apiserver'}},
        'kube-system',
        {'metadata': {'name': 'my-app'}},
        'production',
        {'name': 'staging'},  # Alternative dict format
    ]
    
    result = filter_func(namespaces)
    
    expected = ['my-app', 'production', 'staging']
    assert result == expected, f"Expected {expected}, got {result}"
    print("✓ Test with mixed formats passed")


def test_all_system_namespaces_excluded():
    """Test that all system namespaces are excluded."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['filter_user_namespaces']
    
    namespaces = [
        'openshift-apiserver',
        'openshift-authentication',
        'openshift-cluster-version',
        'kube-system',
        'kube-public',
        'kube-node-lease',
        'default',
    ]
    
    result = filter_func(namespaces)
    
    assert result == [], f"Expected [], got {result}"
    print("✓ Test with all system namespaces passed")


def test_seccomp_compliance_pod_level_compliant():
    """Test seccomp compliance with pod-level RuntimeDefault."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_seccomp_compliance']
    
    pod = {
        'metadata': {
            'name': 'test-pod',
            'namespace': 'my-app'
        },
        'spec': {
            'securityContext': {
                'seccompProfile': {
                    'type': 'RuntimeDefault'
                }
            },
            'containers': [
                {'name': 'container1'}
            ]
        }
    }
    
    result = filter_func(pod, 'RuntimeDefault')
    
    assert result['namespace'] == 'my-app'
    assert result['pod_name'] == 'test-pod'
    assert result['pod_seccomp'] == 'RuntimeDefault'
    assert result['compliant'] is True
    print("✓ Test seccomp pod-level compliant passed")


def test_seccomp_compliance_container_level_compliant():
    """Test seccomp compliance with container-level RuntimeDefault."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_seccomp_compliance']
    
    pod = {
        'metadata': {
            'name': 'test-pod',
            'namespace': 'my-app'
        },
        'spec': {
            'containers': [
                {
                    'name': 'container1',
                    'securityContext': {
                        'seccompProfile': {
                            'type': 'RuntimeDefault'
                        }
                    }
                }
            ]
        }
    }
    
    result = filter_func(pod, 'RuntimeDefault')
    
    assert result['namespace'] == 'my-app'
    assert result['pod_name'] == 'test-pod'
    assert result['pod_seccomp'] is None
    assert result['container_seccomp'] == 'RuntimeDefault'
    assert result['compliant'] is True
    print("✓ Test seccomp container-level compliant passed")


def test_seccomp_compliance_non_compliant():
    """Test seccomp compliance with non-compliant pod."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_seccomp_compliance']
    
    pod = {
        'metadata': {
            'name': 'test-pod',
            'namespace': 'my-app'
        },
        'spec': {
            'securityContext': {
                'seccompProfile': {
                    'type': 'Unconfined'
                }
            },
            'containers': [
                {'name': 'container1'}
            ]
        }
    }
    
    result = filter_func(pod, 'RuntimeDefault')
    
    assert result['namespace'] == 'my-app'
    assert result['pod_name'] == 'test-pod'
    assert result['pod_seccomp'] == 'Unconfined'
    assert result['compliant'] is False
    print("✓ Test seccomp non-compliant passed")


def test_seccomp_compliance_no_profile():
    """Test seccomp compliance with no profile set."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_seccomp_compliance']
    
    pod = {
        'metadata': {
            'name': 'test-pod',
            'namespace': 'my-app'
        },
        'spec': {
            'containers': [
                {'name': 'container1'}
            ]
        }
    }
    
    result = filter_func(pod, 'RuntimeDefault')
    
    assert result['namespace'] == 'my-app'
    assert result['pod_name'] == 'test-pod'
    assert result['pod_seccomp'] is None
    assert result['container_seccomp'] is None
    assert result['compliant'] is False
    print("✓ Test seccomp no profile passed")


def test_seccomp_compliance_multiple_containers():
    """Test seccomp compliance with multiple containers."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_seccomp_compliance']
    
    pod = {
        'metadata': {
            'name': 'test-pod',
            'namespace': 'my-app'
        },
        'spec': {
            'containers': [
                {
                    'name': 'container1',
                    'securityContext': {
                        'seccompProfile': {
                            'type': 'RuntimeDefault'
                        }
                    }
                },
                {
                    'name': 'container2',
                    'securityContext': {
                        'seccompProfile': {
                            'type': 'RuntimeDefault'
                        }
                    }
                }
            ]
        }
    }
    
    result = filter_func(pod, 'RuntimeDefault')
    
    assert result['compliant'] is True
    print("✓ Test seccomp multiple containers compliant passed")


def test_seccomp_compliance_mixed_containers():
    """Test seccomp compliance with mixed container profiles."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_seccomp_compliance']
    
    pod = {
        'metadata': {
            'name': 'test-pod',
            'namespace': 'my-app'
        },
        'spec': {
            'containers': [
                {
                    'name': 'container1',
                    'securityContext': {
                        'seccompProfile': {
                            'type': 'RuntimeDefault'
                        }
                    }
                },
                {
                    'name': 'container2',
                    'securityContext': {
                        'seccompProfile': {
                            'type': 'Unconfined'
                        }
                    }
                }
            ]
        }
    }
    
    result = filter_func(pod, 'RuntimeDefault')
    
    assert result['compliant'] is False
    assert 'RuntimeDefault' in result['container_seccomp']
    assert 'Unconfined' in result['container_seccomp']
    print("✓ Test seccomp mixed containers non-compliant passed")


def test_seccomp_compliance_both_levels():
    """Test seccomp compliance with both pod and container level profiles."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_seccomp_compliance']
    
    pod = {
        'metadata': {
            'name': 'test-pod',
            'namespace': 'my-app'
        },
        'spec': {
            'securityContext': {
                'seccompProfile': {
                    'type': 'RuntimeDefault'
                }
            },
            'containers': [
                {
                    'name': 'container1',
                    'securityContext': {
                        'seccompProfile': {
                            'type': 'Unconfined'
                        }
                    }
                }
            ]
        }
    }
    
    result = filter_func(pod, 'RuntimeDefault')
    
    # Pod-level is compliant, so overall should be compliant
    assert result['compliant'] is True
    assert result['pod_seccomp'] == 'RuntimeDefault'
    print("✓ Test seccomp both levels passed")


def test_extract_clusterrolebinding_basic():
    """Test extracting details from a basic ClusterRoleBinding."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_clusterrolebinding_details']
    
    binding = {
        'metadata': {
            'name': 'cluster-admin-binding'
        },
        'roleRef': {
            'apiGroup': 'rbac.authorization.k8s.io',
            'kind': 'ClusterRole',
            'name': 'cluster-admin'
        },
        'subjects': [
            {
                'kind': 'User',
                'name': 'admin@example.com'
            },
            {
                'kind': 'Group',
                'name': 'cluster-admins'
            }
        ]
    }
    
    result = filter_func(binding)
    
    assert result['name'] == 'cluster-admin-binding'
    assert result['roleRef']['name'] == 'cluster-admin'
    assert len(result['subjects']) == 2
    assert result['subjects'][0]['kind'] == 'User'
    assert result['subjects'][0]['name'] == 'admin@example.com'
    assert result['subjects'][1]['kind'] == 'Group'
    assert result['subjects'][1]['name'] == 'cluster-admins'
    print("✓ Test extract ClusterRoleBinding basic passed")


def test_extract_clusterrolebinding_with_serviceaccount():
    """Test extracting details from ClusterRoleBinding with ServiceAccount subject."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_clusterrolebinding_details']
    
    binding = {
        'metadata': {
            'name': 'sa-binding'
        },
        'roleRef': {
            'apiGroup': 'rbac.authorization.k8s.io',
            'kind': 'ClusterRole',
            'name': 'cluster-admin'
        },
        'subjects': [
            {
                'kind': 'ServiceAccount',
                'name': 'my-service-account',
                'namespace': 'my-namespace'
            }
        ]
    }
    
    result = filter_func(binding)
    
    assert result['name'] == 'sa-binding'
    assert len(result['subjects']) == 1
    assert result['subjects'][0]['kind'] == 'ServiceAccount'
    assert result['subjects'][0]['name'] == 'my-service-account'
    assert result['subjects'][0]['namespace'] == 'my-namespace'
    print("✓ Test extract ClusterRoleBinding with ServiceAccount passed")


def test_extract_clusterrolebinding_invalid():
    """Test extracting details from invalid ClusterRoleBinding."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_clusterrolebinding_details']
    
    result = filter_func(None)
    
    assert result['name'] == 'unknown'
    assert result['roleRef'] == {}
    assert result['subjects'] == []
    print("✓ Test extract ClusterRoleBinding invalid passed")


def test_parse_wildcard_permissions_with_wildcards():
    """Test parsing ClusterRole with wildcard permissions."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_wildcard_permissions']
    
    role = {
        'metadata': {
            'name': 'overly-permissive-role'
        },
        'rules': [
            {
                'apiGroups': ['*'],
                'resources': ['pods', 'services'],
                'verbs': ['get', 'list']
            },
            {
                'apiGroups': ['apps'],
                'resources': ['*'],
                'verbs': ['*']
            }
        ]
    }
    
    result = filter_func(role)
    
    assert result['name'] == 'overly-permissive-role'
    assert result['has_wildcards'] is True
    assert len(result['wildcards']) == 3
    
    # Check for apiGroups wildcard in rule 0
    assert any(w['field'] == 'apiGroups' and w['rule_index'] == 0 for w in result['wildcards'])
    # Check for resources wildcard in rule 1
    assert any(w['field'] == 'resources' and w['rule_index'] == 1 for w in result['wildcards'])
    # Check for verbs wildcard in rule 1
    assert any(w['field'] == 'verbs' and w['rule_index'] == 1 for w in result['wildcards'])
    
    print("✓ Test parse wildcard permissions with wildcards passed")


def test_parse_wildcard_permissions_no_wildcards():
    """Test parsing ClusterRole without wildcard permissions."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_wildcard_permissions']
    
    role = {
        'metadata': {
            'name': 'specific-role'
        },
        'rules': [
            {
                'apiGroups': ['apps'],
                'resources': ['deployments'],
                'verbs': ['get', 'list', 'watch']
            },
            {
                'apiGroups': [''],
                'resources': ['pods'],
                'verbs': ['get']
            }
        ]
    }
    
    result = filter_func(role)
    
    assert result['name'] == 'specific-role'
    assert result['has_wildcards'] is False
    assert len(result['wildcards']) == 0
    print("✓ Test parse wildcard permissions no wildcards passed")


def test_parse_wildcard_permissions_empty_rules():
    """Test parsing ClusterRole with empty rules."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_wildcard_permissions']
    
    role = {
        'metadata': {
            'name': 'empty-role'
        },
        'rules': []
    }
    
    result = filter_func(role)
    
    assert result['name'] == 'empty-role'
    assert result['has_wildcards'] is False
    assert len(result['wildcards']) == 0
    print("✓ Test parse wildcard permissions empty rules passed")


def test_parse_wildcard_permissions_invalid():
    """Test parsing invalid ClusterRole."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['parse_wildcard_permissions']
    
    result = filter_func(None)
    
    assert result['name'] == 'unknown'
    assert result['has_wildcards'] is False
    assert result['wildcards'] == []
    assert result['rules'] == []
    print("✓ Test parse wildcard permissions invalid passed")


def test_extract_sa_token_status_compliant():
    """Test extracting service account token status when compliant (false)."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_sa_token_status']
    
    sa_check_result = {
        'item': 'my-app',
        'resources': [
            {
                'metadata': {
                    'name': 'default',
                    'namespace': 'my-app'
                },
                'automountServiceAccountToken': False
            }
        ]
    }
    
    result = filter_func(sa_check_result)
    
    assert result['namespace'] == 'my-app'
    assert result['service_account'] == 'default'
    assert result['automount_token'] is False
    assert result['compliant'] is True
    print("✓ Test extract SA token status compliant passed")


def test_extract_sa_token_status_non_compliant_true():
    """Test extracting service account token status when non-compliant (true)."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_sa_token_status']
    
    sa_check_result = {
        'item': 'my-app',
        'resources': [
            {
                'metadata': {
                    'name': 'default',
                    'namespace': 'my-app'
                },
                'automountServiceAccountToken': True
            }
        ]
    }
    
    result = filter_func(sa_check_result)
    
    assert result['namespace'] == 'my-app'
    assert result['service_account'] == 'default'
    assert result['automount_token'] is True
    assert result['compliant'] is False
    print("✓ Test extract SA token status non-compliant (true) passed")


def test_extract_sa_token_status_non_compliant_not_set():
    """Test extracting service account token status when non-compliant (not set)."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_sa_token_status']
    
    sa_check_result = {
        'item': 'my-app',
        'resources': [
            {
                'metadata': {
                    'name': 'default',
                    'namespace': 'my-app'
                }
                # automountServiceAccountToken field not present
            }
        ]
    }
    
    result = filter_func(sa_check_result)
    
    assert result['namespace'] == 'my-app'
    assert result['service_account'] == 'default'
    assert result['automount_token'] is None
    assert result['compliant'] is False
    print("✓ Test extract SA token status non-compliant (not set) passed")


def test_extract_sa_token_status_no_resources():
    """Test extracting service account token status when service account doesn't exist."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_sa_token_status']
    
    sa_check_result = {
        'item': 'my-app',
        'resources': []
    }
    
    result = filter_func(sa_check_result)
    
    assert result['namespace'] == 'my-app'
    assert result['service_account'] == 'default'
    assert result['automount_token'] is None
    assert result['compliant'] is False
    print("✓ Test extract SA token status no resources passed")


def test_extract_sa_token_status_invalid():
    """Test extracting service account token status with invalid input."""
    filter_module = FilterModule()
    filter_func = filter_module.filters()['extract_sa_token_status']
    
    result = filter_func(None)
    
    assert result['namespace'] == 'unknown'
    assert result['service_account'] == 'unknown'
    assert result['automount_token'] is None
    assert result['compliant'] is False
    print("✓ Test extract SA token status invalid passed")


if __name__ == '__main__':
    print("Running namespace filter tests...\n")
    
    try:
        # Namespace filter tests
        test_filter_with_namespace_objects()
        test_filter_with_string_names()
        test_filter_with_edge_cases()
        test_filter_with_empty_list()
        test_filter_with_none()
        test_filter_with_mixed_formats()
        test_all_system_namespaces_excluded()
        
        # Seccomp compliance tests
        test_seccomp_compliance_pod_level_compliant()
        test_seccomp_compliance_container_level_compliant()
        test_seccomp_compliance_non_compliant()
        test_seccomp_compliance_no_profile()
        test_seccomp_compliance_multiple_containers()
        test_seccomp_compliance_mixed_containers()
        test_seccomp_compliance_both_levels()
        
        # RBAC filter tests
        test_extract_clusterrolebinding_basic()
        test_extract_clusterrolebinding_with_serviceaccount()
        test_extract_clusterrolebinding_invalid()
        test_parse_wildcard_permissions_with_wildcards()
        test_parse_wildcard_permissions_no_wildcards()
        test_parse_wildcard_permissions_empty_rules()
        test_parse_wildcard_permissions_invalid()
        
        # Service account token status tests
        test_extract_sa_token_status_compliant()
        test_extract_sa_token_status_non_compliant_true()
        test_extract_sa_token_status_non_compliant_not_set()
        test_extract_sa_token_status_no_resources()
        test_extract_sa_token_status_invalid()
        
        print("\n✅ All tests passed!")
        sys.exit(0)
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)
