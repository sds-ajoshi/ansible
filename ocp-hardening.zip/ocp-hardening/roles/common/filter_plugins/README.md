# OpenShift Compliance Filter Plugins

## Overview

This custom Ansible filter plugin provides functionality for OpenShift compliance auditing:
1. Filter namespaces to exclude system namespaces and return only user namespaces
2. Parse pod specifications to determine seccomp profile compliance

## Filter: `filter_user_namespaces`

### Description

Filters a list of namespaces to return only user namespaces by excluding:
- Namespaces starting with `openshift-`
- Namespaces starting with `kube-`
- The namespace named `default`

### Usage

The filter can accept namespaces in two formats:

1. **Namespace objects** (as returned by `k8s_info` module):
```yaml
- name: Get all namespaces
  kubernetes.core.k8s_info:
    kind: Namespace
  register: all_namespaces

- name: Filter to user namespaces
  set_fact:
    user_namespaces: "{{ all_namespaces.resources | filter_user_namespaces }}"
```

2. **Namespace name strings**:
```yaml
- name: Filter namespace names
  set_fact:
    user_namespaces: "{{ namespace_list | filter_user_namespaces }}"
  vars:
    namespace_list:
      - openshift-apiserver
      - kube-system
      - default
      - my-app
      - production
```

### Examples

#### Example 1: Basic Usage with k8s_info

```yaml
- name: Audit network policies in user namespaces
  hosts: localhost
  tasks:
    - name: Get all namespaces
      kubernetes.core.k8s_info:
        kind: Namespace
      register: all_namespaces

    - name: Filter to user namespaces
      set_fact:
        user_namespace_names: "{{ all_namespaces.resources | filter_user_namespaces }}"

    - name: Display user namespaces
      debug:
        msg: "User namespaces: {{ user_namespace_names }}"
```

#### Example 2: Loop Through User Namespaces

```yaml
- name: Check network policies in user namespaces
  hosts: localhost
  tasks:
    - name: Get all namespaces
      kubernetes.core.k8s_info:
        kind: Namespace
      register: all_namespaces

    - name: Filter to user namespaces
      set_fact:
        user_namespaces: "{{ all_namespaces.resources | filter_user_namespaces }}"

    - name: Check for default-deny NetworkPolicy
      kubernetes.core.k8s_info:
        kind: NetworkPolicy
        name: default-deny-ingress
        namespace: "{{ item }}"
      loop: "{{ user_namespaces }}"
      register: network_policy_check
```

### Input Formats

The filter accepts:
- List of namespace objects with `metadata.name` field (k8s_info format)
- List of namespace objects with `name` field (alternative format)
- List of namespace name strings
- Mixed list of the above formats
- Empty list or None (returns empty list)

### Output

Returns a list of namespace name strings representing user namespaces.

### Requirements

This filter is used to satisfy requirements:
- **Requirement 1.1**: Retrieve all user namespaces excluding system namespaces
- **Requirement 1.5**: Exclude namespaces starting with `openshift-`, `kube-`, and the namespace named `default`

### Testing

Unit tests are available in `tests/test_namespace_filter.py`. Run tests with:

```bash
python3 tests/test_namespace_filter.py
```


## Filter: `parse_seccomp_compliance`

### Description

Parses a pod specification to determine seccomp profile compliance. Checks both pod-level and container-level security contexts for `seccompProfile.type` matching the required profile type (typically `RuntimeDefault`).

### Usage

```yaml
- name: Parse pod seccomp compliance
  set_fact:
    pod_compliance: "{{ pod_object | parse_seccomp_compliance('RuntimeDefault') }}"
```

### Input

- **pod**: Pod object (dict) with `spec` and `metadata` fields
- **required_profile_type**: Required seccomp profile type (e.g., 'RuntimeDefault')

### Output

Returns a dictionary with compliance information:

```yaml
{
  'namespace': 'my-app',
  'pod_name': 'my-pod-12345',
  'pod_seccomp': 'RuntimeDefault',  # or None if not set
  'container_seccomp': 'RuntimeDefault',  # or None if not set, or comma-separated if mixed
  'compliant': true  # or false
}
```

### Compliance Logic

A pod is considered compliant if:
1. Pod-level `securityContext.seccompProfile.type` is set to the required type, OR
2. All containers have `securityContext.seccompProfile.type` set to the required type

### Examples

#### Example 1: Audit All Pods for Seccomp Compliance

```yaml
- name: Audit seccomp profiles
  hosts: localhost
  tasks:
    - name: Get all pods from user namespaces
      kubernetes.core.k8s_info:
        kind: Pod
        namespace: "{{ item }}"
      loop: "{{ user_namespaces }}"
      register: pods_by_namespace

    - name: Flatten pod list
      set_fact:
        all_pods: "{{ pods_by_namespace.results | map(attribute='resources') | flatten }}"

    - name: Parse seccomp compliance for each pod
      set_fact:
        seccomp_gaps: >-
          {{
            all_pods
            | map('parse_seccomp_compliance', 'RuntimeDefault')
            | selectattr('compliant', 'equalto', false)
            | list
          }}

    - name: Display non-compliant pods
      debug:
        msg: "Non-compliant: {{ item.namespace }}/{{ item.pod_name }}"
      loop: "{{ seccomp_gaps }}"
```

#### Example 2: Check Single Pod

```yaml
- name: Check specific pod
  hosts: localhost
  tasks:
    - name: Get pod
      kubernetes.core.k8s_info:
        kind: Pod
        name: my-pod
        namespace: my-app
      register: pod_info

    - name: Check seccomp compliance
      set_fact:
        compliance: "{{ pod_info.resources[0] | parse_seccomp_compliance('RuntimeDefault') }}"

    - name: Display result
      debug:
        msg: |
          Pod: {{ compliance.pod_name }}
          Pod-level seccomp: {{ compliance.pod_seccomp | default('not set') }}
          Container-level seccomp: {{ compliance.container_seccomp | default('not set') }}
          Compliant: {{ compliance.compliant }}
```

### Requirements

This filter is used to satisfy requirements:
- **Requirement 3.1**: Retrieve all pods from all user namespaces
- **Requirement 3.2**: Check for `seccompProfile.type` set to `RuntimeDefault` in pod securityContext
- **Requirement 3.3**: Check for `seccompProfile.type` set to `RuntimeDefault` in container securityContext
- **Requirement 3.4**: Generate a report listing pods without RuntimeDefault seccomp profiles
- **Requirement 3.5**: Include namespace, pod name, and seccomp profile status

### Testing

Unit tests for both filters are available in `tests/test_namespace_filter.py`. Run tests with:

```bash
python3 tests/test_namespace_filter.py
```


## Filter: `extract_clusterrolebinding_details`

### Description

Extracts relevant details from a ClusterRoleBinding object, including the binding name, roleRef, and subject details. This filter is used for RBAC auditing to identify cluster-admin bindings.

### Usage

```yaml
- name: Extract ClusterRoleBinding details
  set_fact:
    binding_details: "{{ clusterrolebinding_object | extract_clusterrolebinding_details }}"
```

### Input

- **clusterrolebinding**: ClusterRoleBinding object (dict) with `metadata`, `roleRef`, and `subjects` fields

### Output

Returns a dictionary with extracted details:

```yaml
{
  'name': 'cluster-admin-binding',
  'roleRef': {
    'apiGroup': 'rbac.authorization.k8s.io',
    'kind': 'ClusterRole',
    'name': 'cluster-admin'
  },
  'subjects': [
    {
      'kind': 'User',
      'name': 'admin@example.com'
    },
    {
      'kind': 'ServiceAccount',
      'name': 'my-sa',
      'namespace': 'my-namespace'  # Only present for ServiceAccount subjects
    }
  ]
}
```

### Examples

#### Example 1: Extract Cluster-Admin Bindings

```yaml
- name: Audit cluster-admin bindings
  hosts: localhost
  tasks:
    - name: Get all ClusterRoleBindings
      kubernetes.core.k8s_info:
        kind: ClusterRoleBinding
      register: all_bindings

    - name: Filter for cluster-admin bindings
      set_fact:
        cluster_admin_bindings: >-
          {{
            all_bindings.resources
            | selectattr('roleRef.name', 'equalto', 'cluster-admin')
            | map('extract_clusterrolebinding_details')
            | list
          }}

    - name: Display cluster-admin bindings
      debug:
        msg: |
          Binding: {{ item.name }}
          Subjects:
          {% for subject in item.subjects %}
            - {{ subject.kind }}: {{ subject.name }}{% if subject.namespace is defined %} ({{ subject.namespace }}){% endif %}
          {% endfor %}
      loop: "{{ cluster_admin_bindings }}"
```

### Requirements

This filter is used to satisfy requirements:
- **Requirement 4.1**: Retrieve all ClusterRoleBindings with roleRef name `cluster-admin`
- **Requirement 4.5**: List all cluster-admin bindings with subject details


## Filter: `parse_wildcard_permissions`

### Description

Parses a ClusterRole to identify wildcard permissions (`*`) in apiGroups, resources, or verbs. This filter is used for RBAC auditing to identify overly permissive custom roles.

### Usage

```yaml
- name: Parse ClusterRole for wildcards
  set_fact:
    wildcard_analysis: "{{ clusterrole_object | parse_wildcard_permissions }}"
```

### Input

- **clusterrole**: ClusterRole object (dict) with `metadata` and `rules` fields

### Output

Returns a dictionary with wildcard analysis:

```yaml
{
  'name': 'overly-permissive-role',
  'has_wildcards': true,
  'wildcards': [
    {
      'field': 'apiGroups',
      'rule_index': 0
    },
    {
      'field': 'resources',
      'rule_index': 1
    },
    {
      'field': 'verbs',
      'rule_index': 1
    }
  ],
  'rules': [...]  # Original rules array for reference
}
```

### Examples

#### Example 1: Identify Custom Roles with Wildcard Permissions

```yaml
- name: Audit wildcard permissions
  hosts: localhost
  vars:
    system_roles:
      - cluster-admin
      - admin
      - edit
  tasks:
    - name: Get all ClusterRoles
      kubernetes.core.k8s_info:
        kind: ClusterRole
      register: all_roles

    - name: Filter to custom roles
      set_fact:
        custom_roles: >-
          {{
            all_roles.resources
            | rejectattr('metadata.name', 'in', system_roles)
            | list
          }}

    - name: Parse for wildcard permissions
      set_fact:
        wildcard_roles: >-
          {{
            custom_roles
            | map('parse_wildcard_permissions')
            | selectattr('has_wildcards', 'equalto', true)
            | list
          }}

    - name: Display roles with wildcards
      debug:
        msg: |
          Role: {{ item.name }}
          Wildcards found in:
          {% for wildcard in item.wildcards %}
            - Rule {{ wildcard.rule_index }}: {{ wildcard.field }}
          {% endfor %}
      loop: "{{ wildcard_roles }}"
```

#### Example 2: Generate RBAC Audit Report

```yaml
- name: Generate RBAC audit report
  hosts: localhost
  tasks:
    - name: Get all ClusterRoles
      kubernetes.core.k8s_info:
        kind: ClusterRole
      register: all_roles

    - name: Analyze all roles for wildcards
      set_fact:
        role_analysis: >-
          {{
            all_roles.resources
            | map('parse_wildcard_permissions')
            | list
          }}

    - name: Count roles with wildcards
      set_fact:
        wildcard_count: "{{ role_analysis | selectattr('has_wildcards', 'equalto', true) | length }}"

    - name: Display summary
      debug:
        msg: |
          Total ClusterRoles: {{ role_analysis | length }}
          Roles with wildcard permissions: {{ wildcard_count }}
```

### Requirements

This filter is used to satisfy requirements:
- **Requirement 4.2**: Identify custom roles containing wildcard characters in apiGroups, resources, or verbs
- **Requirement 4.3**: Exclude system roles named `cluster-admin`, `admin`, or `edit`
- **Requirement 4.5**: List all custom roles with wildcard permissions

### Testing

Unit tests for all filters are available in `tests/test_namespace_filter.py`. Run tests with:

```bash
python3 tests/test_namespace_filter.py
```

## Filter: `extract_sa_token_status`

### Description

Extracts service account token mounting status from a k8s_info query result. Determines compliance based on the `automountServiceAccountToken` field:
- **Compliant**: Field is explicitly set to `false`
- **Non-compliant**: Field is `true` or not set (null)

### Usage

```yaml
- name: Extract service account token status
  set_fact:
    sa_status: "{{ sa_check_result | extract_sa_token_status }}"
```

### Input

- **sa_check_result**: Result from k8s_info query for a service account (dict with 'resources' and 'item' keys)

### Output

Returns a dictionary with service account token status:

```yaml
{
  'namespace': 'my-app',
  'service_account': 'default',
  'automount_token': true,  # or false, or None if not set
  'compliant': false  # true only if automount_token is explicitly false
}
```

### Compliance Logic

A service account is considered compliant only if:
- The `automountServiceAccountToken` field is explicitly set to `false`

Non-compliant cases:
- Field is set to `true`
- Field is not present (null/None)

### Examples

#### Example 1: Audit Default Service Accounts in User Namespaces

```yaml
- name: Audit service account token mounting
  hosts: localhost
  tasks:
    - name: Get all namespaces
      kubernetes.core.k8s_info:
        kind: Namespace
      register: all_namespaces

    - name: Filter to user namespaces
      set_fact:
        user_namespaces: "{{ all_namespaces.resources | filter_user_namespaces }}"

    - name: Query for default service account in each namespace
      kubernetes.core.k8s_info:
        kind: ServiceAccount
        name: default
        namespace: "{{ item }}"
      loop: "{{ user_namespaces }}"
      register: sa_check

    - name: Extract token status and find non-compliant accounts
      set_fact:
        sa_token_gaps: >-
          {{
            sa_check.results
            | selectattr('resources', 'defined')
            | rejectattr('resources', 'eq', [])
            | map('extract_sa_token_status')
            | selectattr('compliant', 'equalto', false)
            | list
          }}

    - name: Display non-compliant service accounts
      debug:
        msg: |
          Namespace: {{ item.namespace }}
          Service Account: {{ item.service_account }}
          automountServiceAccountToken: {{ item.automount_token | default('not set') }}
      loop: "{{ sa_token_gaps }}"
```

#### Example 2: Generate Compliance Report

```yaml
- name: Service account compliance report
  hosts: localhost
  tasks:
    - name: Query service accounts
      kubernetes.core.k8s_info:
        kind: ServiceAccount
        name: default
        namespace: "{{ item }}"
      loop: "{{ user_namespaces }}"
      register: sa_check

    - name: Extract all statuses
      set_fact:
        all_sa_statuses: >-
          {{
            sa_check.results
            | selectattr('resources', 'defined')
            | rejectattr('resources', 'eq', [])
            | map('extract_sa_token_status')
            | list
          }}

    - name: Calculate compliance metrics
      set_fact:
        compliant_count: "{{ all_sa_statuses | selectattr('compliant', 'equalto', true) | length }}"
        non_compliant_count: "{{ all_sa_statuses | selectattr('compliant', 'equalto', false) | length }}"
        total_count: "{{ all_sa_statuses | length }}"

    - name: Display summary
      debug:
        msg: |
          Service Account Token Audit Summary
          ====================================
          Total service accounts: {{ total_count }}
          Compliant: {{ compliant_count }}
          Non-compliant: {{ non_compliant_count }}
```

### Requirements

This filter is used to satisfy requirements:
- **Requirement 5.1**: Retrieve all default service accounts from user namespaces
- **Requirement 5.2**: Check the `automountServiceAccountToken` field value
- **Requirement 5.3**: Mark as non-compliant if field is not set to `false`
- **Requirement 5.4**: Generate a report listing non-compliant service accounts
- **Requirement 5.5**: Include namespace, service account name, and token mounting status

### Testing

Unit tests for all filters are available in `tests/test_namespace_filter.py`. Run tests with:

```bash
python3 tests/test_namespace_filter.py
```


## Installation

These filters are automatically available when the playbook is executed, as they are located in the `roles/common/filter_plugins/` directory.

## Dependencies

- Python 3.6+
- No external Python packages required (uses only standard library)

