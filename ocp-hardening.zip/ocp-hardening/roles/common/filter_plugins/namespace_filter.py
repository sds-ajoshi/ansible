#!/usr/bin/env python3
"""
Custom Ansible filter plugins for OpenShift compliance auditing.

Filters:
1. filter_user_namespaces: Excludes system namespaces and returns only user namespaces.
   System namespaces are defined as:
   - Namespaces starting with 'openshift-'
   - Namespaces starting with 'kube-'
   - The 'default' namespace

2. parse_seccomp_compliance: Parses pod specifications to determine seccomp profile compliance.
   Checks both pod-level and container-level security contexts.

3. extract_clusterrolebinding_details: Extracts relevant details from ClusterRoleBinding objects.
   Returns name, roleRef, and subject details.

4. parse_wildcard_permissions: Parses ClusterRole rules to identify wildcard permissions.
   Identifies wildcards (*) in apiGroups, resources, or verbs.

5. extract_sa_token_status: Extracts service account token mounting status.
   Determines compliance based on automountServiceAccountToken field.
"""


class FilterModule(object):
    """Ansible filter plugin for namespace filtering and seccomp compliance parsing."""

    def filters(self):
        """Return the filter mapping."""
        return {
            'filter_user_namespaces': self.filter_user_namespaces,
            'parse_seccomp_compliance': self.parse_seccomp_compliance,
            'extract_clusterrolebinding_details': self.extract_clusterrolebinding_details,
            'parse_wildcard_permissions': self.parse_wildcard_permissions,
            'extract_sa_token_status': self.extract_sa_token_status
        }

    def filter_user_namespaces(self, namespaces):
        """
        Filter a list of namespaces to return only user namespaces.

        Excludes:
        - Namespaces starting with 'openshift-'
        - Namespaces starting with 'kube-'
        - The namespace named 'default'

        Args:
            namespaces: List of namespace objects (dicts with 'metadata.name')
                       or list of namespace name strings

        Returns:
            List of user namespace names (strings)
        """
        if not namespaces:
            return []

        user_namespaces = []

        for ns in namespaces:
            # Handle both namespace objects and string names
            if isinstance(ns, dict):
                # Extract name from namespace object
                if 'metadata' in ns and 'name' in ns['metadata']:
                    ns_name = ns['metadata']['name']
                elif 'name' in ns:
                    ns_name = ns['name']
                else:
                    # Skip malformed namespace objects
                    continue
            elif isinstance(ns, str):
                ns_name = ns
            else:
                # Skip unsupported types
                continue

            # Apply filtering logic
            if self._is_user_namespace(ns_name):
                user_namespaces.append(ns_name)

        return user_namespaces

    def _is_user_namespace(self, namespace_name):
        """
        Determine if a namespace is a user namespace.

        Args:
            namespace_name: String name of the namespace

        Returns:
            Boolean indicating if this is a user namespace
        """
        # Exclude namespaces starting with 'openshift-'
        if namespace_name.startswith('openshift-'):
            return False

        # Exclude namespaces starting with 'kube-'
        if namespace_name.startswith('kube-'):
            return False

        # Exclude the 'default' namespace
        if namespace_name == 'default':
            return False

        # All other namespaces are user namespaces
        return True

    def parse_seccomp_compliance(self, pod, required_profile_type):
        """
        Parse a pod specification to determine seccomp profile compliance.

        Checks both pod-level and container-level security contexts for
        seccompProfile.type matching the required profile type.

        Args:
            pod: Pod object (dict with spec and metadata)
            required_profile_type: Required seccomp profile type (e.g., 'RuntimeDefault')

        Returns:
            Dict with compliance information:
            {
                'namespace': str,
                'pod_name': str,
                'pod_seccomp': str or None,
                'container_seccomp': str or None,
                'compliant': bool
            }
        """
        if not isinstance(pod, dict):
            return {
                'namespace': 'unknown',
                'pod_name': 'unknown',
                'pod_seccomp': None,
                'container_seccomp': None,
                'compliant': False
            }

        # Extract pod metadata
        namespace = pod.get('metadata', {}).get('namespace', 'unknown')
        pod_name = pod.get('metadata', {}).get('name', 'unknown')

        # Check pod-level seccomp profile
        pod_spec = pod.get('spec', {})
        pod_security_context = pod_spec.get('securityContext', {})
        pod_seccomp_profile = pod_security_context.get('seccompProfile', {})
        pod_seccomp_type = pod_seccomp_profile.get('type')

        # Check container-level seccomp profiles
        containers = pod_spec.get('containers', [])
        container_seccomp_types = []
        
        for container in containers:
            container_security_context = container.get('securityContext', {})
            container_seccomp_profile = container_security_context.get('seccompProfile', {})
            container_seccomp_type = container_seccomp_profile.get('type')
            if container_seccomp_type:
                container_seccomp_types.append(container_seccomp_type)

        # Determine compliance
        # A pod is compliant if:
        # 1. Pod-level seccomp is set to required type, OR
        # 2. All containers have seccomp set to required type
        
        pod_level_compliant = (pod_seccomp_type == required_profile_type)
        
        # If there are containers with explicit seccomp settings, check them
        if container_seccomp_types:
            container_level_compliant = all(
                ctype == required_profile_type for ctype in container_seccomp_types
            )
        else:
            # No container-level settings, rely on pod-level
            container_level_compliant = False

        # Pod is compliant if either pod-level OR all container-level are compliant
        compliant = pod_level_compliant or (len(container_seccomp_types) > 0 and container_level_compliant)

        # Format container seccomp for display
        container_seccomp_display = None
        if container_seccomp_types:
            if len(set(container_seccomp_types)) == 1:
                container_seccomp_display = container_seccomp_types[0]
            else:
                container_seccomp_display = ', '.join(container_seccomp_types)

        return {
            'namespace': namespace,
            'pod_name': pod_name,
            'pod_seccomp': pod_seccomp_type,
            'container_seccomp': container_seccomp_display,
            'compliant': compliant
        }

    def extract_clusterrolebinding_details(self, clusterrolebinding):
        """
        Extract relevant details from a ClusterRoleBinding object.

        Args:
            clusterrolebinding: ClusterRoleBinding object (dict)

        Returns:
            Dict with extracted details:
            {
                'name': str,
                'roleRef': dict,
                'subjects': list of dicts
            }
        """
        if not isinstance(clusterrolebinding, dict):
            return {
                'name': 'unknown',
                'roleRef': {},
                'subjects': []
            }

        metadata = clusterrolebinding.get('metadata', {})
        name = metadata.get('name', 'unknown')
        
        roleRef = clusterrolebinding.get('roleRef', {})
        
        subjects = clusterrolebinding.get('subjects', [])
        
        # Extract relevant subject details
        subject_details = []
        for subject in subjects:
            subject_info = {
                'kind': subject.get('kind', 'unknown'),
                'name': subject.get('name', 'unknown')
            }
            # Add namespace if present (for ServiceAccount subjects)
            if 'namespace' in subject:
                subject_info['namespace'] = subject['namespace']
            subject_details.append(subject_info)

        return {
            'name': name,
            'roleRef': roleRef,
            'subjects': subject_details
        }

    def parse_wildcard_permissions(self, clusterrole):
        """
        Parse a ClusterRole to identify wildcard permissions.

        Checks rules for wildcard characters (*) in:
        - apiGroups
        - resources
        - verbs

        Args:
            clusterrole: ClusterRole object (dict)

        Returns:
            Dict with wildcard analysis:
            {
                'name': str,
                'has_wildcards': bool,
                'wildcards': list of dicts with 'field' and 'rule_index',
                'rules': list (original rules for reference)
            }
        """
        if not isinstance(clusterrole, dict):
            return {
                'name': 'unknown',
                'has_wildcards': False,
                'wildcards': [],
                'rules': []
            }

        metadata = clusterrole.get('metadata', {})
        name = metadata.get('name', 'unknown')
        
        rules = clusterrole.get('rules', [])
        
        wildcards = []
        
        for rule_index, rule in enumerate(rules):
            # Check apiGroups for wildcards
            api_groups = rule.get('apiGroups', [])
            if '*' in api_groups:
                wildcards.append({
                    'field': 'apiGroups',
                    'rule_index': rule_index
                })
            
            # Check resources for wildcards
            resources = rule.get('resources', [])
            if '*' in resources:
                wildcards.append({
                    'field': 'resources',
                    'rule_index': rule_index
                })
            
            # Check verbs for wildcards
            verbs = rule.get('verbs', [])
            if '*' in verbs:
                wildcards.append({
                    'field': 'verbs',
                    'rule_index': rule_index
                })

        return {
            'name': name,
            'has_wildcards': len(wildcards) > 0,
            'wildcards': wildcards,
            'rules': rules
        }

    def extract_sa_token_status(self, sa_check_result):
        """
        Extract service account token mounting status from k8s_info result.

        Determines compliance based on automountServiceAccountToken field:
        - Compliant: field is explicitly set to false
        - Non-compliant: field is true or not set (null)

        Args:
            sa_check_result: Result from k8s_info query for a service account
                           (dict with 'resources' and 'item' keys)

        Returns:
            Dict with service account token status:
            {
                'namespace': str,
                'service_account': str,
                'automount_token': bool or None,
                'compliant': bool
            }
        """
        if not isinstance(sa_check_result, dict):
            return {
                'namespace': 'unknown',
                'service_account': 'unknown',
                'automount_token': None,
                'compliant': False
            }

        # Extract namespace from the loop item
        namespace = sa_check_result.get('item', 'unknown')
        
        # Get the service account resource
        resources = sa_check_result.get('resources', [])
        
        if not resources or len(resources) == 0:
            # Service account doesn't exist in this namespace
            return {
                'namespace': namespace,
                'service_account': 'default',
                'automount_token': None,
                'compliant': False
            }
        
        # Get the first (and should be only) service account
        sa_resource = resources[0]
        
        # Extract service account name
        sa_name = sa_resource.get('metadata', {}).get('name', 'default')
        
        # Get automountServiceAccountToken field value
        # This field can be:
        # - true (explicit)
        # - false (explicit)
        # - not present (null/None)
        automount_token = sa_resource.get('automountServiceAccountToken')
        
        # Determine compliance
        # Compliant only if explicitly set to false
        # Non-compliant if true or not set (null)
        compliant = (automount_token is False)
        
        return {
            'namespace': namespace,
            'service_account': sa_name,
            'automount_token': automount_token,
            'compliant': compliant
        }
