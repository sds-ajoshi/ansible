#!/bin/bash
# Validation script for CIS OpenShift Ansible Error Handling Implementation
# This script verifies that comprehensive error handling is properly implemented

set -e

echo "=========================================="
echo "CIS OpenShift Error Handling Validation"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

# Function to check if a pattern exists in a file
check_pattern() {
    local file=$1
    local pattern=$2
    local description=$3
    
    if grep -q "$pattern" "$file" 2>/dev/null; then
        echo -e "${GREEN}✓${NC} $description"
        ((PASS_COUNT++))
        return 0
    else
        echo -e "${RED}✗${NC} $description"
        ((FAIL_COUNT++))
        return 1
    fi
}

# Function to check if a pattern exists in any file matching a glob
check_pattern_in_files() {
    local pattern=$1
    local glob=$2
    local description=$3
    
    if find . -path "$glob" -type f -exec grep -l "$pattern" {} \; 2>/dev/null | grep -q .; then
        echo -e "${GREEN}✓${NC} $description"
        ((PASS_COUNT++))
        return 0
    else
        echo -e "${RED}✗${NC} $description"
        ((FAIL_COUNT++))
        return 1
    fi
}

# Function to check if file exists
check_file_exists() {
    local file=$1
    local description=$2
    
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $description"
        ((PASS_COUNT++))
        return 0
    else
        echo -e "${RED}✗${NC} $description"
        ((FAIL_COUNT++))
        return 1
    fi
}

# Function to count occurrences
count_pattern() {
    local pattern=$1
    local glob=$2
    
    find . -path "$glob" -type f -exec grep -c "$pattern" {} \; 2>/dev/null | awk '{s+=$1} END {print s}'
}

echo "1. Checking Error Handling Infrastructure"
echo "----------------------------------------"

check_file_exists "filter_plugins/error_handling.py" "Error handling filter plugin exists"
check_file_exists "roles/common/tasks/error_handling.yml" "Common error handling tasks exist"
check_file_exists "roles/common/tasks/comprehensive_error_handler.yml" "Comprehensive error handler exists"
check_file_exists "roles/common/tasks/record_error.yml" "Record error task exists"
check_file_exists "roles/common/tasks/section_error_tracking.yml" "Section error tracking exists"
check_file_exists "roles/common/tasks/section_error_summary.yml" "Section error summary exists"
check_file_exists "playbooks/tasks/generate_error_summary.yml" "Final error summary task exists"
check_file_exists "ERROR_HANDLING.md" "Error handling documentation exists"

echo ""
echo "2. Checking Error Categorization"
echo "--------------------------------"

check_pattern "filter_plugins/error_handling.py" "def categorize_error" "categorize_error filter implemented"
check_pattern "filter_plugins/error_handling.py" "CONNECTION_ERROR" "CONNECTION_ERROR category defined"
check_pattern "filter_plugins/error_handling.py" "PERMISSION_ERROR" "PERMISSION_ERROR category defined"
check_pattern "filter_plugins/error_handling.py" "TIMEOUT_ERROR" "TIMEOUT_ERROR category defined"
check_pattern "filter_plugins/error_handling.py" "OPERATOR_MANAGED" "OPERATOR_MANAGED category defined"
check_pattern "filter_plugins/error_handling.py" "CONFIGURATION_ERROR" "CONFIGURATION_ERROR category defined"
check_pattern "filter_plugins/error_handling.py" "RESOURCE_NOT_FOUND" "RESOURCE_NOT_FOUND category defined"
check_pattern "filter_plugins/error_handling.py" "NOT_APPLICABLE" "NOT_APPLICABLE category defined"
check_pattern "filter_plugins/error_handling.py" "UNKNOWN_ERROR" "UNKNOWN_ERROR category defined"

echo ""
echo "3. Checking Custom Filters"
echo "--------------------------"

check_pattern "filter_plugins/error_handling.py" "def count_errors_by_type" "count_errors_by_type filter implemented"
check_pattern "filter_plugins/error_handling.py" "def format_error_summary" "format_error_summary filter implemented"
check_pattern "filter_plugins/error_handling.py" "def check_failure_threshold" "check_failure_threshold filter implemented"
check_pattern "filter_plugins/error_handling.py" "def generate_error_report" "generate_error_report filter implemented"
check_pattern "filter_plugins/error_handling.py" "def get_error_recovery_suggestion" "get_error_recovery_suggestion filter implemented"
check_pattern "filter_plugins/error_handling.py" "def is_critical_error" "is_critical_error filter implemented"
check_pattern "filter_plugins/error_handling.py" "def get_error_statistics" "get_error_statistics filter implemented"
check_pattern "filter_plugins/error_handling.py" "def get_section_errors" "get_section_errors filter implemented"

echo ""
echo "4. Checking Configuration Variables"
echo "-----------------------------------"

check_pattern "group_vars/all.yml" "continue_on_error" "continue_on_error variable defined"
check_pattern "group_vars/all.yml" "max_failures_per_section" "max_failures_per_section variable defined"
check_pattern "group_vars/all.yml" "halt_on_threshold" "halt_on_threshold variable defined"
check_pattern "group_vars/all.yml" "detailed_error_logging" "detailed_error_logging variable defined"
check_pattern "group_vars/all.yml" "save_error_report" "save_error_report variable defined"
check_pattern "group_vars/all.yml" "include_recovery_suggestions" "include_recovery_suggestions variable defined"
check_pattern "group_vars/all.yml" "fail_on_critical_errors" "fail_on_critical_errors variable defined"

echo ""
echo "5. Checking Block/Rescue/Always Structure in Audit Files"
echo "---------------------------------------------------------"

AUDIT_FILES=$(find roles -name "audit.yml" -type f | wc -l)
echo "Found $AUDIT_FILES audit files"

BLOCK_COUNT=$(count_pattern "^  block:" "./roles/*/tasks/audit.yml")
RESCUE_COUNT=$(count_pattern "^  rescue:" "./roles/*/tasks/audit.yml")
ALWAYS_COUNT=$(count_pattern "^  always:" "./roles/*/tasks/audit.yml")

echo "Block statements found: $BLOCK_COUNT"
echo "Rescue statements found: $RESCUE_COUNT"
echo "Always statements found: $ALWAYS_COUNT"

if [ "$BLOCK_COUNT" -gt 0 ] && [ "$RESCUE_COUNT" -gt 0 ]; then
    echo -e "${GREEN}✓${NC} Block/rescue structure implemented in audit files"
    ((PASS_COUNT++))
else
    echo -e "${RED}✗${NC} Block/rescue structure missing or incomplete"
    ((FAIL_COUNT++))
fi

echo ""
echo "6. Checking Error Recording in Rescue Blocks"
echo "--------------------------------------------"

check_pattern_in_files "error_type.*categorize_error" "./roles/*/tasks/audit.yml" "Error categorization used in rescue blocks"
check_pattern_in_files "status.*ERROR" "./roles/*/tasks/audit.yml" "ERROR status set in rescue blocks"
check_pattern_in_files "cis_results.*error" "./roles/*/tasks/audit.yml" "Errors recorded to cis_results"

echo ""
echo "7. Checking ignore_errors Usage"
echo "-------------------------------"

IGNORE_ERRORS_COUNT=$(count_pattern "ignore_errors.*yes" "./roles/*/tasks/audit.yml")
echo "ignore_errors: yes found $IGNORE_ERRORS_COUNT times"

if [ "$IGNORE_ERRORS_COUNT" -gt 0 ]; then
    echo -e "${GREEN}✓${NC} ignore_errors used to continue execution on failures"
    ((PASS_COUNT++))
else
    echo -e "${YELLOW}⚠${NC} ignore_errors not found (may be intentional)"
    ((WARN_COUNT++))
fi

echo ""
echo "8. Checking Error Recovery Suggestions"
echo "--------------------------------------"

check_pattern "filter_plugins/error_handling.py" "Verify OpenShift cluster is accessible" "CONNECTION_ERROR recovery suggestions defined"
check_pattern "filter_plugins/error_handling.py" "Verify service account has required permissions" "PERMISSION_ERROR recovery suggestions defined"
check_pattern "filter_plugins/error_handling.py" "Increase timeout value" "TIMEOUT_ERROR recovery suggestions defined"
check_pattern "filter_plugins/error_handling.py" "This configuration is managed by OpenShift operators" "OPERATOR_MANAGED recovery suggestions defined"

echo ""
echo "9. Checking Critical Error Detection"
echo "------------------------------------"

check_pattern "filter_plugins/error_handling.py" "def is_critical_error" "is_critical_error function implemented"
check_pattern "filter_plugins/error_handling.py" "critical_errors" "Critical errors tracked in reports"

echo ""
echo "10. Checking Section Error Tracking"
echo "-----------------------------------"

check_pattern "roles/common/tasks/section_error_summary.yml" "section_error_stats" "Section error statistics calculated"
check_pattern "roles/common/tasks/section_error_summary.yml" "section_error_report" "Section error report generated"
check_pattern "roles/common/tasks/section_error_summary.yml" "section_threshold_status" "Section threshold checked"

echo ""
echo "11. Checking Final Error Summary"
echo "--------------------------------"

check_pattern "playbooks/tasks/generate_error_summary.yml" "overall_error_stats" "Overall error statistics calculated"
check_pattern "playbooks/tasks/generate_error_summary.yml" "final_error_report" "Final error report generated"
check_pattern "playbooks/tasks/generate_error_summary.yml" "error_report_.*json" "Error report saved to JSON"
check_pattern "playbooks/tasks/generate_error_summary.yml" "error_statistics_.*json" "Error statistics saved to JSON"

echo ""
echo "12. Checking Documentation"
echo "-------------------------"

check_pattern "ERROR_HANDLING.md" "Error Categories" "Error categories documented"
check_pattern "ERROR_HANDLING.md" "Configuration" "Configuration variables documented"
check_pattern "ERROR_HANDLING.md" "Block/Rescue/Always" "Implementation patterns documented"
check_pattern "ERROR_HANDLING.md" "Custom Filters" "Custom filters documented"
check_pattern "ERROR_HANDLING.md" "Best Practices" "Best practices documented"
check_pattern "ERROR_HANDLING.md" "Troubleshooting" "Troubleshooting guide included"

echo ""
echo "=========================================="
echo "Validation Summary"
echo "=========================================="
echo -e "${GREEN}Passed:${NC} $PASS_COUNT"
echo -e "${RED}Failed:${NC} $FAIL_COUNT"
echo -e "${YELLOW}Warnings:${NC} $WARN_COUNT"
echo ""

TOTAL=$((PASS_COUNT + FAIL_COUNT))
if [ $TOTAL -gt 0 ]; then
    SUCCESS_RATE=$((PASS_COUNT * 100 / TOTAL))
    echo "Success Rate: $SUCCESS_RATE%"
    echo ""
fi

if [ $FAIL_COUNT -eq 0 ]; then
    echo -e "${GREEN}✓ All validation checks passed!${NC}"
    echo ""
    echo "Comprehensive error handling is properly implemented across all roles."
    echo "The system includes:"
    echo "  - Error categorization with 8 error types"
    echo "  - Block/rescue/always structure in audit tasks"
    echo "  - Section-level error tracking and thresholds"
    echo "  - Comprehensive error reporting and statistics"
    echo "  - Recovery suggestions for common errors"
    echo "  - Critical error detection and handling"
    echo "  - Complete documentation"
    exit 0
else
    echo -e "${RED}✗ Validation failed with $FAIL_COUNT errors${NC}"
    echo ""
    echo "Please review the failed checks above and ensure all error handling"
    echo "components are properly implemented."
    exit 1
fi
