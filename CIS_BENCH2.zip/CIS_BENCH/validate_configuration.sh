#!/bin/bash
# Comprehensive validation script for CIS OpenShift Ansible Automation
# Tests configuration, syntax, role references, tags, and variable precedence

echo "=========================================="
echo "CIS OpenShift Ansible Automation"
echo "Configuration Validation Script"
echo "=========================================="
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
TESTS_PASSED=0
TESTS_FAILED=0

# Function to print test result
print_result() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✓ PASS${NC}: $2"
        ((TESTS_PASSED++))
    else
        echo -e "${RED}✗ FAIL${NC}: $2"
        ((TESTS_FAILED++))
    fi
}

# Test 1: Check required files exist
echo "Test 1: Checking required files..."
FILES=(
    "ansible.cfg"
    "requirements.yml"
    "group_vars/all.yml"
    "inventory/hosts.example"
    ".gitignore"
    "playbooks/audit_l1.yml"
    "playbooks/audit_l2.yml"
    "playbooks/remediate_l1.yml"
    "playbooks/remediate_l2.yml"
    "playbooks/audit_and_remediate.yml"
)

for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        print_result 0 "File exists: $file"
    else
        print_result 1 "File missing: $file"
    fi
done

# Test 2: Check required directories exist
echo ""
echo "Test 2: Checking required directories..."
DIRS=(
    "roles"
    "roles/cis_section_1"
    "roles/cis_section_2"
    "roles/cis_section_3"
    "roles/cis_section_4"
    "roles/cis_section_5"
    "filter_plugins"
    "library"
    "playbooks"
    "inventory"
    "group_vars"
)

for dir in "${DIRS[@]}"; do
    if [ -d "$dir" ]; then
        print_result 0 "Directory exists: $dir"
    else
        print_result 1 "Directory missing: $dir"
    fi
done

# Test 3: Validate playbook syntax
echo ""
echo "Test 3: Validating playbook syntax..."
PLAYBOOKS=(
    "playbooks/audit_l1.yml"
    "playbooks/audit_l2.yml"
    "playbooks/remediate_l1.yml"
    "playbooks/remediate_l2.yml"
    "playbooks/audit_and_remediate.yml"
)

for playbook in "${PLAYBOOKS[@]}"; do
    if ansible-playbook --syntax-check "$playbook" > /dev/null 2>&1; then
        print_result 0 "Syntax valid: $playbook"
    else
        print_result 1 "Syntax error: $playbook"
    fi
done

# Test 4: Check role structure
echo ""
echo "Test 4: Checking role structure..."
SECTIONS=(1 2 3 4 5)

for section in "${SECTIONS[@]}"; do
    ROLE_DIR="roles/cis_section_${section}"
    
    # Check main.yml exists
    if [ -f "${ROLE_DIR}/tasks/main.yml" ]; then
        print_result 0 "Role main.yml exists: cis_section_${section}"
    else
        print_result 1 "Role main.yml missing: cis_section_${section}"
    fi
    
    # Check audit.yml exists
    if [ -f "${ROLE_DIR}/tasks/audit.yml" ]; then
        print_result 0 "Role audit.yml exists: cis_section_${section}"
    else
        print_result 1 "Role audit.yml missing: cis_section_${section}"
    fi
    
    # Check remediate.yml exists
    if [ -f "${ROLE_DIR}/tasks/remediate.yml" ]; then
        print_result 0 "Role remediate.yml exists: cis_section_${section}"
    else
        print_result 1 "Role remediate.yml missing: cis_section_${section}"
    fi
done

# Test 5: Verify tags are present
echo ""
echo "Test 5: Verifying tags in playbooks..."
EXPECTED_TAGS=("section1" "section2" "section3" "section4" "section5" "audit" "remediate" "level1")

for tag in "${EXPECTED_TAGS[@]}"; do
    if ansible-playbook playbooks/audit_l1.yml --list-tags 2>&1 | grep -q "$tag"; then
        print_result 0 "Tag found: $tag"
    else
        print_result 1 "Tag missing: $tag"
    fi
done

# Test 6: Check variable definitions
echo ""
echo "Test 6: Checking variable definitions in group_vars/all.yml..."
REQUIRED_VARS=(
    "cis_mode"
    "cis_level"
    "openshift_cluster_name"
    "openshift_base_domain"
    "report_output_dir"
    "report_format"
    "continue_on_error"
    "control_plane_group"
    "worker_node_group"
)

for var in "${REQUIRED_VARS[@]}"; do
    if grep -q "^${var}:" group_vars/all.yml; then
        print_result 0 "Variable defined: $var"
    else
        print_result 1 "Variable missing: $var"
    fi
done

# Test 7: Check .gitignore entries
echo ""
echo "Test 7: Checking .gitignore entries..."
GITIGNORE_ENTRIES=(
    "*.retry"
    "inventory/hosts"
    "cis_reports/"
    "*.log"
)

for entry in "${GITIGNORE_ENTRIES[@]}"; do
    if grep -q "$entry" .gitignore; then
        print_result 0 ".gitignore entry: $entry"
    else
        print_result 1 ".gitignore missing: $entry"
    fi
done

# Test 8: Verify role references in playbooks
echo ""
echo "Test 8: Verifying role references in playbooks..."
for section in "${SECTIONS[@]}"; do
    if grep -q "cis_section_${section}" playbooks/audit_l1.yml; then
        print_result 0 "Role referenced in audit_l1.yml: cis_section_${section}"
    else
        print_result 1 "Role not referenced in audit_l1.yml: cis_section_${section}"
    fi
done

# Test 9: Check filter plugins
echo ""
echo "Test 9: Checking filter plugins..."
if [ -f "filter_plugins/cis_filters.py" ]; then
    print_result 0 "Filter plugin exists: cis_filters.py"
else
    print_result 1 "Filter plugin missing: cis_filters.py"
fi

# Test 10: Verify ansible.cfg configuration
echo ""
echo "Test 10: Verifying ansible.cfg configuration..."
if grep -q "roles_path.*./roles" ansible.cfg; then
    print_result 0 "ansible.cfg: roles_path configured"
else
    print_result 1 "ansible.cfg: roles_path not configured"
fi

if grep -q "filter_plugins.*./filter_plugins" ansible.cfg; then
    print_result 0 "ansible.cfg: filter_plugins configured"
else
    print_result 1 "ansible.cfg: filter_plugins not configured"
fi

# Summary
echo ""
echo "=========================================="
echo "Validation Summary"
echo "=========================================="
echo -e "${GREEN}Tests Passed: ${TESTS_PASSED}${NC}"
echo -e "${RED}Tests Failed: ${TESTS_FAILED}${NC}"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}✓ All validation tests passed!${NC}"
    echo "The CIS OpenShift Ansible Automation is properly configured."
    exit 0
else
    echo -e "${YELLOW}⚠ Some validation tests failed.${NC}"
    echo "Please review the failures above and correct them."
    exit 1
fi
