# CIS Red Hat OpenShift Container Platform Ansible Automation

Comprehensive Ansible automation suite for auditing and remediating CIS Red Hat OpenShift Container Platform Benchmark v1.8.0 compliance controls.

## Overview

This automation suite provides both audit (verification) and remediation capabilities for CIS Benchmark Level 1 and Level 2 controls across OpenShift 4 clusters. It enables organizations to assess and enforce security compliance in a systematic, repeatable manner.

**🚀 New to this project? Start with the [Quick Start Guide](QUICK_START.md) for a condensed step-by-step checklist.**

### Key Features

- **Comprehensive Coverage**: All CIS Benchmark sections (Control Plane, etcd, Worker Nodes, Policies)
- **Dual Modes**: Audit-only or remediation modes
- **Level Support**: Level 1 (L1) and Level 2 (L2) compliance
- **Operator-Aware**: Respects OpenShift operator-managed configurations
- **Detailed Reporting**: JSON, YAML, and HTML report formats
- **Tag-Based Filtering**: Run specific sections or individual controls
- **Idempotent**: Safe to run multiple times
- **Error Resilient**: Continues execution despite individual task failures

## Prerequisites

### Required Software

- **Ansible**: Version 2.15 or later
- **Python**: Version 3.9 or later
- **OpenShift CLI (oc)**: Version 4.14 or later
- **jq**: JSON processor for parsing command outputs

### Required Ansible Collections

- `kubernetes.core` (>= 3.0.0)
- `community.general` (>= 8.0.0)

### OpenShift Cluster Access

- Access to OpenShift cluster with appropriate permissions
- Kubeconfig file or service account token
- Recommended: cluster-admin role or custom role with read/write permissions

### Required RBAC Permissions

The automation requires permissions to:
- Read all cluster resources (configmaps, pods, nodes, etc.)
- Read and modify policies (NetworkPolicies, SCCs, RBAC)
- Execute commands on nodes via `oc debug`
- Create and update MachineConfigs (for remediation)

### Example ClusterRole Definition

For audit-only operations, you can use a custom ClusterRole with read-only permissions:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: cis-audit-role
rules:
  # Read access to all resources for audit
  - apiGroups: ["*"]
    resources: ["*"]
    verbs: ["get", "list", "watch"]
  # Node debug access
  - apiGroups: [""]
    resources: ["nodes"]
    verbs: ["get", "list"]
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["create", "get", "list", "delete"]
  - apiGroups: [""]
    resources: ["pods/log"]
    verbs: ["get"]
  # Access to OpenShift config resources
  - apiGroups: ["config.openshift.io"]
    resources: ["*"]
    verbs: ["get", "list", "watch"]
  - apiGroups: ["operator.openshift.io"]
    resources: ["*"]
    verbs: ["get", "list", "watch"]
```

For remediation operations, additional write permissions are required:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: cis-remediation-role
rules:
  # Include all audit permissions
  - apiGroups: ["*"]
    resources: ["*"]
    verbs: ["get", "list", "watch"]
  # Write access for remediation
  - apiGroups: [""]
    resources: ["networkpolicies", "resourcequotas", "serviceaccounts"]
    verbs: ["create", "update", "patch", "delete"]
  - apiGroups: ["networking.k8s.io"]
    resources: ["networkpolicies"]
    verbs: ["create", "update", "patch", "delete"]
  - apiGroups: ["security.openshift.io"]
    resources: ["securitycontextconstraints"]
    verbs: ["create", "update", "patch"]
  - apiGroups: ["machineconfiguration.openshift.io"]
    resources: ["kubeletconfigs", "machineconfigs"]
    verbs: ["create", "update", "patch"]
  - apiGroups: ["config.openshift.io"]
    resources: ["apiservers", "oauths"]
    verbs: ["get", "list", "patch", "update"]
  # Node debug access
  - apiGroups: [""]
    resources: ["nodes", "pods", "pods/log"]
    verbs: ["*"]
```

Create a ServiceAccount and bind the role:

```bash
# Create service account
oc create serviceaccount cis-automation -n default

# For audit-only
oc create clusterrolebinding cis-audit-binding \
  --clusterrole=cis-audit-role \
  --serviceaccount=default:cis-automation

# For remediation (use cluster-admin or custom role)
oc adm policy add-cluster-role-to-user cluster-admin \
  system:serviceaccount:default:cis-automation
```

## Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd cis-openshift-ansible
```

### 2. Install Ansible Collections

```bash
ansible-galaxy collection install -r requirements.yml
```

### 3. Configure Inventory

```bash
cp inventory/hosts.example inventory/hosts
```

Edit `inventory/hosts` with your OpenShift cluster details:

```ini
[masters]
master-0.ocp.example.com
master-1.ocp.example.com
master-2.ocp.example.com

[workers]
worker-0.ocp.example.com
worker-1.ocp.example.com
worker-2.ocp.example.com
```

### 4. Configure Variables

Edit `group_vars/all.yml` to customize settings:

```yaml
# Set your cluster details
openshift_cluster_name: "ocp-cluster"
openshift_base_domain: "example.com"

# Configure execution mode
cis_mode: "audit"  # or "remediate" or "both"
cis_level: 1       # or 2

# Set report output location
report_output_dir: "./cis_reports"
```

### 5. Verify OpenShift Access

```bash
oc whoami
oc get nodes
```

## Quick Start

### Run Level 1 Audit

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
```

### Run Level 2 Audit

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l2.yml
```

### Run Level 1 Remediation (Dry-Run)

```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml -e remediation_dry_run=true
```

### Run Level 1 Remediation

```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml
```

## Usage Examples

### Basic Execution Modes

#### Audit-Only Mode

Run Level 1 audit without making any changes:
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
```

Run Level 2 audit (includes all L1 + L2 controls):
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l2.yml
```

#### Remediation-Only Mode

Apply Level 1 remediations:
```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml
```

Apply Level 2 remediations (includes all L1 + L2):
```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l2.yml
```

#### Combined Mode

Run audit followed by remediation:
```bash
ansible-playbook -i inventory/hosts playbooks/audit_and_remediate.yml
```

### Tag-Based Filtering

#### Run Specific Section

Run only Section 1 (Control Plane Components):
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1
```

Run only Section 5 (Policies):
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section5
```

#### Run Specific Subsection

Run only Section 1.2 (API Server):
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1.2
```

Run only Section 5.1 (RBAC and Service Accounts):
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section5.1
```

#### Run Specific Control

Run only control 1.1.1:
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_1.1.1
```

Run only control 5.1.5:
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_5.1.5
```

#### Run Multiple Sections

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags "section1,section2,section3"
```

#### Run Multiple Controls

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags "control_1.1.1,control_1.1.2,control_1.1.3"
```

### Custom Variable Overrides

#### Change CIS Level

```bash
# Run L2 audit using L1 playbook
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e cis_level=2
```

#### Change Report Format

```bash
# Generate YAML report
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_format=yaml

# Generate HTML report
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_format=html
```

#### Change Report Location

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  -e report_output_dir=/tmp/cis_reports
```

#### Multiple Variable Overrides

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  -e cis_level=2 \
  -e report_format=yaml \
  -e report_output_dir=/tmp/reports \
  -e verbose_output=true
```

### Dry-Run and Testing

#### Remediation Dry-Run

Test what would be changed without applying:
```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml \
  -e remediation_dry_run=true
```

#### Ansible Check Mode

Validate playbook without execution:
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --check
```

#### Syntax Validation

```bash
ansible-playbook playbooks/audit_l1.yml --syntax-check
```

### Verbose Output

#### Standard Verbosity

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -v
```

#### Detailed Verbosity

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -vv
```

#### Debug Level Verbosity

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -vvv
```

### Advanced Usage

#### Run Against Specific Hosts

```bash
# Run only against master nodes
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --limit masters

# Run only against worker nodes
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --limit workers

# Run against specific host
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --limit master-0.ocp.example.com
```

#### Skip Specific Tags

```bash
# Skip Section 1
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --skip-tags section1

# Skip manual controls
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --skip-tags manual
```

#### List Available Tags

```bash
ansible-playbook playbooks/audit_l1.yml --list-tags
```

#### List Tasks

```bash
ansible-playbook playbooks/audit_l1.yml --list-tasks
```

### Production Workflow Example

Complete workflow for production compliance:

```bash
# Step 1: Run audit in test environment
ansible-playbook -i inventory/hosts.test playbooks/audit_l1.yml

# Step 2: Review audit report
cat ./cis_reports/cis_audit_report_*.json | jq '.summary'

# Step 3: Test remediation in test environment (dry-run)
ansible-playbook -i inventory/hosts.test playbooks/remediate_l1.yml \
  -e remediation_dry_run=true

# Step 4: Apply remediation in test environment
ansible-playbook -i inventory/hosts.test playbooks/remediate_l1.yml

# Step 5: Verify remediation worked
ansible-playbook -i inventory/hosts.test playbooks/audit_l1.yml

# Step 6: Apply to production (one section at a time)
ansible-playbook -i inventory/hosts.prod playbooks/remediate_l1.yml --tags section5
ansible-playbook -i inventory/hosts.prod playbooks/remediate_l1.yml --tags section3

# Step 7: Final production audit
ansible-playbook -i inventory/hosts.prod playbooks/audit_l1.yml
```

## Available Playbooks

| Playbook | Description | CIS Level | Mode |
|----------|-------------|-----------|------|
| `audit_l1.yml` | Audit Level 1 controls | L1 | Audit only |
| `audit_l2.yml` | Audit Level 1 and Level 2 controls | L1 + L2 | Audit only |
| `remediate_l1.yml` | Remediate Level 1 controls | L1 | Remediation only |
| `remediate_l2.yml` | Remediate Level 1 and Level 2 controls | L1 + L2 | Remediation only |
| `audit_and_remediate.yml` | Combined audit and remediation | Configurable | Both |

## CIS Sections Coverage

- **Section 1**: Control Plane Components (API Server, Controller Manager, Scheduler)
- **Section 2**: etcd Configuration
- **Section 3**: Control Plane Configuration (Authentication, Logging)
- **Section 4**: Worker Nodes (Kubelet Configuration)
- **Section 5**: Policies (RBAC, SCCs, Network Policies, Secrets)

## Configuration Variables

Key variables in `group_vars/all.yml`:

### Execution Control

- `cis_mode`: Execution mode (`audit`, `remediate`, `both`)
- `cis_level`: Compliance level (`1` or `2`)
- `skip_operator_managed`: Skip operator-managed configurations (default: `true`)

### OpenShift Connection

- `openshift_api_url`: OpenShift API endpoint
- `openshift_kubeconfig`: Path to kubeconfig file
- `openshift_validate_certs`: Validate SSL certificates (default: `true`)

### Reporting

- `report_output_dir`: Report output directory (default: `./cis_reports`)
- `report_format`: Report format (`json`, `yaml`, `html`)
- `report_include_details`: Include detailed results (default: `true`)

### Remediation

- `remediation_dry_run`: Dry-run mode (default: `false`)
- `remediation_backup_enabled`: Backup before changes (default: `true`)

## Reports

Reports are generated in the specified `report_output_dir` with the following structure:

```json
{
  "execution_timestamp": "2025-11-13T10:30:00Z",
  "openshift_version": "4.15.2",
  "cis_benchmark_version": "1.8.0",
  "level": "L1",
  "mode": "audit",
  "summary": {
    "total_controls": 95,
    "passed": 78,
    "failed": 12,
    "manual": 5,
    "errors": 0
  },
  "results_by_section": {
    "section_1": { "passed": 25, "failed": 3, "manual": 2 }
  },
  "detailed_results": [...]
}
```

## Troubleshooting

### Authentication Issues

**Problem**: Cannot connect to OpenShift cluster

**Solution**:
```bash
# Verify oc CLI access
oc whoami
oc cluster-info

# Check kubeconfig
echo $KUBECONFIG
export KUBECONFIG=/path/to/kubeconfig

# Test API connectivity
oc get nodes
```

**Problem**: Token expired or invalid

**Solution**:
```bash
# Re-login to OpenShift
oc login https://api.cluster.example.com:6443

# Or use service account token
oc sa get-token cis-automation -n default
```

### Permission Errors

**Problem**: "Forbidden" or "Unauthorized" errors during audit

**Solution**:
```bash
# Check current permissions
oc auth can-i get configmaps -n openshift-kube-apiserver
oc auth can-i list pods --all-namespaces

# Verify service account permissions
oc adm policy who-can get configmaps -n openshift-kube-apiserver

# Grant necessary permissions (cluster-admin for full access)
oc adm policy add-cluster-role-to-user cluster-admin <username>
```

### Node Access Issues

**Problem**: Cannot access nodes via `oc debug`

**Solution**:
```bash
# Test node debug access
oc debug node/master-0.ocp.example.com -- chroot /host ls /etc/kubernetes

# Verify node status
oc get nodes

# Check if debug pods are allowed
oc get scc privileged -o yaml | grep -A 5 users
```

**Problem**: "Error from server (Forbidden): nodes is forbidden"

**Solution**: Ensure your user/service account has permissions to create privileged pods and access nodes.

### Collection Not Found

**Problem**: "ERROR! couldn't resolve module/action 'kubernetes.core.k8s'"

**Solution**:
```bash
# Install required collections
ansible-galaxy collection install -r requirements.yml --force

# Verify installation
ansible-galaxy collection list | grep kubernetes.core
```

### Syntax Check

**Problem**: Want to validate playbook syntax before execution

**Solution**:
```bash
# Check syntax
ansible-playbook playbooks/audit_l1.yml --syntax-check

# Dry-run (check mode)
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --check
```

### Slow Execution

**Problem**: Playbook takes too long to complete

**Solution**:
```bash
# Run specific sections only
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1

# Enable parallel execution (already enabled by default)
# Adjust in group_vars/all.yml:
# parallel_node_checks: true
# max_parallel_tasks: 10

# Reduce verbosity
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
```

### Report Generation Issues

**Problem**: Reports not generated or empty

**Solution**:
```bash
# Check report output directory exists and is writable
ls -la ./cis_reports/

# Create directory if missing
mkdir -p ./cis_reports

# Check for errors in playbook output
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -v
```

### Version Detection Issues

**Problem**: Incorrect OpenShift version detected

**Solution**:
```bash
# Manually set version in group_vars/all.yml
openshift_version: "4.15.2"

# Or pass as extra var
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  -e openshift_version=4.15.2
```

### Task Failures

**Problem**: Multiple tasks failing with errors

**Solution**:
```bash
# Enable detailed error logging
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -vvv

# Check error report (if save_error_report: true)
cat ./cis_reports/error_report_*.json

# Review specific task output
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  --tags control_1.1.1 -vvv
```

### Remediation Not Applied

**Problem**: Remediation tasks run but changes not applied

**Solution**:
```bash
# Verify remediation mode is set
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml \
  -e cis_mode=remediate

# Check if dry-run is enabled
# In group_vars/all.yml: remediation_dry_run: false

# Verify operator-managed settings are not being skipped
# In group_vars/all.yml: skip_operator_managed: false (not recommended)

# Check MachineConfig status for kubelet changes
oc get machineconfigs
oc get machineconfigpools
```

### Common Error Messages

| Error Message | Cause | Solution |
|---------------|-------|----------|
| "jq: command not found" | jq not installed | Install jq: `yum install jq` or `apt-get install jq` |
| "oc: command not found" | OpenShift CLI not in PATH | Install oc CLI and add to PATH |
| "Failed to connect to the host" | Network/firewall issue | Check network connectivity and firewall rules |
| "The connection to the server was refused" | API server not accessible | Verify API URL and kubeconfig |
| "error: You must be logged in" | Not authenticated | Run `oc login` or set KUBECONFIG |
| "Operator-managed, no remediation available" | Expected behavior | This is informational, not an error |

## Important Notes

### Operator-Managed Configurations

OpenShift 4 uses operators to manage most cluster configurations. Manual changes to operator-managed settings will cause degraded cluster state. This automation:

- Identifies operator-managed configurations during audit
- Skips remediation for operator-managed settings by default
- Provides guidance on proper configuration methods

**Why Operator-Managed Settings Cannot Be Remediated:**

1. **Automatic Reversion**: Operators continuously reconcile configurations. Manual changes are automatically reverted within minutes.
2. **Cluster Degradation**: Modifying operator-managed files causes operators to report degraded status.
3. **Unsupported Configuration**: Manual changes void support and may cause unpredictable behavior.
4. **Proper Configuration Methods**: Use operator CRDs and APIs instead:
   - API Server settings: Modify `APIServer` resource
   - Kubelet settings: Use `KubeletConfig` resource
   - Network settings: Use `Network` operator configuration
   - Authentication: Configure `OAuth` resource

**Examples of Operator-Managed Settings:**
- File permissions on `/etc/kubernetes/manifests/*.yaml`
- API server arguments in configmaps
- etcd configuration
- Kubelet service files
- Certificate and key files

### Non-Remediable Controls

Some CIS controls cannot be automated or should not be remediated:

| Control Type | Examples | Reason |
|--------------|----------|--------|
| **Operator-Managed** | File permissions, API server args | Automatically managed by operators |
| **Manual Policy** | RBAC reviews, secret access | Requires organizational decisions |
| **Manual Configuration** | Identity providers, log forwarding | Requires external system integration |
| **Not Applicable** | CNI file permissions | OpenShift uses integrated CNI |

These controls are marked as "MANUAL", "NOT_REMEDIABLE", or "OPERATOR_MANAGED" in reports.

### Testing Recommendations

1. **Test in non-production first**: Always test in dev/test environments
   ```bash
   # Use test cluster inventory
   ansible-playbook -i inventory/hosts.test playbooks/audit_l1.yml
   ```

2. **Review audit results**: Understand failures before remediation
   ```bash
   # Run audit first
   ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
   
   # Review report
   cat ./cis_reports/cis_audit_report_*.json | jq '.summary'
   ```

3. **Use dry-run mode**: Test remediation without applying changes
   ```bash
   ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml \
     -e remediation_dry_run=true
   ```

4. **Backup configurations**: Enable automatic backups
   ```yaml
   # In group_vars/all.yml
   remediation_backup_enabled: true
   ```

5. **Monitor cluster health**: Watch for degraded operators after remediation
   ```bash
   # Check operator status
   oc get clusteroperators
   
   # Watch for degraded state
   watch -n 5 'oc get co | grep -v "True.*False.*False"'
   ```

6. **Start with specific sections**: Test one section at a time
   ```bash
   # Test Section 5 (Policies) first - safest
   ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section5
   
   # Then Section 3 (Authentication/Logging)
   ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section3
   ```

7. **Review changes before applying**: Use check mode
   ```bash
   ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --check --diff
   ```

## Version Compatibility

- **OpenShift 4.14+**: Full support
- **OpenShift 4.13**: Supported with minor differences
- **OpenShift 4.12 and earlier**: Limited support

Version-specific behaviors are automatically detected and handled.

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.

Quick guidelines:

1. Follow existing code structure and naming conventions
2. Add appropriate tags to new tasks (section, control, level, mode)
3. Include CIS control references in task names and comments
4. Implement proper error handling with block/rescue
5. Update documentation for new features
6. Test against multiple OpenShift versions
7. Document operator-managed configurations

For detailed information on:
- Task naming conventions
- Inline comment structure
- Error handling patterns
- Testing requirements
- Pull request process

Please refer to the [Contributing Guide](CONTRIBUTING.md).

## License

[Specify your license here]

## Documentation

📚 **[Complete Documentation Index](DOCUMENTATION_INDEX.md)** - Full index of all documentation

### Getting Started
- **[Quick Start Guide](QUICK_START.md)**: 5-minute setup with condensed step-by-step checklist ⚡

### Main Documentation
- **[FAQ](FAQ.md)**: Frequently asked questions and answers
- **[Contributing Guide](CONTRIBUTING.md)**: Guidelines for contributing to the project
- **[Error Handling Guide](ERROR_HANDLING.md)**: Comprehensive error handling, categorization, and recovery
- **[Reporting Guide](REPORTING.md)**: Report formats, interpretation, and integration
- **[RBAC Examples](rbac-examples/README.md)**: ClusterRole and ServiceAccount configurations for audit and remediation

### Role-Specific Documentation
- [Section 1: Control Plane Components](roles/cis_section_1/README.md)
- [Section 2: etcd](roles/cis_section_2/README.md)
- [Section 3: Control Plane Configuration](roles/cis_section_3/README.md)
- [Section 4: Worker Nodes](roles/cis_section_4/README.md)
- [Section 5: Policies](roles/cis_section_5/README.md)

## References

- [CIS Red Hat OpenShift Container Platform Benchmark v1.8.0](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift Security Documentation](https://docs.openshift.com/container-platform/latest/security/)
- [Ansible Documentation](https://docs.ansible.com/)
- [kubernetes.core Collection](https://docs.ansible.com/ansible/latest/collections/kubernetes/core/)

## Support

For issues, questions, or contributions, please [open an issue](link-to-issues) or contact the maintainers.
