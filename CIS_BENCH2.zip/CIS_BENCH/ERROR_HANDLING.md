# CIS OpenShift Ansible Automation - Error Handling Guide

## Overview

This document describes the comprehensive error handling system implemented across all CIS compliance automation roles. The error handling system ensures that individual task failures do not halt playbook execution while providing detailed error categorization, tracking, and reporting.

## Error Handling Architecture

### Components

1. **Error Categorization** - Automatic classification of errors into predefined types
2. **Error Tracking** - Section-level and global error counting with configurable thresholds
3. **Error Recovery** - Suggestions for resolving common error types
4. **Error Reporting** - Comprehensive error summaries and detailed reports

### Error Categories

The system categorizes errors into the following types:

| Error Type | Description | Critical | Common Causes |
|------------|-------------|----------|---------------|
| `CONNECTION_ERROR` | Unable to connect to OpenShift cluster or nodes | Yes | Network issues, cluster down, invalid kubeconfig |
| `PERMISSION_ERROR` | Insufficient permissions to execute operation | Yes | Missing RBAC permissions, invalid credentials |
| `TIMEOUT_ERROR` | Operation exceeded timeout limit | Yes | Slow cluster, network latency, resource contention |
| `OPERATOR_MANAGED` | Configuration is managed by OpenShift operators | No | Attempting to modify operator-controlled settings |
| `CONFIGURATION_ERROR` | Invalid or malformed configuration | No | Syntax errors, missing fields, invalid values |
| `RESOURCE_NOT_FOUND` | Requested resource does not exist | No | Typo in resource name, resource deleted, wrong namespace |
| `NOT_APPLICABLE` | Control does not apply to this environment | No | Version incompatibility, feature not enabled |
| `UNKNOWN_ERROR` | Unclassified error | No | Unexpected failures, new error patterns |

## Configuration

### Error Handling Variables

Configure error handling behavior in `group_vars/all.yml`:

```yaml
# Continue execution on task errors
continue_on_error: true

# Maximum failures per section (0 = unlimited)
max_failures_per_section: 0

# Halt execution when threshold exceeded
halt_on_threshold: false

# Enable detailed error logging
detailed_error_logging: true

# Save error report to file
save_error_report: true

# Include recovery suggestions
include_recovery_suggestions: true

# Fail playbook on critical errors
fail_on_critical_errors: false

# Task retry configuration
task_retry_count: 0
task_retry_delay: 5
```

### Threshold Configuration

Set failure thresholds per section to control execution flow:

```yaml
# Example: Stop section after 5 failures
max_failures_per_section: 5
halt_on_threshold: true
```

## Implementation Patterns

### Block/Rescue/Always Structure

All audit tasks follow this pattern:

```yaml
- name: "CIS X.Y.Z - Control description"
  block:
    - name: "Execute audit check"
      shell: |
        # Audit command
      register: audit_result
      failed_when: false
      changed_when: false

    - name: "Record result"
      set_fact:
        cis_results: "{{ cis_results + [result] }}"
      vars:
        result:
          control: "X.Y.Z"
          title: "Control description"
          level: "L1"
          status: "{{ 'PASS' if condition else 'FAIL' }}"
          message: "Result message"
          expected: "Expected value"
          actual: "{{ audit_result.stdout }}"
          timestamp: "{{ ansible_date_time.iso8601 }}"

  rescue:
    - name: "Handle error"
      set_fact:
        cis_results: "{{ cis_results + [error_result] }}"
      vars:
        error_result:
          control: "X.Y.Z"
          title: "Control description"
          level: "L1"
          status: "ERROR"
          error_type: "{{ error_message | categorize_error(error_stderr) }}"
          message: "{{ ansible_failed_result.msg | default('Unknown error') }}"
          expected: "Expected value"
          actual: "N/A"
          timestamp: "{{ ansible_date_time.iso8601 }}"

  tags:
    - sectionX
    - control_X.Y.Z
    - level1
    - audit
```

### Using Common Error Handling Tasks

Include reusable error handling tasks:

```yaml
# At the start of a section
- name: "Initialize section error tracking"
  include_tasks: roles/common/tasks/section_error_tracking.yml
  vars:
    section_name: "Section 1"

# In rescue blocks
- name: "Record error"
  include_tasks: roles/common/tasks/record_error.yml
  vars:
    control_id: "1.1.1"
    control_title: "Control description"
    control_level: "L1"
    error_message: "{{ ansible_failed_result.msg }}"
    expected_value: "600"

# At the end of a section
- name: "Generate section error summary"
  include_tasks: roles/common/tasks/section_error_tracking.yml
  vars:
    section_name: "Section 1"
```

### Ignore Errors Pattern

Use `ignore_errors: yes` on audit tasks to continue execution:

```yaml
- name: "CIS X.Y.Z - Audit task"
  block:
    # Task implementation
  rescue:
    # Error handling
  tags:
    - audit
  ignore_errors: yes
```

## Error Reporting

### Automatic Error Summary

Error summaries are automatically generated at playbook completion:

```
================================================================================
CIS OpenShift Compliance - Error Summary
================================================================================
Execution Time: 2025-11-14T10:30:00Z
CIS Level: L1
Mode: audit
================================================================================

Error Statistics:
  Total Controls Checked: 95
  Total Errors: 12
  Critical Errors: 2
  Error Rate: 12.63%
  
Errors by Type:
  - CONNECTION_ERROR: 2
  - PERMISSION_ERROR: 1
  - OPERATOR_MANAGED: 5
  - CONFIGURATION_ERROR: 2
  - RESOURCE_NOT_FOUND: 1
  - UNKNOWN_ERROR: 1

Errors by Level:
  - Level 1: 10
  - Level 2: 2

Sections with Errors: 1, 2, 4

Most Common Error Type: OPERATOR_MANAGED
```

### Error Report Files

When `save_error_report: true`, the following files are generated:

1. **error_report_<timestamp>.json** - Detailed error information
2. **error_statistics_<timestamp>.json** - Error statistics and metrics

### Error Report Structure

```json
{
  "total_errors": 12,
  "errors_by_type": {
    "CONNECTION_ERROR": 2,
    "PERMISSION_ERROR": 1,
    "OPERATOR_MANAGED": 5
  },
  "errors_by_section": {
    "section_1": [
      {
        "control": "1.1.1",
        "title": "Control description",
        "error_type": "CONNECTION_ERROR",
        "message": "Error details"
      }
    ]
  },
  "critical_errors": [
    {
      "control": "1.1.1",
      "error_type": "CONNECTION_ERROR",
      "message": "Unable to connect to cluster"
    }
  ],
  "summary": "Total Errors: 12\nCritical Errors: 2\n..."
}
```

## Error Recovery

### Automatic Recovery Suggestions

When `include_recovery_suggestions: true`, errors include recovery guidance:

```yaml
error_result:
  control: "1.1.1"
  error_type: "CONNECTION_ERROR"
  message: "Unable to connect to cluster"
  recovery_suggestions:
    - "Verify OpenShift cluster is accessible"
    - "Check network connectivity to the cluster"
    - "Verify kubeconfig is valid and not expired"
    - "Ensure oc CLI is properly configured"
```

### Common Error Resolutions

#### CONNECTION_ERROR

1. Verify cluster accessibility:
   ```bash
   oc cluster-info
   oc get nodes
   ```

2. Check kubeconfig:
   ```bash
   echo $KUBECONFIG
   oc config view
   ```

3. Test network connectivity:
   ```bash
   ping api.cluster.example.com
   curl -k https://api.cluster.example.com:6443/healthz
   ```

#### PERMISSION_ERROR

1. Check current user permissions:
   ```bash
   oc whoami
   oc auth can-i --list
   ```

2. Verify service account permissions:
   ```bash
   oc get clusterrolebindings | grep <service-account>
   oc describe clusterrole <role-name>
   ```

3. Grant required permissions:
   ```bash
   oc adm policy add-cluster-role-to-user cluster-admin <user>
   ```

#### OPERATOR_MANAGED

1. Check operator status:
   ```bash
   oc get co
   oc describe co <operator-name>
   ```

2. Use operator CRDs for configuration:
   ```bash
   oc get <crd-type>
   oc edit <crd-type> <resource-name>
   ```

3. Review operator documentation for proper configuration methods

## Threshold Management

### Section-Level Thresholds

Configure maximum failures per section:

```yaml
# Stop section after 10 failures
max_failures_per_section: 10
halt_on_threshold: true
```

### Threshold Behavior

- **Threshold = 0**: No limit, all tasks execute regardless of failures
- **Threshold > 0**: Section halts after reaching threshold (if `halt_on_threshold: true`)
- **Threshold exceeded**: Warning logged, execution continues (if `halt_on_threshold: false`)

### Checking Threshold Status

```yaml
- name: "Check threshold"
  set_fact:
    threshold_status: "{{ cis_results | check_failure_threshold(max_failures_per_section, 'Section 1') }}"

- name: "Display threshold status"
  debug:
    msg: "{{ threshold_status.message }}"
```

## Custom Filters

### Available Filters

| Filter | Purpose | Usage |
|--------|---------|-------|
| `categorize_error` | Classify error type | `{{ error_msg \| categorize_error(stderr) }}` |
| `count_errors_by_type` | Count errors by category | `{{ results \| count_errors_by_type }}` |
| `format_error_summary` | Format error summary | `{{ results \| format_error_summary('Section 1') }}` |
| `check_failure_threshold` | Check threshold status | `{{ results \| check_failure_threshold(10, 'Section 1') }}` |
| `get_section_errors` | Get errors for section | `{{ results \| get_section_errors('1') }}` |
| `generate_error_report` | Generate full report | `{{ results \| generate_error_report }}` |
| `is_critical_error` | Check if error is critical | `{{ error_type \| is_critical_error }}` |
| `get_error_recovery_suggestion` | Get recovery steps | `{{ error_type \| get_error_recovery_suggestion }}` |
| `get_error_statistics` | Get error statistics | `{{ results \| get_error_statistics }}` |

### Filter Examples

```yaml
# Categorize an error
- set_fact:
    error_type: "{{ error_message | categorize_error(stderr_output) }}"

# Count errors by type
- set_fact:
    error_counts: "{{ cis_results | count_errors_by_type }}"

# Generate error summary
- debug:
    msg: "{{ cis_results | format_error_summary('Section 1') }}"

# Check if critical
- set_fact:
    is_critical: "{{ error_type | is_critical_error }}"

# Get recovery suggestions
- set_fact:
    suggestions: "{{ error_type | get_error_recovery_suggestion }}"
```

## Best Practices

### 1. Always Use Block/Rescue

```yaml
# Good
- name: "CIS control"
  block:
    - name: "Execute check"
      # task
  rescue:
    - name: "Handle error"
      # error handling

# Bad
- name: "CIS control"
  shell: |
    # command
  ignore_errors: yes  # No error categorization or tracking
```

### 2. Record All Results

```yaml
# Always record results, even on error
rescue:
  - name: "Record error"
    set_fact:
      cis_results: "{{ cis_results + [error_result] }}"
```

### 3. Use Meaningful Error Messages

```yaml
# Good
message: "Failed to retrieve API server configuration: connection timeout after 60s"

# Bad
message: "Error"
```

### 4. Set Appropriate Thresholds

```yaml
# For comprehensive audits
max_failures_per_section: 0  # No limit

# For production validation
max_failures_per_section: 5  # Stop after 5 failures
halt_on_threshold: true
```

### 5. Enable Detailed Logging for Troubleshooting

```yaml
# During development/troubleshooting
detailed_error_logging: true
include_recovery_suggestions: true

# In production
detailed_error_logging: false
include_recovery_suggestions: false
```

## Troubleshooting

### High Error Rates

1. Check cluster connectivity
2. Verify permissions
3. Review OpenShift version compatibility
4. Check for cluster issues (degraded operators, resource constraints)

### Threshold Exceeded

1. Review error types in section
2. Address critical errors first (CONNECTION, PERMISSION, TIMEOUT)
3. Increase threshold if errors are expected (OPERATOR_MANAGED, NOT_APPLICABLE)
4. Fix underlying issues before re-running

### Missing Error Reports

1. Verify `save_error_report: true`
2. Check `report_output_dir` exists and is writable
3. Ensure playbook completed (reports generated at end)
4. Check for errors in error report generation tasks

## Integration with Playbooks

### Main Playbook Integration

```yaml
---
- name: "CIS OpenShift Compliance Audit"
  hosts: localhost
  gather_facts: yes
  
  pre_tasks:
    - name: "Initialize results"
      set_fact:
        cis_results: []
  
  roles:
    - role: cis_section_1
    - role: cis_section_2
    - role: cis_section_3
    - role: cis_section_4
    - role: cis_section_5
  
  post_tasks:
    - name: "Generate error summary"
      include_tasks: playbooks/tasks/generate_error_summary.yml
```

### Role Integration

```yaml
# roles/cis_section_X/tasks/main.yml
---
- name: "Initialize section"
  include_tasks: roles/common/tasks/section_error_tracking.yml
  vars:
    section_name: "Section X"

- name: "Execute audit tasks"
  include_tasks: audit.yml
  when: cis_mode in ['audit', 'both']

- name: "Generate section summary"
  include_tasks: roles/common/tasks/section_error_tracking.yml
  vars:
    section_name: "Section X"
```

## Monitoring and Metrics

### Key Metrics

- **Error Rate**: Percentage of controls with errors
- **Critical Error Count**: Number of CONNECTION, PERMISSION, or TIMEOUT errors
- **Most Common Error Type**: Identifies systemic issues
- **Sections with Errors**: Identifies problematic areas

### Metric Interpretation

| Metric | Good | Warning | Critical |
|--------|------|---------|----------|
| Error Rate | < 5% | 5-15% | > 15% |
| Critical Errors | 0 | 1-3 | > 3 |
| Sections with Errors | 0-1 | 2-3 | > 3 |

## References

- [Ansible Error Handling](https://docs.ansible.com/ansible/latest/user_guide/playbooks_error_handling.html)
- [CIS Benchmark Documentation](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift Troubleshooting Guide](https://docs.openshift.com/container-platform/latest/support/troubleshooting/troubleshooting-installations.html)
