#!/bin/bash
# Test script to validate tag filtering works correctly

echo "=========================================="
echo "Testing Tag Filtering"
echo "=========================================="

# Test 1: List all tags in audit_l1.yml
echo ""
echo "Test 1: Listing all tags in audit_l1.yml"
ansible-playbook playbooks/audit_l1.yml --list-tags 2>&1 | grep -A 50 "play #1"

# Test 2: List tasks for section1 tag
echo ""
echo "Test 2: Listing tasks for section1 tag"
ansible-playbook playbooks/audit_l1.yml --tags section1 --list-tasks 2>&1 | grep -A 20 "play #1"

# Test 3: List tasks for control_1.1.1 tag
echo ""
echo "Test 3: Listing tasks for control_1.1.1 tag"
ansible-playbook playbooks/audit_l1.yml --tags control_1.1.1 --list-tasks 2>&1 | grep -A 10 "play #1"

# Test 4: List tasks for section5 tag
echo ""
echo "Test 4: Listing tasks for section5 tag"
ansible-playbook playbooks/audit_l1.yml --tags section5 --list-tasks 2>&1 | grep -A 20 "play #1"

echo ""
echo "=========================================="
echo "Tag filtering tests complete"
echo "=========================================="
