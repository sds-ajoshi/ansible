# CIS Section 5: Policies

This Ansible role implements audit and remediation tasks for CIS Red Hat OpenShift Container Platform Benchmark v1.8.0, Section 5: Policies.

## Overview

Section 5 covers security policies including:
- **5.1**: RBAC and Service Accounts
- **5.2**: Security Context Constraints (SCCs)
- **5.3**: Network Policies and CNI
- **5.4**: Secrets Management
- **5.5**: Extensible Admission Control
- **5.7**: General Policies (Seccomp, Security Contexts, Resource Quotas)

## Current Implementation Status

### Subsection 5.1: RBAC and Service Accounts ✅

Implemented controls:
- **5.1.1** (L1, Manual): Ensure that the cluster-admin role is only used where required
- **5.1.2** (L1, Manual): Minimize access to secrets
- **5.1.3** (L1, Manual): Minimize wildcard use in Roles and ClusterRoles
- **5.1.4** (L1, Manual): Minimize access to create pods
- **5.1.5** (L1, Automated): Ensure that default service accounts are not actively used
- **5.1.6** (L1, Manual): Ensure that Service Account Tokens are only mounted where necessary

### Subsection 5.2: Security Context Constraints (SCCs) 🚧

Not yet implemented. Will include:
- Privileged SCC usage auditing
- Custom SCC security validation
- Pod SCC annotation verification

### Subsection 5.3: Network Policies 🚧

Not yet implemented. Will include:
- Network policy existence checks per namespace
- Default deny policy validation

### Subsection 5.4: Secrets Management 🚧

Not yet implemented. Will include:
- Secrets as environment variables detection
- Encryption at rest verification

### Subsection 5.5: Admission Control 🚧

Not yet implemented. Will include:
- Admission controller configuration validation

### Subsection 5.7: General Policies 🚧

Not yet implemented. Will include:
- Seccomp profile usage
- Security context validation
- Resource quota checks

## Variables

### Default Variables (defaults/main.yml)

```yaml
# Execution mode
cis_mode: "audit"  # Options: audit, remediate, both

# CIS level
cis_level: 1  # Options: 1, 2

# RBAC and Service Account settings
check_cluster_admin_bindings: true
check_service_account_tokens: true
check_default_service_account_usage: true

# System namespaces to exclude from checks
exclude_system_namespaces:
  - kube-system
  - openshift-*
  # ... (see defaults/main.yml for full list)

# Error handling
continue_on_error: true
```

## Dependencies

- OpenShift CLI (`oc`) installed and configured
- `jq` command-line JSON processor
- Appropriate RBAC permissions to query cluster resources
- Ansible collections:
  - `kubernetes.core`
  - `community.general`

## Usage

### Run Section 5.1 Audit Only

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section5.1
```

### Run All Section 5 Audits (when fully implemented)

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section5
```

### Run Specific Control

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_5.1.5
```

### Run Remediation (Manual Guidance)

```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section5.1
```

## Audit Results

Audit results are stored in the `cis_results` fact array with the following structure:

```yaml
- control: "5.1.5"
  title: "Ensure that default service accounts are not actively used"
  level: "L1"
  assessment: "Automated"
  status: "PASS|FAIL|MANUAL|ERROR"
  message: "Descriptive message about the result"
  expected: "Expected configuration"
  actual: "Actual configuration found"
  details: "Additional details (JSON or text)"
  timestamp: "ISO8601 timestamp"
```

## Remediation Notes

### Manual vs Automated Remediation

Most controls in Section 5.1 require **manual remediation** because they involve:
- Organizational policy decisions
- Risk assessment and business justification
- Review of specific use cases
- Coordination with application teams

The remediation tasks provide guidance and examples but do not automatically modify configurations.

### Safe Remediation Practices

1. **Review audit results** before applying any remediation
2. **Test in non-production** environments first
3. **Document exceptions** with business justification
4. **Coordinate with teams** affected by RBAC changes
5. **Monitor applications** after applying changes

## Known Limitations

1. **System Namespaces**: Checks exclude OpenShift system namespaces by default as they require specific RBAC configurations
2. **Operator-Managed Resources**: Some RBAC configurations are managed by OpenShift operators and should not be modified
3. **Manual Assessment**: Many controls require human judgment and cannot be fully automated
4. **Version Compatibility**: Tested against OpenShift 4.14+; earlier versions may have different behaviors

## Troubleshooting

### Permission Errors

If you encounter permission errors:
```bash
# Verify your current permissions
oc auth can-i get clusterrolebindings
oc auth can-i get pods --all-namespaces

# Check your current user/service account
oc whoami
```

Required permissions:
- `get`, `list` on `clusterrolebindings`, `rolebindings`
- `get`, `list` on `pods`, `serviceaccounts` across all namespaces
- `get`, `list` on `roles`, `clusterroles`

### jq Not Found

Install jq:
```bash
# RHEL/CentOS
sudo yum install jq

# Ubuntu/Debian
sudo apt-get install jq

# macOS
brew install jq
```

### Empty or Unexpected Results

1. Verify OpenShift CLI is configured: `oc whoami`
2. Check cluster connectivity: `oc get nodes`
3. Review task output with verbose mode: `ansible-playbook ... -vvv`

## References

- [CIS Red Hat OpenShift Container Platform Benchmark v1.8.0](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift RBAC Documentation](https://docs.openshift.com/container-platform/latest/authentication/using-rbac.html)
- [OpenShift Service Accounts](https://docs.openshift.com/container-platform/latest/authentication/understanding-and-creating-service-accounts.html)
- [OpenShift Security Context Constraints](https://docs.openshift.com/container-platform/latest/authentication/managing-security-context-constraints.html)

## Contributing

When adding new controls to this role:

1. Follow the existing task structure and naming conventions
2. Include proper error handling with `block/rescue`
3. Add appropriate tags: `section5`, `section5.X`, `control_5.X.X`, `level1|level2`, `audit|remediate`
4. Document the control in this README
5. Test against a real OpenShift cluster
6. Update the implementation status section

## License

[Your License Here]

## Author

[Your Name/Organization]
