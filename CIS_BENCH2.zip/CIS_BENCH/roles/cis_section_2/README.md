# CIS Section 2: etcd

This role implements audit and remediation tasks for CIS Red Hat OpenShift Container Platform Benchmark Section 2, which covers etcd security configuration.

## Overview

etcd is the key-value store used by Kubernetes and OpenShift to store all cluster data. Securing etcd is critical as it contains sensitive information including secrets, configuration data, and cluster state.

In OpenShift 4, etcd is managed by the `cluster-etcd-operator` and most configurations are automatically set to secure defaults. Manual modifications to etcd settings are not recommended and will cause cluster degradation.

## CIS Controls Covered

### Level 1 Controls (Automated)

- **2.1**: Ensure that the --cert-file and --key-file arguments are set as appropriate
- **2.2**: Ensure that the --client-cert-auth argument is set to true
- **2.3**: Ensure that the --auto-tls argument is not set to true
- **2.4**: Ensure that the --peer-cert-file and --peer-key-file arguments are set as appropriate
- **2.5**: Ensure that the --peer-client-cert-auth argument is set to true
- **2.6**: Ensure that the --peer-auto-tls argument is not set to true

### Level 2 Controls (Manual)

- **2.7**: Ensure that a unique Certificate Authority is used for etcd

### Additional Checks

- **etcd data directory**: Verify permissions (700) and ownership (etcd:etcd) for `/var/lib/etcd`

## Variables

### Default Variables (defaults/main.yml)

```yaml
# etcd namespace
etcd_namespace: openshift-etcd

# Expected etcd data directory
etcd_data_dir: /var/lib/etcd

# Expected permissions and ownership
etcd_data_dir_permissions: "700"
etcd_data_dir_owner: "etcd"
etcd_data_dir_group: "etcd"

# etcd pod label selector
etcd_pod_label: "app=etcd"
```

## Dependencies

- OpenShift CLI (oc) must be installed and configured
- Appropriate RBAC permissions to query etcd pods and configurations
- Access to control plane nodes for data directory checks

## Usage

### Audit Only

```bash
# Audit all Section 2 controls
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section2

# Audit specific control
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_2.1
```

### Remediation

```bash
# Run remediation (will display operator-managed notices)
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section2
```

Note: Remediation tasks for Section 2 primarily provide informational messages, as etcd configurations are operator-managed and should not be manually modified.

## Audit Process

The audit tasks perform the following checks:

1. **Query etcd pod configuration**: Retrieves etcd pod specifications from the `openshift-etcd` namespace
2. **Verify certificate settings**: Checks that cert-file, key-file, peer-cert-file, and peer-key-file are configured
3. **Verify authentication settings**: Ensures client-cert-auth and peer-client-cert-auth are set to true
4. **Verify TLS settings**: Confirms that auto-tls and peer-auto-tls are not enabled
5. **Check data directory**: Verifies permissions and ownership of `/var/lib/etcd`
6. **Manual review**: Flags control 2.7 for manual verification of unique CA usage

## Remediation Approach

All etcd configurations in OpenShift 4 are managed by the cluster-etcd-operator. The remediation tasks provide:

- **Informational messages**: Explaining that configurations are operator-managed
- **Guidance**: Recommendations for proper configuration methods
- **Warnings**: Alerts about the risks of manual modifications

### Operator-Managed Configurations

The following settings are automatically managed and should not be manually modified:

- Certificate and key file paths
- Client authentication settings
- Peer communication security
- TLS configuration
- Data directory permissions

### Safe Configuration Options

While most etcd settings are operator-managed, you can safely configure:

- **etcd encryption at rest**: Enable through the APIServer resource
  ```bash
  oc patch apiservers.config.openshift.io cluster --type=merge \
    -p '{"spec":{"encryption":{"type":"aescbc"}}}'
  ```

## Known Limitations

1. **Operator-managed**: Most etcd configurations cannot be manually remediated
2. **Node access required**: Data directory checks require `oc debug node` access
3. **Manual verification**: Control 2.7 (unique CA) requires manual review
4. **Version-specific**: Behavior may vary across OpenShift versions

## Troubleshooting

### etcd pods not found

```bash
# Verify etcd pods are running
oc get pods -n openshift-etcd -l app=etcd

# Check etcd operator status
oc get clusteroperator etcd
```

### Permission denied errors

Ensure your service account or user has appropriate RBAC permissions:

```bash
# Check permissions
oc auth can-i get pods -n openshift-etcd
oc auth can-i get pods -n openshift-etcd --as=system:serviceaccount:default:cis-automation
```

### Node debug access issues

```bash
# Test node debug access
oc debug node/<node-name> -- chroot /host ls /var/lib/etcd
```

## References

- [OpenShift etcd Documentation](https://docs.openshift.com/container-platform/latest/backup_and_restore/control_plane_backup_and_restore/backing-up-etcd.html)
- [CIS Red Hat OpenShift Benchmark v1.8.0](https://www.cisecurity.org/benchmark/kubernetes)
- [cluster-etcd-operator](https://github.com/openshift/cluster-etcd-operator)

## Tags

All tasks in this role use the following tag structure:

- `section2`: All Section 2 tasks
- `control_2.X`: Specific control tasks
- `level1`: Level 1 controls
- `level2`: Level 2 controls
- `audit`: Audit tasks
- `remediate`: Remediation tasks

## Example Output

```yaml
- control: "2.1"
  title: "Ensure that the --cert-file and --key-file arguments are set as appropriate"
  level: "L1"
  assessment: "Automated"
  status: "PASS"
  message: "etcd is configured with cert-file and key-file"
  actual:
    - "--cert-file=/etc/kubernetes/static-pod-certs/secrets/etcd-all-serving/etcd-serving-NODE_NAME.crt"
    - "--key-file=/etc/kubernetes/static-pod-certs/secrets/etcd-all-serving/etcd-serving-NODE_NAME.key"
  timestamp: "2025-11-13T10:30:00Z"
```
