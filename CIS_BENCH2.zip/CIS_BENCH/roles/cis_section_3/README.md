# CIS Section 3: Control Plane Configuration

This role implements audit and remediation tasks for CIS Red Hat OpenShift Container Platform Benchmark Section 3: Control Plane Configuration.

## Overview

Section 3 covers authentication, authorization, and logging configurations for the OpenShift control plane. This includes identity provider configuration, audit logging, and security settings for the API server.

## Subsections

### 3.1 Authentication and Authorization

Controls related to:
- Client certificate authentication
- Identity provider configuration
- Anonymous authentication
- Insecure port configuration
- API server profiling
- Admission plugins (DenyServiceExternalIPs)
- kubeadmin secret removal

### 3.2 Logging

Controls related to:
- Audit policy configuration
- Audit log coverage
- Audit log retention
- Audit log forwarding

## CIS Controls Covered

| Control | Title | Level | Assessment | Remediable |
|---------|-------|-------|------------|------------|
| 3.1.1 | Client certificate authentication should not be used for users | L1 | Manual | Manual |
| 3.2.1 | Ensure that a minimal audit policy is created | L1 | Automated | N/A (enabled by default) |
| 3.2.2 | Ensure that the audit policy covers key security concerns | L1 | Manual | Configurable |
| 3.1.x | Remove kubeadmin secret | L1 | Automated | Automated |
| 3.1.x | Verify anonymous authentication | L1 | Automated | N/A (operator-managed) |
| 3.1.x | Verify insecure port is disabled | L1 | Automated | N/A (operator-managed) |
| 3.1.x | Verify profiling configuration | L2 | Automated | N/A (operator-managed) |
| 3.1.x | Verify DenyServiceExternalIPs | L1 | Automated | N/A (operator-managed) |
| 3.2.x | Verify audit log retention | L1 | Automated | Configurable |
| 3.2.x | Configure audit log forwarding | L2 | Manual | Manual |

## Variables

### Defaults (roles/cis_section_3/defaults/main.yml)

```yaml
# Audit log retention settings
audit_log_max_age: 30
audit_log_max_backup: 10
audit_log_max_size: 100

# Expected audit profile
expected_audit_profile: "Default"

# kubeadmin secret check
check_kubeadmin_removal: true
```

### Required Variables

- `cis_mode`: Execution mode (`audit`, `remediate`, or `both`)
- `cis_level`: CIS level to check (`1` or `2`)

## Dependencies

- OpenShift CLI (`oc`) must be installed and configured
- Appropriate RBAC permissions to query OAuth, API server configs, and secrets
- `jq` command-line JSON processor

## Usage

### Audit Only

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section3
```

### Remediation Only

```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section3
```

### Specific Subsection

```bash
# Authentication and Authorization only
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section3.1

# Logging only
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section3.2
```

### Specific Control

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_3.2.1
```

## Operator-Managed Configurations

Many Section 3 controls are operator-managed in OpenShift and cannot be directly modified:

- **Anonymous authentication**: Configured by default to allow restricted access to discovery endpoints
- **Insecure port**: Disabled by default
- **API server profiling**: Managed by cluster operators
- **Audit policy**: Enabled by default with comprehensive coverage

Manual changes to these settings will cause the cluster to enter a degraded state.

## Remediable Controls

### Automated Remediation

- **kubeadmin secret removal**: Automatically removed if identity providers are configured

### Manual Remediation

- **Identity provider configuration**: Requires manual setup via OAuth resource
- **Audit log forwarding**: Requires OpenShift Logging operator and ClusterLogForwarder configuration

### Configurable Settings

- **Audit profile**: Can be set to `Default`, `WriteRequestBodies`, `AllRequestBodies`, or `None`

## Known Limitations

1. **Identity Provider Setup**: Cannot be fully automated as it requires organization-specific configuration (LDAP, OAuth, etc.)
2. **Log Forwarding**: Requires external logging infrastructure and manual configuration
3. **Operator-Managed Settings**: Most API server and authentication settings are controlled by OpenShift operators

## Example Playbook

```yaml
---
- name: Audit CIS Section 3
  hosts: localhost
  gather_facts: yes
  vars:
    cis_mode: audit
    cis_level: 1
  roles:
    - cis_section_3
```

## Testing

Test the role in a non-production environment first:

```bash
# Dry-run remediation
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section3 --check

# Actual remediation
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section3
```

## References

- [CIS Red Hat OpenShift Container Platform Benchmark v1.8.0](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift Authentication Documentation](https://docs.openshift.com/container-platform/latest/authentication/understanding-authentication.html)
- [OpenShift Audit Logging](https://docs.openshift.com/container-platform/latest/security/audit-log-policy-config.html)
- [OpenShift Logging](https://docs.openshift.com/container-platform/latest/logging/cluster-logging.html)

## License

See project LICENSE file.

## Author

Generated as part of CIS OpenShift Ansible Automation Suite
