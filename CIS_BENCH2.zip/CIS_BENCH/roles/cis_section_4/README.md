# CIS Section 4 - Worker Nodes

This role implements CIS Red Hat OpenShift Container Platform Benchmark v1.8.0 Section 4 controls for Worker Nodes.

## Overview

Section 4 focuses on security configurations for OpenShift worker nodes, including:
- Worker node configuration file permissions and ownership
- Kubelet configuration and security settings
- TLS and certificate management
- Authentication and authorization settings

## CIS Controls Covered

### Subsection 4.1 - Worker Node Configuration Files

| Control | Title | Level | Assessment | Remediation |
|---------|-------|-------|------------|-------------|
| 4.1.1 | Ensure that the kubelet service file permissions are set to 600 or more restrictive | L1 | Automated | Not Available (Operator-Managed) |
| 4.1.2 | Ensure that the kubelet service file ownership is set to root:root | L1 | Automated | Not Available (Operator-Managed) |
| 4.1.3 | If proxy kubeconfig file exists ensure permissions are set to 600 or more restrictive | L1 | Manual | Manual |
| 4.1.4 | If proxy kubeconfig file exists ensure ownership is set to root:root | L1 | Manual | Manual |
| 4.1.5 | Ensure that the --kubeconfig kubelet.conf file permissions are set to 600 or more restrictive | L1 | Automated | Not Available (Operator-Managed) |
| 4.1.6 | Ensure that the --kubeconfig kubelet.conf file ownership is set to root:root | L1 | Automated | Not Available (Operator-Managed) |
| 4.1.7 | Ensure that the certificate authorities file permissions are set to 600 or more restrictive | L1 | Manual | Manual |
| 4.1.8 | Ensure that the client certificate authorities file ownership is set to root:root | L1 | Manual | Manual |
| 4.1.9 | If the kubelet config.yaml configuration file is being used validate permissions set to 600 or more restrictive | L1 | Automated | Not Available (Operator-Managed) |
| 4.1.10 | If the kubelet config.yaml configuration file is being used validate file ownership is set to root:root | L1 | Automated | Not Available (Operator-Managed) |

### Subsection 4.2 - Kubelet Configuration

| Control | Title | Level | Assessment | Remediation |
|---------|-------|-------|------------|-------------|
| 4.2.1 | Ensure that the --anonymous-auth argument is set to false | L1 | Automated | Available via KubeletConfig |
| 4.2.2 | Ensure that the --authorization-mode argument is not set to AlwaysAllow | L1 | Automated | Available via KubeletConfig |
| 4.2.3 | Ensure that the --client-ca-file argument is set as appropriate | L1 | Automated | Not Available (Operator-Managed) |
| 4.2.4 | Verify that the --read-only-port argument is set to 0 | L1 | Automated | Available via KubeletConfig |
| 4.2.5 | Ensure that the --streaming-connection-idle-timeout argument is not set to 0 | L1 | Automated | Available via KubeletConfig |
| 4.2.6 | Ensure that the --protect-kernel-defaults argument is set to true | L1 | Automated | Available via KubeletConfig |
| 4.2.7 | Ensure that the --make-iptables-util-chains argument is set to true | L1 | Automated | Available via KubeletConfig |
| 4.2.8 | Ensure that the --hostname-override argument is not set | L1 | Manual | Manual |
| 4.2.9 | Ensure that the eventRecordQPS argument is set to a level which ensures appropriate event capture | L2 | Manual | Available via KubeletConfig |
| 4.2.10 | Ensure that the --tls-cert-file and --tls-private-key-file arguments are set as appropriate | L1 | Automated | Not Available (Operator-Managed) |
| 4.2.11 | Ensure that the --rotate-certificates argument is not set to false | L1 | Automated | Available via KubeletConfig |
| 4.2.12 | Verify that the RotateKubeletServerCertificate argument is set to true | L1 | Manual | Available via KubeletConfig |
| 4.2.13 | Ensure that the Kubelet only makes use of Strong Cryptographic Ciphers | L1 | Manual | Available via KubeletConfig |

## Variables

### Default Variables (defaults/main.yml)

```yaml
# Expected file permissions
expected_kubelet_service_permissions: "644"
expected_kubelet_conf_permissions: "600"
expected_kubelet_ca_permissions: "644"

# Kubelet configuration paths
kubelet_config_path_414_plus: "/var/data/kubelet/config.json"
kubelet_config_path_legacy: "/var/lib/kubelet/config.json"

# Expected kubelet settings
expected_anonymous_auth: false
expected_authorization_mode: "Webhook"
expected_read_only_port: 0
expected_streaming_idle_timeout: "5m"
expected_protect_kernel_defaults: true
expected_make_iptables_util_chains: true
expected_event_qps: 0
expected_rotate_certificates: true

# Recommended TLS cipher suites
recommended_tls_cipher_suites:
  - "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"
  - "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
  - "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"
  - "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"
  - "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256"
  - "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256"
```

## Dependencies

- OpenShift CLI (oc) must be installed and configured
- Access to worker nodes via `oc debug node/<node-name>`
- Appropriate RBAC permissions to query node configurations

## Usage

### Audit Only

```bash
# Audit all Section 4 controls
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section4

# Audit specific subsection
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section4.1
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section4.2

# Audit specific control
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_4.2.1
```

### Remediation

```bash
# Remediate all Section 4 controls
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section4

# Remediate specific subsection
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section4.2
```

## Important Notes

### Operator-Managed Configurations

Most worker node file permissions and ownership settings are managed by the Machine Config Operator and cannot be manually remediated:
- Kubelet service file permissions and ownership
- Kubelet.conf file permissions and ownership
- Kubelet config.json file permissions and ownership
- TLS certificate and key files

Any manual changes to these files will be automatically reverted by the operator.

### Kubelet Configuration via KubeletConfig

Many kubelet settings can be configured using the `KubeletConfig` custom resource. The remediation tasks provide guidance on creating appropriate KubeletConfig resources.

Example:
```yaml
apiVersion: machineconfiguration.openshift.io/v1
kind: KubeletConfig
metadata:
  name: custom-kubelet-config
spec:
  machineConfigPoolSelector:
    matchLabels:
      pools.operator.machineconfiguration.openshift.io/worker: ""
  kubeletConfig:
    readOnlyPort: 0
    protectKernelDefaults: true
    streamingConnectionIdleTimeout: "5m"
```

### Version-Specific Behavior

- **OpenShift 4.13+**: Kubelet config moved to `/var/data/kubelet/config.json`
- **OpenShift 4.6+**: Read-only port set to 0 by default
- **OpenShift 4.14+**: File permissions improved to 600 for sensitive files

### Node Access

Audit tasks use `oc debug node/<node-name>` to access worker nodes. This requires:
- Cluster admin privileges or appropriate RBAC permissions
- Network connectivity to worker nodes
- Debug pods enabled in the cluster

## Known Limitations

1. **File Permission Checks**: File permissions are operator-managed and cannot be changed without causing cluster degradation
2. **Manual Controls**: Some controls require manual verification and cannot be fully automated
3. **Node Access**: Requires debug pod access to worker nodes, which may not be available in all environments
4. **MachineConfig Changes**: Kubelet configuration changes via KubeletConfig require node reboots and may cause temporary service disruption

## Troubleshooting

### Issue: Cannot access worker nodes

**Solution**: Ensure you have appropriate RBAC permissions and that debug pods are enabled:
```bash
oc adm policy add-cluster-role-to-user cluster-admin <username>
```

### Issue: Kubelet config not found

**Solution**: Check OpenShift version and verify the correct config path:
```bash
# For OpenShift 4.13+
oc debug node/<node> -- chroot /host cat /var/data/kubelet/config.json

# For older versions
oc debug node/<node> -- chroot /host cat /var/lib/kubelet/config.json
```

### Issue: KubeletConfig changes not applied

**Solution**: Verify MachineConfigPool status:
```bash
oc get mcp
oc get kubeletconfig
oc describe kubeletconfig <name>
```

## References

- [CIS Red Hat OpenShift Container Platform Benchmark v1.8.0](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift Machine Config Operator](https://docs.openshift.com/container-platform/latest/post_installation_configuration/machine-configuration-tasks.html)
- [OpenShift Kubelet Configuration](https://docs.openshift.com/container-platform/latest/nodes/nodes/nodes-nodes-managing.html)
- [OpenShift Security Best Practices](https://docs.openshift.com/container-platform/latest/security/index.html)
