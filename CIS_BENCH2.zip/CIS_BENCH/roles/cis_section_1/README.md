# CIS Section 1 - Control Plane Components

This Ansible role implements audit and remediation tasks for CIS Red Hat OpenShift Container Platform Benchmark Section 1: Control Plane Components.

## Overview

Section 1 covers security controls for OpenShift control plane components including:
- Master node configuration files (Section 1.1)
- API Server configuration (Section 1.2)
- Controller Manager configuration (Section 1.3)
- Scheduler configuration (Section 1.4)

This role currently implements **Section 1.1: Master Node Configuration Files** (controls 1.1.1 through 1.1.21).

## Controls Covered

### Section 1.1: Master Node Configuration Files

| Control | Title | Level | Assessment | Remediation |
|---------|-------|-------|------------|-------------|
| 1.1.1 | API server pod specification file permissions | L1 | Automated | Operator-Managed |
| 1.1.2 | API server pod specification file ownership | L1 | Automated | Operator-Managed |
| 1.1.3 | Controller manager pod specification file permissions | L1 | Automated | Operator-Managed |
| 1.1.4 | Controller manager pod specification file ownership | L1 | Automated | Operator-Managed |
| 1.1.5 | Scheduler pod specification file permissions | L1 | Automated | Operator-Managed |
| 1.1.6 | Scheduler pod specification file ownership | L1 | Automated | Operator-Managed |
| 1.1.7 | etcd pod specification file permissions | L1 | Automated | Operator-Managed |
| 1.1.8 | etcd pod specification file ownership | L1 | Automated | Operator-Managed |
| 1.1.9 | Container Network Interface file permissions | L1 | Manual | Not Applicable |
| 1.1.10 | Container Network Interface file ownership | L1 | Manual | Not Applicable |
| 1.1.11 | etcd data directory permissions | L1 | Automated | Operator-Managed |
| 1.1.12 | etcd data directory ownership | L1 | Automated | Operator-Managed |
| 1.1.13 | admin.kubeconfig file permissions | L1 | Automated | Operator-Managed |
| 1.1.14 | admin.kubeconfig file ownership | L1 | Automated | Operator-Managed |
| 1.1.15 | scheduler.conf file permissions | L1 | Manual | Not Applicable |
| 1.1.16 | scheduler.conf file ownership | L1 | Manual | Not Applicable |
| 1.1.17 | controller-manager.conf file permissions | L1 | Manual | Not Applicable |
| 1.1.18 | controller-manager.conf file ownership | L1 | Manual | Not Applicable |
| 1.1.19 | Kubernetes PKI directory and file ownership | L1 | Automated | Operator-Managed |
| 1.1.20 | Kubernetes PKI certificate file permissions | L1 | Automated | Operator-Managed |
| 1.1.21 | Kubernetes PKI key file permissions | L1 | Automated | Operator-Managed |

## Variables

### Required Variables

- `cis_mode`: Execution mode (`audit`, `remediate`, or `both`)
- `cis_level`: CIS level to audit/remediate (`1` or `2`)

### Optional Variables

- `control_plane_group`: Inventory group for control plane nodes (default: `masters`)
- `expected_file_permissions`: Expected file permissions, set automatically based on OpenShift version
- `expected_file_owner`: Expected file owner (default: `root`)
- `expected_file_group`: Expected file group (default: `root`)

## Dependencies

- OpenShift CLI (`oc`) must be installed and configured
- Access to OpenShift cluster with appropriate permissions
- Ability to run `oc debug node/<node>` commands

## Usage

### Audit Only

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1
```

### Specific Control

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_1.1.1
```

### Remediation

```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section1
```

Note: Remediation tasks will display informational messages about operator-managed configurations.

## Known Limitations

### Operator-Managed Configurations

**All controls in Section 1.1 are operator-managed in OpenShift 4.** This means:

- File permissions and ownership are automatically set by cluster operators
- Manual changes will be reverted by the operators
- No manual remediation is possible or recommended

### Version-Specific Behavior

- **OpenShift 4.14+**: File permissions are set to 600 by default
- **Older versions**: File permissions are 644, which is compliant for those versions

### Not Applicable Controls

Controls 1.1.9, 1.1.10, 1.1.15-1.1.18 are marked as "Not Applicable" because:
- OpenShift uses OVN-Kubernetes or OpenShift SDN (not separate CNI files)
- OpenShift uses integrated kubeconfig (not separate scheduler.conf or controller-manager.conf files)

## Audit Results

Audit results are stored in the `cis_results` fact array with the following structure:

```yaml
- control: "1.1.1"
  title: "Ensure that the API server pod specification file permissions are set to 600 or more restrictive"
  level: "L1"
  status: "PASS" | "FAIL" | "MANUAL" | "ERROR"
  message: "Detailed result message"
  expected: "600"
  actual: "600"
  timestamp: "2025-11-13T10:30:00Z"
  host: "master-0.example.com"
```

## Troubleshooting

### Cannot connect to control plane node

Ensure you have:
- Valid kubeconfig with cluster-admin or equivalent permissions
- Network connectivity to the OpenShift cluster
- `oc` CLI tool installed and in PATH

### Permission denied errors

The automation requires permissions to:
- List nodes
- Run `oc debug node/<node>` commands
- Access control plane node filesystems

### Unexpected FAIL results on older OpenShift versions

For OpenShift versions prior to 4.14, file permissions of 644 are expected and compliant. The automation automatically adjusts expectations based on detected OpenShift version.

## References

- [CIS Red Hat OpenShift Container Platform Benchmark v1.8.0](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift Security Documentation](https://docs.openshift.com/container-platform/latest/security/)
- [OpenShift Operators Reference](https://docs.openshift.com/container-platform/latest/operators/operator-reference.html)
