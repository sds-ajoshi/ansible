#!/bin/bash
# Validation script for CIS OpenShift Ansible Automation
# Tests tag filtering and variable precedence

set -o pipefail

echo "=========================================="
echo "CIS OpenShift Ansible Automation Validation"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
TESTS_PASSED=0
TESTS_FAILED=0

# Function to print test result
print_result() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✓ PASS${NC}: $2"
        ((TESTS_PASSED++))
    else
        echo -e "${RED}✗ FAIL${NC}: $2"
        ((TESTS_FAILED++))
    fi
}

echo "Test 1: Validate playbook syntax"
echo "-----------------------------------"
for playbook in playbooks/*.yml; do
    if ansible-playbook --syntax-check "$playbook" > /dev/null 2>&1; then
        print_result 0 "Syntax check for $(basename $playbook)"
    else
        print_result 1 "Syntax check for $(basename $playbook)"
    fi
done
echo ""

echo "Test 2: Verify role references in playbooks"
echo "-----------------------------------"
for role in cis_section_1 cis_section_2 cis_section_3 cis_section_4 cis_section_5; do
    if grep -q "role: $role" playbooks/audit_l1.yml; then
        print_result 0 "Role $role referenced in audit_l1.yml"
    else
        print_result 1 "Role $role NOT found in audit_l1.yml"
    fi
done
echo ""

echo "Test 3: Verify tag consistency"
echo "-----------------------------------"
# Check that section tags exist
for num in 1 2 3 4 5; do
    section="section${num}"
    if grep -rq "\- $section" roles/cis_section_${num}/tasks/ 2>/dev/null; then
        print_result 0 "Tag $section found in role tasks"
    else
        print_result 1 "Tag $section NOT found in role tasks"
    fi
done
echo ""

echo "Test 4: Verify audit and remediate tags"
echo "-----------------------------------"
for section in 1 2 3 4 5; do
    if grep -q "tags:" roles/cis_section_${section}/tasks/audit.yml 2>/dev/null; then
        print_result 0 "Tags found in section ${section} audit tasks"
    else
        print_result 1 "Tags NOT found in section ${section} audit tasks"
    fi
    
    if grep -q "tags:" roles/cis_section_${section}/tasks/remediate.yml 2>/dev/null; then
        print_result 0 "Tags found in section ${section} remediate tasks"
    else
        print_result 1 "Tags NOT found in section ${section} remediate tasks"
    fi
done
echo ""

echo "Test 5: Verify required files exist"
echo "-----------------------------------"
required_files=(
    "inventory/hosts.example"
    "group_vars/all.yml"
    ".gitignore"
    "requirements.yml"
    "README.md"
)

for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        print_result 0 "Required file exists: $file"
    else
        print_result 1 "Required file missing: $file"
    fi
done
echo ""

echo "Test 6: Verify role structure"
echo "-----------------------------------"
for section in 1 2 3 4 5; do
    role_dir="roles/cis_section_${section}"
    
    if [ -d "$role_dir/tasks" ]; then
        print_result 0 "Section $section has tasks directory"
    else
        print_result 1 "Section $section missing tasks directory"
    fi
    
    if [ -f "$role_dir/tasks/main.yml" ]; then
        print_result 0 "Section $section has main.yml"
    else
        print_result 1 "Section $section missing main.yml"
    fi
    
    if [ -f "$role_dir/tasks/audit.yml" ]; then
        print_result 0 "Section $section has audit.yml"
    else
        print_result 1 "Section $section missing audit.yml"
    fi
    
    if [ -f "$role_dir/tasks/remediate.yml" ]; then
        print_result 0 "Section $section has remediate.yml"
    else
        print_result 1 "Section $section missing remediate.yml"
    fi
done
echo ""

echo "Test 7: Verify configuration variables"
echo "-----------------------------------"
required_vars=(
    "cis_mode"
    "cis_level"
    "openshift_api_url"
    "report_output_dir"
    "remediation_dry_run"
    "skip_operator_managed"
)

for var in "${required_vars[@]}"; do
    if grep -q "^$var:" group_vars/all.yml; then
        print_result 0 "Variable $var defined in group_vars/all.yml"
    else
        print_result 1 "Variable $var NOT found in group_vars/all.yml"
    fi
done
echo ""

echo "Test 8: Verify .gitignore entries"
echo "-----------------------------------"
gitignore_entries=(
    "inventory/hosts"
    "*.retry"
    "cis_reports/"
    "*.log"
)

for entry in "${gitignore_entries[@]}"; do
    if grep -q "$entry" .gitignore; then
        print_result 0 ".gitignore contains: $entry"
    else
        print_result 1 ".gitignore missing: $entry"
    fi
done
echo ""

echo "Test 9: Verify filter plugins"
echo "-----------------------------------"
if [ -d "filter_plugins" ]; then
    print_result 0 "filter_plugins directory exists"
    
    if [ -f "filter_plugins/cis_filters.py" ]; then
        print_result 0 "cis_filters.py exists"
    else
        print_result 1 "cis_filters.py missing"
    fi
else
    print_result 1 "filter_plugins directory missing"
fi
echo ""

echo "Test 10: Verify playbook documentation"
echo "-----------------------------------"
for playbook in playbooks/*.yml; do
    if head -20 "$playbook" | grep -q "# Usage:"; then
        print_result 0 "Usage documentation in $(basename $playbook)"
    else
        print_result 1 "Usage documentation missing in $(basename $playbook)"
    fi
done
echo ""

# Summary
echo "=========================================="
echo "Validation Summary"
echo "=========================================="
echo -e "Tests Passed: ${GREEN}${TESTS_PASSED}${NC}"
echo -e "Tests Failed: ${RED}${TESTS_FAILED}${NC}"
echo "Total Tests: $((TESTS_PASSED + TESTS_FAILED))"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}All validation tests passed!${NC}"
    exit 0
else
    echo -e "${RED}Some validation tests failed. Please review the output above.${NC}"
    exit 1
fi
