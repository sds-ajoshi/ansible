# Design Document: CIS OpenShift Ansible Automation Suite

## Overview

This design document outlines the architecture and implementation approach for an Ansible automation suite that implements CIS Red Hat OpenShift Container Platform Benchmark v1.8.0 compliance controls. The suite provides both audit (verification) and remediation capabilities for Level 1 and Level 2 controls across OpenShift 4 clusters.

### Design Principles

1. **Audit-First Approach**: Verification before modification, with clear separation between audit and remediation tasks
2. **Idempotent Operations**: All remediation tasks can be safely run multiple times without unintended side effects
3. **Operator-Aware**: Respect OpenShift's operator-managed configurations and avoid modifications that cause degraded cluster state
4. **Modular Structure**: Organized by CIS control sections for maintainability and selective execution
5. **Comprehensive Logging**: Detailed audit trails for compliance reporting and troubleshooting
6. **Graceful Degradation**: Individual task failures do not halt entire playbook execution

### Scope

The automation suite covers:
- **Section 1**: Control Plane Components (API Server, Controller Manager, Scheduler)
- **Section 2**: etcd Configuration
- **Section 3**: Control Plane Configuration (Authentication, Logging)
- **Section 4**: Worker Nodes (Kubelet Configuration)
- **Section 5**: Policies (RBAC, SCCs, Network Policies, Secrets Management)

## Architecture

### High-Level Structure

```
cis-openshift-ansible/
├── playbooks/
│   ├── audit_l1.yml              # Level 1 audit playbook
│   ├── audit_l2.yml              # Level 2 audit playbook (includes L1)
│   ├── remediate_l1.yml          # Level 1 remediation playbook
│   ├── remediate_l2.yml          # Level 2 remediation playbook (includes L1)
│   └── audit_and_remediate.yml   # Combined audit + remediation
├── roles/
│   ├── cis_section_1/            # Control Plane Components
│   ├── cis_section_2/            # etcd
│   ├── cis_section_3/            # Control Plane Configuration
│   ├── cis_section_4/            # Worker Nodes
│   └── cis_section_5/            # Policies
├── group_vars/
│   └── all.yml                   # Default variables and configuration
├── inventory/
│   └── hosts.example             # Example inventory file
├── library/                      # Custom Ansible modules (if needed)
├── filter_plugins/               # Custom Jinja2 filters for reporting
└── README.md                     # Usage documentation
```

### Role Structure

Each CIS section role follows a consistent structure:

```
roles/cis_section_X/
├── tasks/
│   ├── main.yml                  # Entry point with conditional includes
│   ├── audit.yml                 # All audit tasks for this section
│   └── remediate.yml             # All remediation tasks for this section
├── vars/
│   └── main.yml                  # Section-specific variables
├── defaults/
│   └── main.yml                  # Default values for variables
└── README.md                     # Section-specific documentation
```

### Design Rationale

**Why role-per-section instead of role-per-control?**
- Reduces complexity (5 roles vs 100+ roles)
- Easier to maintain and navigate
- Aligns with CIS Benchmark document structure
- Simplifies tag-based filtering (section-level and control-level tags)

**Why separate audit and remediation task files?**
- Clear separation of concerns
- Enables audit-only or remediation-only execution modes
- Reduces risk of accidental modifications during audits
- Easier to review and validate changes

## Components and Interfaces

### 1. Playbook Layer

#### Main Playbooks

**audit_l1.yml**
- Purpose: Execute all Level 1 audit tasks
- Target: All OpenShift cluster nodes (control plane and workers)
- Variables: `cis_level: 1`, `cis_mode: audit`
- Tags: `audit`, `level1`, section-specific tags

**audit_l2.yml**
- Purpose: Execute all Level 1 and Level 2 audit tasks
- Target: All OpenShift cluster nodes
- Variables: `cis_level: 2`, `cis_mode: audit`
- Tags: `audit`, `level1`, `level2`, section-specific tags

**remediate_l1.yml**
- Purpose: Apply Level 1 remediations
- Target: All OpenShift cluster nodes
- Variables: `cis_level: 1`, `cis_mode: remediate`
- Tags: `remediate`, `level1`, section-specific tags

**remediate_l2.yml**
- Purpose: Apply Level 1 and Level 2 remediations
- Target: All OpenShift cluster nodes
- Variables: `cis_level: 2`, `cis_mode: remediate`
- Tags: `remediate`, `level1`, `level2`, section-specific tags

**audit_and_remediate.yml**
- Purpose: Combined audit followed by remediation
- Target: All OpenShift cluster nodes
- Variables: `cis_level` (1 or 2), `cis_mode: both`
- Tags: All tags from audit and remediation

### 2. Role Layer

Each role implements tasks for a specific CIS section:

#### Role: cis_section_1 (Control Plane Components)

**Subsections:**
- 1.1: Master Node Configuration Files (file permissions and ownership)
- 1.2: API Server (configuration arguments and settings)
- 1.3: Controller Manager (configuration and security)
- 1.4: Scheduler (configuration and RBAC protection)

**Key Audit Tasks:**
- Verify file permissions (600 or 644 depending on OpenShift version)
- Verify file ownership (root:root)
- Check API server arguments via configmap inspection
- Validate admission plugins configuration
- Verify TLS and certificate settings

**Key Remediation Tasks:**
- Note: Most control plane settings are operator-managed and non-remediable
- Document operator-managed configurations
- Provide guidance for manual configuration where applicable

**Target Hosts:** Control plane nodes (masters)

#### Role: cis_section_2 (etcd)

**Controls:**
- Certificate and key file configuration
- Client authentication settings
- Peer communication security
- Certificate authority validation

**Key Audit Tasks:**
- Verify etcd pod arguments
- Check certificate file paths and validity
- Validate client and peer authentication settings
- Verify unique CA usage

**Key Remediation Tasks:**
- Note: etcd is operator-managed; most settings are non-remediable
- Document current configuration
- Provide guidance for etcd encryption at rest

**Target Hosts:** Control plane nodes running etcd

#### Role: cis_section_3 (Control Plane Configuration)

**Subsections:**
- 3.1: Authentication and Authorization
- 3.2: Logging (audit policies and retention)

**Key Audit Tasks:**
- Verify identity provider configuration
- Check for kubeadmin account status
- Validate audit policy configuration
- Verify audit log retention settings

**Key Remediation Tasks:**
- Configure audit log retention
- Set up audit log forwarding
- Document identity provider setup requirements

**Target Hosts:** Control plane nodes, OpenShift API

#### Role: cis_section_4 (Worker Nodes)

**Subsections:**
- 4.1: Worker Node Configuration Files
- 4.2: Kubelet Configuration

**Key Audit Tasks:**
- Verify kubelet service file permissions and ownership
- Check kubelet configuration file settings
- Validate certificate authorities
- Verify kubelet arguments (anonymous-auth, authorization-mode, etc.)
- Check TLS configuration

**Key Remediation Tasks:**
- Configure kubelet settings via MachineConfig
- Set appropriate file permissions (where not operator-managed)
- Configure TLS cipher suites

**Target Hosts:** Worker nodes

#### Role: cis_section_5 (Policies)

**Subsections:**
- 5.1: RBAC and Service Accounts
- 5.2: Security Context Constraints (SCCs)
- 5.3: Network Policies and CNI
- 5.4: Secrets Management
- 5.5: Extensible Admission Control
- 5.7: General Policies

**Key Audit Tasks:**
- Identify cluster-admin role bindings
- Find pods using privileged SCCs
- Check for network policies in namespaces
- Verify service account token mounting
- Check seccomp profile usage
- Validate secrets usage patterns

**Key Remediation Tasks:**
- Create network policies for namespaces
- Configure default seccomp profiles
- Set service account token auto-mount to false
- Apply security contexts to pods
- Create custom SCCs where needed

**Target Hosts:** OpenShift API, all namespaces

### 3. Task Structure

#### Task Naming Convention

```yaml
# Format: CIS <section>.<subsection>.<control> - <description>
- name: "CIS 1.1.1 - Ensure API server pod specification file permissions are set to 600"
  tags:
    - section1
    - section1.1
    - control_1.1.1
    - level1
    - audit
```

#### Task Template (Audit)

```yaml
# CIS Control: <section>.<subsection>.<control>
# Level: <L1|L2>
# Assessment: <Automated|Manual>
- name: "CIS <control> - <description>"
  block:
    - name: "Gather configuration data"
      # Collection task (oc get, oc exec, shell commands)
      
    - name: "Evaluate compliance"
      # Comparison logic
      
    - name: "Record result"
      set_fact:
        cis_results: "{{ cis_results | default([]) + [result] }}"
  tags:
    - section<X>
    - section<X>.<Y>
    - control_<X>.<Y>.<Z>
    - level<1|2>
    - audit
  ignore_errors: yes
```

#### Task Template (Remediation)

```yaml
# CIS Control: <section>.<subsection>.<control>
# Level: <L1|L2>
# Remediation: <Available|Not Available|Not Recommended>
- name: "CIS <control> - Remediate <description>"
  block:
    - name: "Check if remediation is applicable"
      # Pre-check logic
      
    - name: "Apply remediation"
      # Remediation task (oc apply, oc patch, etc.)
      when: remediation_applicable
      
    - name: "Verify remediation"
      # Post-remediation verification
      
    - name: "Record remediation result"
      set_fact:
        cis_remediation_results: "{{ cis_remediation_results | default([]) + [result] }}"
  tags:
    - section<X>
    - section<X>.<Y>
    - control_<X>.<Y>.<Z>
    - level<1|2>
    - remediate
  ignore_errors: yes
  when: cis_mode in ['remediate', 'both']
```

## Data Models

### Audit Result Structure

```yaml
cis_results:
  - control: "1.1.1"
    title: "Ensure API server pod specification file permissions are set to 600"
    level: "L1"
    assessment: "Manual"
    status: "PASS" | "FAIL" | "MANUAL" | "ERROR"
    message: "Detailed result message"
    expected: "600"
    actual: "600"
    timestamp: "2025-11-13T10:30:00Z"
    host: "master-0.example.com"
```

### Remediation Result Structure

```yaml
cis_remediation_results:
  - control: "1.1.1"
    title: "Ensure API server pod specification file permissions are set to 600"
    level: "L1"
    status: "SUCCESS" | "FAILED" | "SKIPPED" | "NOT_AVAILABLE"
    message: "Detailed remediation message"
    changed: true | false
    timestamp: "2025-11-13T10:35:00Z"
    host: "master-0.example.com"
```

### Configuration Variables

```yaml
# CIS execution mode
cis_mode: "audit"  # Options: audit, remediate, both

# CIS level
cis_level: 1  # Options: 1, 2

# OpenShift cluster details
openshift_api_url: "https://api.cluster.example.com:6443"
openshift_kubeconfig: "/path/to/kubeconfig"

# Audit configuration
audit_log_retention_days: 30
audit_log_max_size_mb: 100
audit_log_max_files: 10

# Remediation behavior
remediation_backup_enabled: true
remediation_dry_run: false

# Reporting
report_output_dir: "./cis_reports"
report_format: "json"  # Options: json, yaml, html

# Error handling
continue_on_error: true
max_failures_per_section: 5

# Node targeting
control_plane_group: "masters"
worker_node_group: "workers"

# Operator-managed configuration awareness
skip_operator_managed: true
warn_on_operator_managed: true
```

## Error Handling

### Strategy

1. **Task-Level Error Handling**
   - Use `ignore_errors: yes` on audit tasks to continue execution
   - Use `block/rescue` for remediation tasks to handle failures gracefully
   - Capture error details in result structures

2. **Section-Level Error Handling**
   - Track failure count per section
   - Optionally halt section execution after threshold (configurable)
   - Continue to next section regardless of failures

3. **Playbook-Level Error Handling**
   - Generate summary report even if tasks fail
   - Distinguish between task failures and execution errors
   - Provide actionable error messages

### Error Categories

```yaml
error_types:
  - CONNECTION_ERROR: "Unable to connect to OpenShift API or nodes"
  - PERMISSION_ERROR: "Insufficient permissions to execute command"
  - CONFIGURATION_ERROR: "Invalid configuration or missing required variables"
  - OPERATOR_MANAGED: "Configuration is operator-managed and cannot be modified"
  - NOT_APPLICABLE: "Control does not apply to this OpenShift version"
  - UNKNOWN_ERROR: "Unexpected error occurred"
```

### Error Handling Example

```yaml
- name: "CIS 1.2.1 - Audit anonymous request authorization"
  block:
    - name: "Get API server configuration"
      shell: |
        oc get configmap config -n openshift-kube-apiserver -ojson | \
        jq -r '.data["config.yaml"]' | jq '.apiServerArguments'
      register: api_config
      failed_when: false
      
    - name: "Evaluate result"
      set_fact:
        audit_result:
          control: "1.2.1"
          status: "{{ 'PASS' if api_config.rc == 0 else 'ERROR' }}"
          message: "{{ api_config.stdout if api_config.rc == 0 else api_config.stderr }}"
          
  rescue:
    - name: "Handle error"
      set_fact:
        audit_result:
          control: "1.2.1"
          status: "ERROR"
          message: "Failed to retrieve API server configuration: {{ ansible_failed_result.msg }}"
          
  always:
    - name: "Record result"
      set_fact:
        cis_results: "{{ cis_results | default([]) + [audit_result] }}"
```

## Testing Strategy

### Unit Testing

**Approach:** Use Molecule for role-level testing

**Test Scenarios:**
1. Audit tasks execute without errors
2. Audit tasks correctly identify compliant configurations
3. Audit tasks correctly identify non-compliant configurations
4. Remediation tasks apply changes correctly
5. Remediation tasks are idempotent
6. Error handling works as expected

**Test Structure:**
```
roles/cis_section_X/
└── molecule/
    └── default/
        ├── molecule.yml
        ├── converge.yml
        ├── verify.yml
        └── prepare.yml
```

### Integration Testing

**Approach:** Test against actual OpenShift clusters (dev/test environments)

**Test Scenarios:**
1. Full L1 audit completes successfully
2. Full L2 audit completes successfully
3. Audit-only mode does not modify configurations
4. Remediation-only mode applies changes
5. Combined audit and remediation workflow
6. Tag-based filtering works correctly
7. Error handling and reporting

**Test Environments:**
- OpenShift 4.14 cluster
- OpenShift 4.15 cluster
- OpenShift 4.16+ cluster

### Validation Testing

**Approach:** Verify compliance improvements after remediation

**Test Scenarios:**
1. Run audit, capture baseline results
2. Run remediation
3. Run audit again, verify improvements
4. Compare before/after compliance scores

## Implementation Considerations

### OpenShift Version Compatibility

**Challenge:** File permissions and configurations vary between OpenShift versions

**Solution:**
- Use version detection at playbook start
- Conditional task execution based on version
- Document version-specific behaviors in task comments

```yaml
- name: "Detect OpenShift version"
  shell: "oc version -o json | jq -r '.openshiftVersion'"
  register: openshift_version
  
- name: "Set version-specific expectations"
  set_fact:
    expected_file_permissions: "{{ '600' if openshift_version.stdout is version('4.14', '>=') else '644' }}"
```

### Operator-Managed Configurations

**Challenge:** Many OpenShift configurations are managed by operators and should not be manually modified

**Solution:**
- Identify operator-managed settings in audit tasks
- Mark as "NOT_REMEDIABLE" in remediation tasks
- Provide documentation on proper configuration methods (e.g., using operator CRDs)
- Add warnings when attempting to modify operator-managed settings

```yaml
- name: "CIS 1.1.1 - Remediate API server pod spec permissions"
  debug:
    msg: "This file is operator-managed. Manual permission changes will be reverted. No remediation available."
  when: skip_operator_managed
  tags:
    - control_1.1.1
    - remediate
```

### Authentication and Authorization

**Challenge:** Tasks require appropriate permissions to query and modify OpenShift resources

**Solution:**
- Document required RBAC permissions in README
- Use service account with cluster-admin role (or custom role with specific permissions)
- Provide kubeconfig or token-based authentication
- Handle authentication failures gracefully

**Required Permissions:**
```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: cis-automation-role
rules:
  - apiGroups: ["*"]
    resources: ["*"]
    verbs: ["get", "list", "watch"]
  - apiGroups: ["config.openshift.io"]
    resources: ["*"]
    verbs: ["get", "list", "patch", "update"]
  # Additional permissions as needed
```

### Node Access

**Challenge:** Some controls require direct node access (SSH or oc debug)

**Solution:**
- Use `oc debug node/<node-name>` for node-level commands
- Avoid SSH dependencies where possible
- Handle node access failures gracefully
- Document node access requirements

```yaml
- name: "Check file permissions on control plane node"
  shell: |
    oc debug node/{{ inventory_hostname }} -- chroot /host stat -c %a /etc/kubernetes/manifests/kube-apiserver-pod.yaml
  register: file_perms
  failed_when: false
```

### Idempotency

**Challenge:** Remediation tasks must be safely repeatable

**Solution:**
- Check current state before applying changes
- Use `changed_when` conditions appropriately
- Leverage Ansible's built-in idempotency (oc apply, k8s module)
- Test remediation tasks multiple times

```yaml
- name: "Apply network policy"
  k8s:
    state: present
    definition: "{{ network_policy_definition }}"
  register: np_result
  changed_when: np_result.changed
```

### Performance Optimization

**Challenge:** Auditing 100+ controls across multiple nodes can be time-consuming

**Solution:**
- Use `async` and `poll` for long-running tasks
- Parallelize node-level checks where possible
- Cache frequently accessed data (e.g., API server config)
- Provide progress indicators

```yaml
- name: "Audit all worker nodes in parallel"
  include_tasks: audit_worker_node.yml
  loop: "{{ groups['workers'] }}"
  loop_control:
    loop_var: worker_node
  async: 300
  poll: 0
  register: worker_audits
```

### Reporting and Output

**Challenge:** Generate useful, actionable reports for compliance officers and engineers

**Solution:**
- Structured output formats (JSON, YAML)
- HTML report generation with summary statistics
- CSV export for spreadsheet analysis
- Integration with compliance tools (optional)

**Report Structure:**
```json
{
  "execution_timestamp": "2025-11-13T10:30:00Z",
  "openshift_version": "4.15.2",
  "cis_benchmark_version": "1.8.0",
  "level": "L1",
  "mode": "audit",
  "summary": {
    "total_controls": 95,
    "passed": 78,
    "failed": 12,
    "manual": 5,
    "errors": 0
  },
  "results_by_section": {
    "section_1": { "passed": 25, "failed": 3, "manual": 2 },
    "section_2": { "passed": 7, "failed": 0, "manual": 0 }
  },
  "detailed_results": [...]
}
```

## Security Considerations

1. **Credential Management**
   - Never store credentials in playbooks or variables files
   - Use Ansible Vault for sensitive variables
   - Leverage OpenShift service accounts where possible
   - Document secure credential handling in README

2. **Audit Trail**
   - Log all remediation actions with timestamps
   - Capture before/after states for changes
   - Store audit logs securely
   - Implement log rotation and retention

3. **Least Privilege**
   - Use minimal required permissions for automation
   - Avoid cluster-admin role where possible
   - Document required permissions clearly
   - Provide custom RBAC role definitions

4. **Change Control**
   - Implement dry-run mode for remediation
   - Require explicit confirmation for production changes
   - Backup configurations before remediation
   - Provide rollback procedures

5. **Network Security**
   - Use encrypted connections (HTTPS, TLS)
   - Validate certificates
   - Avoid exposing sensitive data in logs
   - Secure report storage and transmission

## Deployment and Usage

### Prerequisites

- Ansible 2.15 or later
- Python 3.9 or later
- OpenShift CLI (oc) 4.14 or later
- kubernetes.core Ansible collection
- community.general Ansible collection
- Access to OpenShift cluster with appropriate permissions

### Installation

```bash
# Clone repository
git clone <repository-url>
cd cis-openshift-ansible

# Install required Ansible collections
ansible-galaxy collection install -r requirements.yml

# Configure inventory
cp inventory/hosts.example inventory/hosts
# Edit inventory/hosts with your cluster details

# Configure variables
cp group_vars/all.yml.example group_vars/all.yml
# Edit group_vars/all.yml with your settings
```

### Execution Examples

```bash
# Run Level 1 audit
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml

# Run Level 2 audit
ansible-playbook -i inventory/hosts playbooks/audit_l2.yml

# Run Level 1 remediation (dry-run)
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml -e remediation_dry_run=true

# Run Level 1 remediation
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml

# Run specific section only
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1

# Run specific control
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_1.1.1

# Audit only (skip remediation)
ansible-playbook -i inventory/hosts playbooks/audit_and_remediate.yml --tags audit

# Generate HTML report
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_format=html
```

## Maintenance and Extension

### Adding New Controls

1. Identify the CIS section for the new control
2. Add audit task to `roles/cis_section_X/tasks/audit.yml`
3. Add remediation task to `roles/cis_section_X/tasks/remediate.yml` (if applicable)
4. Add appropriate tags (section, control, level)
5. Update documentation
6. Add test cases

### Updating for New OpenShift Versions

1. Review CIS Benchmark updates for new OpenShift version
2. Identify changed controls or new controls
3. Update version detection logic
4. Add version-specific conditionals
5. Test against new OpenShift version
6. Update documentation

### Custom Extensions

The automation suite supports custom extensions:
- Custom modules in `library/`
- Custom filters in `filter_plugins/`
- Custom roles for organization-specific controls
- Integration with external compliance tools

## Documentation Requirements

### README.md

- Overview and purpose
- Prerequisites and installation
- Quick start guide
- Usage examples
- Configuration options
- Troubleshooting
- Contributing guidelines

### Role Documentation

Each role should include:
- CIS section coverage
- Control list with assessment status
- Variables and defaults
- Dependencies
- Example usage
- Known limitations

### Inline Documentation

- Task comments with CIS control references
- Variable descriptions
- Complex logic explanations
- Operator-managed configuration warnings
- Version-specific notes

## Success Criteria

The design will be considered successful when:

1. All 15 requirements from the requirements document are fully addressed
2. Audit tasks can verify all CIS L1 and L2 controls
3. Remediation tasks can apply fixes for all remediable controls
4. Playbooks execute without errors on OpenShift 4.14+
5. Reports provide clear, actionable compliance information
6. Documentation enables new users to run automation within 30 minutes
7. Error handling prevents single failures from halting execution
8. Idempotency is verified through repeated execution
9. Tag-based filtering works for all execution modes
10. Integration tests pass on multiple OpenShift versions
