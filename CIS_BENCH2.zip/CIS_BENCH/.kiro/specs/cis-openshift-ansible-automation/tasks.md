# Implementation Plan

## Project Setup and Infrastructure

- [x] 1. Create project directory structure and configuration files
  - Create the base directory structure: `playbooks/`, `roles/`, `group_vars/`, `inventory/`, `library/`, `filter_plugins/`
  - Create `requirements.yml` for Ansible collection dependencies (kubernetes.core, community.general)
  - Create example inventory file at `inventory/hosts.example` with control plane and worker node groups
  - Create `group_vars/all.yml` with default configuration variables (cis_mode, cis_level, OpenShift connection details, reporting settings)
  - Create root `README.md` with installation instructions, prerequisites, and quick start guide
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 13.1, 13.3, 13.4, 14.1, 14.2, 14.3, 14.4_

## Core Playbook Implementation

- [x] 2. Implement main audit and remediation playbooks
  - Create `playbooks/audit_l1.yml` that sets `cis_level: 1` and `cis_mode: audit`, includes all section roles with audit tags
  - Create `playbooks/audit_l2.yml` that sets `cis_level: 2` and `cis_mode: audit`, includes all section roles with audit tags
  - Create `playbooks/remediate_l1.yml` that sets `cis_level: 1` and `cis_mode: remediate`, includes all section roles with remediate tags
  - Create `playbooks/remediate_l2.yml` that sets `cis_level: 2` and `cis_mode: remediate`, includes all section roles with remediate tags
  - Create `playbooks/audit_and_remediate.yml` that supports both modes sequentially
  - Add usage instructions as comments at the top of each playbook with execution examples
  - _Requirements: 1.1, 1.3, 2.1, 3.1, 4.1, 5.1, 5.2, 6.1, 6.2, 14.1, 14.4_

## Section 1: Control Plane Components Role

- [x] 3. Implement CIS Section 1 role structure and subsection 1.1 (Master Node Configuration Files)
  - Create role directory structure: `roles/cis_section_1/tasks/`, `roles/cis_section_1/vars/`, `roles/cis_section_1/defaults/`
  - Create `roles/cis_section_1/tasks/main.yml` with conditional includes for audit.yml and remediate.yml based on cis_mode
  - Create `roles/cis_section_1/tasks/audit.yml` with OpenShift version detection task
  - Implement audit tasks for controls 1.1.1-1.1.21 (file permissions and ownership for API server, controller manager, scheduler, etcd pod specs, PKI files, kubeconfig files)
  - Use `oc debug node/<node>` commands to check file permissions and ownership on control plane nodes
  - Set version-specific expected permissions (600 for 4.14+, 644 for older versions)
  - Record results in `cis_results` fact array with control number, status, expected vs actual values
  - Add appropriate tags: `section1`, `section1.1`, `control_1.1.X`, `level1`, `audit`
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 7.1, 7.2, 7.3, 7.4, 8.1, 8.2, 10.1, 10.2, 12.1_

- [x] 4. Implement Section 1 subsection 1.2 (API Server) audit tasks
  - Implement audit tasks for controls 1.2.1-1.2.35 covering API server configuration arguments
  - Query API server configmap: `oc get configmap config -n openshift-kube-apiserver -ojson`
  - Parse and verify API server arguments: anonymous-auth, basic-auth-file, token-auth-file, authorization-mode, admission plugins, etc.
  - Check TLS settings, certificate configurations, encryption provider config, audit policy
  - Verify profiling, request timeout, service account settings
  - Mark operator-managed settings appropriately in audit results
  - Add tags: `section1`, `section1.2`, `control_1.2.X`, `level1` or `level2`, `audit`
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 7.1, 7.2, 7.3, 8.1, 8.2, 15.1, 15.2_

- [x] 5. Implement Section 1 subsections 1.3 and 1.4 (Controller Manager and Scheduler) audit tasks
  - Implement audit tasks for controls 1.3.1-1.3.7 (Controller Manager configuration)
  - Query controller manager configmap: `oc get configmap config -n openshift-kube-controller-manager -ojson`
  - Verify terminated-pod-gc-threshold, profiling, use-service-account-credentials, service-account-private-key-file, root-ca-file, bind-address
  - Implement audit tasks for controls 1.4.1-1.4.2 (Scheduler configuration)
  - Query scheduler configmap: `oc get configmap config -n openshift-kube-scheduler -ojson`
  - Verify profiling and bind-address settings
  - Add tags: `section1`, `section1.3`, `section1.4`, `control_1.3.X`, `control_1.4.X`, `level1`, `audit`
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 7.1, 7.2, 8.1, 8.2_

- [x] 6. Implement Section 1 remediation tasks
  - Create `roles/cis_section_1/tasks/remediate.yml`
  - For controls 1.1.X (file permissions): Add tasks that output "Operator-managed, no remediation available" messages
  - For controls 1.2.X, 1.3.X, 1.4.X (API server, controller manager, scheduler): Document that settings are operator-managed
  - Provide guidance comments on proper configuration methods using operator CRDs where applicable
  - Add tags: `section1`, `control_1.X.X`, `level1` or `level2`, `remediate`
  - Use `when: cis_mode in ['remediate', 'both']` conditions
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 8.1, 8.2, 15.1, 15.2, 15.3, 15.4_

## Section 2: etcd Role

- [x] 7. Implement CIS Section 2 role for etcd configuration
  - Create role directory structure: `roles/cis_section_2/tasks/`, `roles/cis_section_2/vars/`, `roles/cis_section_2/defaults/`
  - Create `roles/cis_section_2/tasks/main.yml` with conditional includes
  - Create `roles/cis_section_2/tasks/audit.yml` for controls 2.1-2.7
  - Verify etcd certificate and key file configuration (cert-file, key-file, client-cert-auth, auto-tls, peer-cert-file, peer-key-file, peer-client-cert-auth, peer-auto-tls)
  - Query etcd pod configuration: `oc get pod -n openshift-etcd -l app=etcd -o json`
  - Check etcd data directory permissions and ownership (/var/lib/etcd, should be 700, etcd:etcd)
  - Verify unique certificate authorities for etcd
  - Add tags: `section2`, `control_2.X`, `level1` or `level2`, `audit`
  - Create `roles/cis_section_2/tasks/remediate.yml` documenting operator-managed configurations
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.1, 2.2, 2.3, 7.1, 7.2, 8.1, 8.2, 15.1, 15.2_

## Section 3: Control Plane Configuration Role

- [x] 8. Implement CIS Section 3 role for authentication and logging
  - Create role directory structure: `roles/cis_section_3/tasks/`, `roles/cis_section_3/vars/`, `roles/cis_section_3/defaults/`
  - Create `roles/cis_section_3/tasks/main.yml` with conditional includes
  - Create `roles/cis_section_3/tasks/audit.yml` for controls 3.1.1-3.2.2
  - Implement subsection 3.1 (Authentication and Authorization): Verify anonymous authentication, insecure port, insecure bind address, secure port, profiling, DenyServiceExternalIPs admission plugin
  - Implement subsection 3.2 (Logging): Check audit logs configuration, audit policy, log retention, log rotation, log forwarding
  - Query OAuth configuration: `oc get oauth cluster -o json`
  - Check for kubeadmin secret: `oc get secret kubeadmin -n kube-system`
  - Verify audit configuration in API server configmap
  - Add tags: `section3`, `section3.1`, `section3.2`, `control_3.X.X`, `level1` or `level2`, `audit`
  - Create `roles/cis_section_3/tasks/remediate.yml` with tasks for configurable settings (audit retention, log forwarding)
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.1, 2.2, 2.4, 7.1, 7.2, 8.1, 8.2, 9.1, 9.2, 15.1, 15.2_

## Section 4: Worker Nodes Role

- [x] 9. Implement CIS Section 4 role for worker node configuration
  - Create role directory structure: `roles/cis_section_4/tasks/`, `roles/cis_section_4/vars/`, `roles/cis_section_4/defaults/`
  - Create `roles/cis_section_4/tasks/main.yml` with conditional includes
  - Create `roles/cis_section_4/tasks/audit.yml` for controls 4.1.1-4.2.13
  - Implement subsection 4.1 (Worker Node Configuration Files): Verify kubelet service file permissions and ownership, kubelet.conf permissions, certificate authorities
  - Implement subsection 4.2 (Kubelet Configuration): Check kubelet config via node proxy API
  - Query kubelet config: `oc get --raw /api/v1/nodes/<node>/proxy/configz`
  - Verify anonymous-auth, authorization-mode, client-ca-file, read-only-port, streaming-connection-idle-timeout, protect-kernel-defaults, make-iptables-util-chains, event-qps, tls-cert-file, tls-private-key-file, rotate-certificates, RotateKubeletServerCertificate, tls-cipher-suites
  - Target worker node group from inventory
  - Add tags: `section4`, `section4.1`, `section4.2`, `control_4.X.X`, `level1` or `level2`, `audit`
  - Create `roles/cis_section_4/tasks/remediate.yml` with MachineConfig-based remediation tasks for configurable kubelet settings
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.1, 2.2, 2.4, 7.1, 7.2, 8.1, 8.2, 9.1, 9.2, 12.1, 12.2, 12.3_

## Section 5: Policies Role

- [x] 10. Implement CIS Section 5 role structure and subsection 5.1 (RBAC and Service Accounts)
  - Create role directory structure: `roles/cis_section_5/tasks/`, `roles/cis_section_5/vars/`, `roles/cis_section_5/defaults/`
  - Create `roles/cis_section_5/tasks/main.yml` with conditional includes
  - Create `roles/cis_section_5/tasks/audit.yml` starting with controls 5.1.1-5.1.6
  - Verify RBAC is enabled (default in OpenShift, cannot be disabled)
  - Identify cluster-admin role bindings: `oc get clusterrolebindings -o json`
  - Check for default service account usage in pods
  - Verify service account token auto-mounting settings
  - Audit service account permissions and ensure least privilege
  - Add tags: `section5`, `section5.1`, `control_5.1.X`, `level1`, `audit`
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 7.1, 7.2, 8.1, 8.2, 12.4_

- [x] 11. Implement Section 5 subsection 5.2 (Security Context Constraints) audit tasks
  - Implement audit tasks for controls 5.2.1-5.2.13
  - Query all SCCs: `oc get scc -o json`
  - Identify pods using privileged SCCs: `oc get pods -A -o json | jq '.items[] | select(.metadata.annotations."openshift.io/scc"|test("privileged"))'`
  - Check for pods without SCC annotations
  - Verify SCC settings: allowPrivilegedContainer, allowPrivilegeEscalation, allowHostNetwork, allowHostPorts, allowHostPID, allowHostIPC, runAsUser, SELinux, capabilities
  - Audit custom SCCs for security misconfigurations
  - Add tags: `section5`, `section5.2`, `control_5.2.X`, `level1` or `level2`, `audit`
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 7.1, 7.2, 8.1, 8.2_

- [x] 12. Implement Section 5 subsections 5.3, 5.4, 5.5, 5.7 (Network Policies, Secrets, Admission Control, General Policies) audit tasks
  - Implement controls 5.3.1-5.3.2 (Network Policies): Check for NetworkPolicy objects in each namespace
  - Implement controls 5.4.1-5.4.2 (Secrets Management): Verify secrets are not exposed as environment variables, check encryption at rest
  - Implement controls 5.5.1 (Admission Control): Verify admission controllers configuration
  - Implement controls 5.7.1-5.7.4 (General Policies): Check seccomp profiles, AppArmor profiles (N/A for OpenShift), security contexts, namespace resource quotas
  - Query namespaces: `oc get namespaces -o json`
  - Check for network policies: `oc get networkpolicies -A -o json`
  - Find pods without seccomp profiles: `oc get pods -A -o json | jq '.items[] | select(.spec.securityContext.seccompProfile.type==null)'`
  - Add tags: `section5`, `section5.3`, `section5.4`, `section5.5`, `section5.7`, `control_5.X.X`, `level1` or `level2`, `audit`
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 7.1, 7.2, 8.1, 8.2_

- [x] 13. Implement Section 5 remediation tasks
  - Create `roles/cis_section_5/tasks/remediate.yml`
  - Implement remediation for 5.1.X: Configure service account token auto-mount to false where appropriate
  - Implement remediation for 5.2.X: Provide guidance on creating custom SCCs with secure defaults
  - Implement remediation for 5.3.X: Create default deny-all NetworkPolicy templates for namespaces
  - Implement remediation for 5.4.X: Document secrets management best practices
  - Implement remediation for 5.7.X: Apply default seccomp profiles to pods, set security contexts
  - Use k8s module for applying Kubernetes resources
  - Add tags: `section5`, `control_5.X.X`, `level1` or `level2`, `remediate`
  - _Requirements: 2.1, 2.2, 2.4, 7.1, 7.2, 8.1, 8.2, 9.1, 9.2_

## Reporting and Error Handling

- [x] 14. Implement reporting and summary generation
  - Create custom Jinja2 filter in `filter_plugins/cis_filters.py` for formatting audit results
  - Add task at end of each playbook to generate summary statistics (total, passed, failed, manual, errors)
  - Implement JSON report generation with structure: execution_timestamp, openshift_version, cis_benchmark_version, level, mode, summary, results_by_section, detailed_results
  - Implement YAML report generation as alternative format
  - Create report output directory based on `report_output_dir` variable
  - Add timestamp to report filenames
  - Display summary to console at playbook completion
  - _Requirements: 1.3, 1.5, 3.3, 3.4, 4.3, 4.4, 8.4, 11.1, 11.2, 11.3, 11.4_

- [x] 15. Implement comprehensive error handling across all roles
  - Add `block/rescue/always` structure to critical tasks in all role audit files
  - Use `ignore_errors: yes` on audit tasks to continue execution on failures
  - Capture error details in result structures with error type categorization (CONNECTION_ERROR, PERMISSION_ERROR, OPERATOR_MANAGED, etc.)
  - Implement failure tracking per section with configurable threshold (`max_failures_per_section`)
  - Add error summary section to final report
  - Ensure all tasks record results even on failure
  - _Requirements: 8.1, 8.2, 8.3, 8.4_

## Documentation and Examples

- [x] 16. Create comprehensive documentation
  - Update root `README.md` with complete installation instructions, prerequisites (Ansible version, Python, oc CLI, collections)
  - Document all configuration variables in `group_vars/all.yml` with descriptions and examples
  - Create role-specific README.md files in each `roles/cis_section_X/` directory documenting covered controls, variables, dependencies, known limitations
  - Add inline comments to all tasks with CIS control references and explanations
  - Document operator-managed configurations and why they cannot be remediated
  - Provide troubleshooting section with common issues and solutions
  - Include examples for all execution modes: audit-only, remediation-only, combined, tag-based filtering, specific sections, specific controls
  - Document required RBAC permissions and provide example ClusterRole definition
  - _Requirements: 9.4, 13.4, 14.1, 14.2, 14.3, 14.4, 15.1, 15.2, 15.3, 15.4_

## Integration and Validation

- [x] 17. Create example configurations and validate end-to-end functionality
  - Populate `inventory/hosts.example` with realistic example inventory structure (control plane and worker groups)
  - Populate `group_vars/all.yml` with all required default variables and secure recommended values
  - Create `.gitignore` file to exclude sensitive files (inventory/hosts, *.retry, reports/)
  - Validate all playbooks have correct syntax using `ansible-playbook --syntax-check`
  - Verify all roles are properly referenced in playbooks
  - Ensure all tags are consistently applied across tasks
  - Test tag filtering works correctly for sections and individual controls
  - Verify variable precedence and defaults work as expected
  - _Requirements: 9.1, 9.2, 9.3, 10.1, 10.2, 10.3, 10.4, 13.1, 13.2, 13.3_
