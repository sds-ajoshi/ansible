---
inclusion: always
---

# CIS Red Hat OpenShift Container Platform Security Benchmark

Guidance for OpenShift 4 security compliance based on CIS Benchmark v1.8.0 (tested against OpenShift 4.18).

## Core Principles

- **Default Security**: OpenShift 4 is secure by default; most CIS recommendations are pre-implemented
- **Operator-Managed**: Configuration managed by OpenShift operators; manual changes cause degraded state
- **Non-Remediable**: Many settings are automatically managed and cannot be changed
- **Audit-Focused**: Verify configurations rather than modify them

## Architecture Components

### Control Plane
- **API Servers**: OpenShift API server and Kubernetes API server (kube-apiserver)
- **Controller Managers**: OpenShift and Kube Controller Managers
- **Scheduler**: Kubernetes Scheduler (kube-scheduler)
- **etcd**: Key-value store for cluster state
- **Machine Config Operator**: Manages node configurations

### Security Context Constraints (SCCs)
OpenShift uses SCCs instead of Pod Security Policies. Default SCCs:
- `restricted-v2` (default for authenticated users)
- `nonroot-v2`
- `hostnetwork-v2`
- `privileged`
- `anyuid`

## Common Audit Commands

### File Permissions and Ownership
```bash
# Check permissions (should be 600 or 644)
oc exec -n <namespace> <pod> -- stat -c %a <file-path>

# Check ownership (should be root:root)
oc exec -n <namespace> <pod> -- stat -c %U:%G <file-path>
```

### API Server Configuration
```bash
# View API server arguments
oc get configmap config -n openshift-kube-apiserver -ojson | \
  jq -r '.data["config.yaml"]' | jq '.apiServerArguments'

# Check admission plugins
oc get configmap config -n openshift-kube-apiserver -ojson | \
  jq -r '.data["config.yaml"]' | jq '.apiServerArguments."enable-admission-plugins"'
```

### Kubelet Configuration
```bash
# Check kubelet config on all nodes
for node in $(oc get nodes -ojsonpath='{.items[*].metadata.name}'); do
  oc get --raw /api/v1/nodes/$node/proxy/configz | jq '.kubeletconfig'
done
```

### RBAC and Access Control
```bash
# List cluster-admin users
oc get clusterrolebindings -o=custom-columns=NAME:.metadata.name,ROLE:.roleRef.name,SUBJECT:.subjects[*].kind | grep cluster-admin

# Check permissions
oc adm policy who-can <verb> <resource>
```

## Security Areas

### Authentication and Authorization
- Anonymous requests authorized but restricted to specific endpoints
- RBAC enabled by default (cannot be disabled)
- Avoid client certificate authentication for users (use identity providers)
- Service accounts use unique credentials per controller

### Encryption and TLS
- All API communication uses HTTPS with X.509 certificates
- etcd communication encrypted with separate CAs
- Minimum TLS version: 1.2 (configurable via `tlsSecurityProfile`)
- Profiles: Old, Intermediate (default), Modern, Custom
- HAProxy Ingress controller does not support TLS 1.3

### Audit Logging
- Enabled by default
- Logs: `/var/log/kube-apiserver/audit.log` and `/var/log/openshift-apiserver/audit.log`
- Default profile: `Default` (options: `WriteRequestBodies`, `AllRequestBodies`, `None`)
- Retention: 10 files by default

### Network Policies
- OpenShift SDN and OVN-Kubernetes support ingress/egress policies
- Default: all pods in a project are accessible
- Create NetworkPolicy objects to isolate pods

### Secrets Management
- Prefer mounting secrets as files over environment variables
- Consider external secret storage (Vault, etc.)
- Service account tokens should only be mounted when necessary

## Key File Locations

### Control Plane
- API server pod spec: `/etc/kubernetes/manifests/kube-apiserver-pod.yaml`
- Controller manager pod spec: `/etc/kubernetes/manifests/kube-controller-manager-pod.yaml`
- Scheduler pod spec: `/etc/kubernetes/manifests/kube-scheduler-pod.yaml`
- etcd pod spec: `/etc/kubernetes/manifests/etcd-pod.yaml`
- Certificates: `/etc/kubernetes/static-pod-certs/secrets/`
- Kubeconfig: `/etc/kubernetes/kubeconfig`

### Worker Nodes
- Kubelet service: `/etc/systemd/system/kubelet.service` or `/usr/lib/systemd/system/kubelet.service`
- Kubelet config: `/var/lib/kubelet/config.json` or `/var/data/kubelet/config.json` (4.13+)
- Kubelet kubeconfig: `/etc/kubernetes/kubelet.conf`
- Client CA: `/etc/kubernetes/kubelet-ca.crt`

### etcd
- Data directory: `/var/lib/etcd`
- Ownership: `etcd:etcd`
- Permissions: 700

## Important Defaults

### File Permissions (OpenShift 4.14+)
- Pod specs: 600 (older versions: 644, not remediable)
- Kubeconfig files: 600 (older versions: 644, not remediable)
- Certificates: 600
- Configuration files: 644

### Ownership
- All control plane files: `root:root`
- etcd data directory: `etcd:etcd`

## Common Verification Patterns

### Check SCC Usage
```bash
# Find pods using privileged SCC
oc get pods -A -o json | jq '.items[] | select(.metadata.annotations."openshift.io/scc"|test("privileged"?)) | .metadata.name'

# Find pods without SCC
oc get pods -A -o json | jq '.items[] | select(.metadata.annotations."openshift.io/scc" == null) | .metadata.name'
```

### Check Seccomp Profiles
```bash
# Find pods without seccomp profile
oc get pods -A -o json | jq '.items[] | select((.metadata.namespace | test("^kube*|^openshift*") | not) and .spec.securityContext.seccompProfile.type==null) | (.metadata.namespace + "/" + .metadata.name)'
```

### Check Service Account Token Mounting
```bash
# Find pods that auto-mount service account tokens
oc get pods -A -o json | jq '.items[] | select(.spec.automountServiceAccountToken) | .metadata.name'

# Find service accounts that auto-mount tokens
oc get serviceaccounts -A -o json | jq '.items[] | select(.automountServiceAccountToken) | .metadata.name'
```

## Remediation Guidelines

### DO NOT Remediate
- File permissions on operator-managed files (causes degraded cluster state)
- Default operator configurations
- Platform component settings

### Safe to Configure
- Identity providers (remove kubeadmin after setup)
- Network policies per namespace
- Custom SCCs for specific workloads
- TLS security profiles
- Audit log retention and forwarding
- etcd encryption at rest

### Testing Approach
1. Test in non-production environment first
2. Review Impact section of CIS recommendation
3. Deploy to small subset of production
4. Monitor for issues before full rollout
5. Document exceptions with business justification

## Version-Specific Notes

- OpenShift 4.14+: File permissions improved to 600 (earlier versions: 644)
- OpenShift 4.13+: Kubelet config moved to `/var/data/kubelet/config.json`
- OpenShift 4.6+: `kubelet-read-only-port` set to 0 by default
- OpenShift 4.4+: etcd managed by cluster-etcd-operator

## References

- [OpenShift Security Documentation](https://docs.openshift.com/container-platform/latest/security/)
- [CIS Benchmark for OpenShift](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift Operators Reference](https://docs.openshift.com/container-platform/latest/operators/operator-reference.html)
