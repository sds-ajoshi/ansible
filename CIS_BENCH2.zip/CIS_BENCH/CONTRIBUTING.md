# Contributing to CIS OpenShift Ansible Automation

Thank you for your interest in contributing to the CIS OpenShift Ansible Automation suite! This document provides guidelines for contributing to the project.

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help maintain a welcoming environment

## How to Contribute

### Reporting Issues

When reporting issues, please include:
- OpenShift version
- Ansible version
- CIS Benchmark version
- Detailed description of the issue
- Steps to reproduce
- Expected vs actual behavior
- Relevant log output or error messages

### Suggesting Enhancements

Enhancement suggestions are welcome! Please include:
- Clear description of the enhancement
- Use case and benefits
- Potential implementation approach
- Any relevant CIS controls or requirements

### Contributing Code

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Make your changes following the guidelines below
4. Test your changes thoroughly
5. Commit with clear, descriptive messages
6. Push to your fork
7. Create a Pull Request

## Development Guidelines

### Directory Structure

Follow the established directory structure:

```
cis-openshift-ansible/
├── playbooks/           # Main playbooks
├── roles/              # Role-based organization by CIS section
│   └── cis_section_X/
│       ├── tasks/
│       │   ├── main.yml
│       │   ├── audit.yml
│       │   └── remediate.yml
│       ├── vars/
│       ├── defaults/
│       └── README.md
├── group_vars/         # Variable definitions
├── inventory/          # Inventory examples
├── filter_plugins/     # Custom Jinja2 filters
├── library/            # Custom Ansible modules (if needed)
└── rbac-examples/      # RBAC configuration examples
```

### Task Naming Conventions

All tasks must follow this naming convention:

```yaml
- name: "CIS <section>.<subsection>.<control> - <description>"
```

Examples:
```yaml
- name: "CIS 1.1.1 - Ensure that the API server pod specification file permissions are set to 600 or more restrictive"
- name: "CIS 5.1.5 - Ensure that default service accounts are not actively used"
```

### Inline Comments and Documentation

#### Task File Structure

Each task file should include:

1. **File Header Comment**: Describe the section and subsection
```yaml
---
# CIS Section X - <Section Name> - Audit Tasks
# Subsection X.Y: <Subsection Name>
```

2. **Control Reference Comment**: Before each control implementation
```yaml
# CIS X.Y.Z - <Control Title>
# Level: L1 or L2
# Assessment: Automated or Manual
# Remediation: Available, Not Available, Operator-Managed, Manual
```

3. **Implementation Comments**: Explain complex logic
```yaml
# Check file permissions using oc debug node command
# OpenShift 4.14+ expects 600, earlier versions expect 644
```

#### Example Task with Complete Documentation

```yaml
---
# CIS Section 1 - Control Plane Components - Audit Tasks
# Subsection 1.1: Master Node Configuration Files

# CIS 1.1.1 - API server pod specification file permissions
# Level: L1
# Assessment: Automated
# Remediation: Operator-Managed (cannot be manually changed)
- name: "CIS 1.1.1 - Ensure that the API server pod specification file permissions are set to 600 or more restrictive"
  block:
    # Use oc debug to access control plane node filesystem
    # File location: /etc/kubernetes/manifests/kube-apiserver-pod.yaml
    - name: "Check API server pod spec file permissions"
      shell: |
        oc debug node/{{ control_plane_node.stdout }} -- \
          chroot /host stat -c %a /etc/kubernetes/manifests/kube-apiserver-pod.yaml
      register: api_server_perms
      failed_when: false
      changed_when: false
      delegate_to: localhost

    # Compare actual permissions against version-specific expectations
    # OpenShift 4.14+: 600, earlier versions: 644
    - name: "Record CIS 1.1.1 result"
      set_fact:
        cis_results: "{{ cis_results + [result] }}"
      vars:
        result:
          control: "1.1.1"
          title: "Ensure that the API server pod specification file permissions are set to 600 or more restrictive"
          level: "L1"
          status: "{{ 'PASS' if (api_server_perms.stdout | int <= expected_file_permissions | int) else 'FAIL' }}"
          message: "File permissions: {{ api_server_perms.stdout }}, Expected: {{ expected_file_permissions }}"
          expected: "{{ expected_file_permissions }}"
          actual: "{{ api_server_perms.stdout }}"
          timestamp: "{{ ansible_date_time.iso8601 }}"
          host: "{{ control_plane_node.stdout }}"
  
  # Error handling: capture failures and continue execution
  rescue:
    - name: "Record CIS 1.1.1 error"
      set_fact:
        cis_results: "{{ cis_results + [error_result] }}"
      vars:
        error_result:
          control: "1.1.1"
          status: "ERROR"
          message: "Failed to execute audit: {{ ansible_failed_result.msg }}"
  
  # Tags enable selective execution
  tags:
    - section1          # All Section 1 tasks
    - section1.1        # Subsection 1.1 tasks
    - control_1.1.1     # This specific control
    - level1            # Level 1 controls
    - audit             # Audit tasks only
```

### Tagging Strategy

All tasks must include appropriate tags:

```yaml
tags:
  - section<X>              # Section number (e.g., section1, section5)
  - section<X>.<Y>          # Subsection (e.g., section1.1, section5.2)
  - control_<X>.<Y>.<Z>     # Specific control (e.g., control_1.1.1)
  - level<1|2>              # CIS level (level1 or level2)
  - audit|remediate         # Task type
```

### Error Handling

All tasks must implement proper error handling:

```yaml
- name: "Task name"
  block:
    # Main task logic
    - name: "Execute task"
      # ... task implementation ...
      
  rescue:
    # Error handling
    - name: "Handle error"
      set_fact:
        cis_results: "{{ cis_results + [error_result] }}"
      vars:
        error_result:
          control: "X.Y.Z"
          status: "ERROR"
          message: "{{ ansible_failed_result.msg }}"
  
  always:
    # Cleanup or final actions (optional)
    - name: "Cleanup"
      # ... cleanup tasks ...
```

### Result Structure

All audit tasks must record results in this format:

```yaml
result:
  control: "X.Y.Z"                    # CIS control number
  title: "Control title"              # Full control title
  level: "L1" or "L2"                 # CIS level
  assessment: "Automated" or "Manual" # Assessment type
  status: "PASS|FAIL|MANUAL|ERROR"    # Result status
  message: "Descriptive message"      # Human-readable message
  expected: "Expected value"          # What should be configured
  actual: "Actual value"              # What was found
  details: {}                         # Additional details (optional)
  timestamp: "ISO8601 timestamp"      # When the check was performed
  host: "hostname"                    # Target host
```

### Variable Naming

Follow these naming conventions:

- **Global variables**: `cis_*` prefix (e.g., `cis_mode`, `cis_level`)
- **Section variables**: `section<X>_*` prefix (e.g., `section1_controls`)
- **Temporary variables**: Descriptive names (e.g., `api_server_perms`, `control_plane_node`)
- **Result variables**: `*_result` suffix (e.g., `audit_result`, `error_result`)

### Operator-Managed Configurations

When documenting operator-managed configurations:

```yaml
# CIS X.Y.Z - Control Title
# Level: L1
# Assessment: Automated
# Remediation: Operator-Managed
# Note: This setting is managed by the <operator-name> operator.
#       Manual changes will be automatically reverted.
#       To configure properly, use: <proper configuration method>
```

Example:

```yaml
# CIS 1.1.1 - API server pod specification file permissions
# Level: L1
# Assessment: Automated
# Remediation: Operator-Managed
# Note: File permissions are managed by the cluster-kube-apiserver-operator.
#       Manual changes will be automatically reverted.
#       OpenShift 4.14+ sets permissions to 600 by default.
```

### README Documentation

Each role must include a README.md with:

1. **Overview**: Brief description of the section
2. **Controls Covered**: Table of all controls with status
3. **Variables**: Required and optional variables
4. **Dependencies**: Prerequisites and requirements
5. **Usage**: Examples of running the role
6. **Known Limitations**: Operator-managed settings, version-specific behavior
7. **Troubleshooting**: Common issues and solutions
8. **References**: Links to CIS Benchmark and OpenShift documentation

### Testing

Before submitting a pull request:

1. **Syntax Check**: `ansible-playbook playbooks/audit_l1.yml --syntax-check`
2. **Dry Run**: `ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --check`
3. **Test Environment**: Run against a test OpenShift cluster
4. **Multiple Versions**: Test against different OpenShift versions if possible
5. **Tag Filtering**: Verify tags work correctly
6. **Error Handling**: Test error scenarios

### Version Compatibility

- Document version-specific behavior in comments
- Use conditional logic for version differences
- Test against multiple OpenShift versions
- Update version compatibility in README

Example:

```yaml
# OpenShift 4.14+ uses 600 permissions, earlier versions use 644
- name: "Set version-specific expectations"
  set_fact:
    expected_permissions: "{{ '600' if openshift_version is version('4.14', '>=') else '644' }}"
```

## Pull Request Guidelines

### PR Title Format

Use clear, descriptive titles:
- `feat: Add Section X.Y controls`
- `fix: Correct permission check in control 1.1.1`
- `docs: Update README with troubleshooting section`
- `refactor: Improve error handling in Section 5`

### PR Description

Include in your PR description:
- Summary of changes
- Related issue numbers (if applicable)
- Testing performed
- OpenShift versions tested
- Breaking changes (if any)
- Documentation updates

### Checklist

Before submitting, ensure:
- [ ] Code follows naming conventions
- [ ] All tasks have proper tags
- [ ] Error handling is implemented
- [ ] Inline comments and documentation added
- [ ] README updated (if applicable)
- [ ] Tested against OpenShift cluster
- [ ] Syntax check passes
- [ ] No sensitive information in code

## Code Review Process

1. Automated checks run on PR submission
2. Maintainers review code and provide feedback
3. Address feedback and update PR
4. Once approved, PR is merged

## Questions?

If you have questions about contributing:
- Open an issue for discussion
- Review existing issues and PRs
- Check the documentation

## License

By contributing, you agree that your contributions will be licensed under the same license as the project.

## Thank You!

Your contributions help improve OpenShift security compliance for everyone!
