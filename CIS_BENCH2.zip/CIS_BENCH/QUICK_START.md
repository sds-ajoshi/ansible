# Quick Start Guide - CIS OpenShift Ansible Automation

Get up and running with CIS compliance auditing and remediation in minutes.

## Prerequisites Checklist

Before you begin, ensure you have:

- [ ] Ansible 2.15+ installed
- [ ] Python 3.9+ installed
- [ ] OpenShift CLI (oc) 4.14+ installed
- [ ] jq installed (`yum install jq` or `apt-get install jq`)
- [ ] Access to an OpenShift 4.14+ cluster
- [ ] Cluster-admin or appropriate RBAC permissions

## 5-Minute Setup

### Step 1: Clone and Install Dependencies

```bash
# Clone the repository
git clone <repository-url>
cd cis-openshift-ansible

# Install required Ansible collections
ansible-galaxy collection install -r requirements.yml
```

### Step 2: Verify OpenShift Access

```bash
# Login to your cluster
oc login https://api.your-cluster.example.com:6443

# Verify access
oc whoami
oc get nodes
```

### Step 3: Configure Inventory (Optional)

For basic usage, you can skip inventory configuration and use the default localhost setup. For advanced usage:

```bash
# Copy example inventory
cp inventory/hosts.example inventory/hosts

# Edit with your cluster details
vi inventory/hosts
```

### Step 4: Run Your First Audit

```bash
# Run Level 1 audit (read-only, safe to run)
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
```

### Step 5: Review Results

```bash
# View audit summary
cat ./cis_reports/cis_audit_report_*.json | jq '.summary'

# View detailed results
cat ./cis_reports/cis_audit_report_*.json | jq '.detailed_results[] | select(.status=="FAIL")'
```

## Common Workflows

### Workflow 1: Audit Only (Recommended First Step)

```bash
# Level 1 audit (basic security controls)
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml

# Level 2 audit (comprehensive security controls)
ansible-playbook -i inventory/hosts playbooks/audit_l2.yml

# Audit specific section only
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section5
```

### Workflow 2: Test Remediation (Dry-Run)

```bash
# See what would be changed without applying
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml \
  -e remediation_dry_run=true

# Review the dry-run output before proceeding
```

### Workflow 3: Apply Remediation

```bash
# Apply Level 1 remediations
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml

# Verify remediation worked
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
```

### Workflow 4: Production Deployment

```bash
# Step 1: Test environment audit
ansible-playbook -i inventory/hosts.test playbooks/audit_l1.yml

# Step 2: Test environment remediation (dry-run)
ansible-playbook -i inventory/hosts.test playbooks/remediate_l1.yml \
  -e remediation_dry_run=true

# Step 3: Apply to test environment
ansible-playbook -i inventory/hosts.test playbooks/remediate_l1.yml

# Step 4: Verify test environment
ansible-playbook -i inventory/hosts.test playbooks/audit_l1.yml

# Step 5: Apply to production (section by section)
ansible-playbook -i inventory/hosts.prod playbooks/remediate_l1.yml --tags section5
ansible-playbook -i inventory/hosts.prod playbooks/remediate_l1.yml --tags section3

# Step 6: Final production audit
ansible-playbook -i inventory/hosts.prod playbooks/audit_l1.yml
```

## Quick Reference Commands

### Audit Commands

```bash
# Basic audit
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml

# Audit with verbose output
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -v

# Audit specific section
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1

# Audit specific control
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_1.1.1

# Generate YAML report
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_format=yaml

# Generate HTML report
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_format=html
```

### Remediation Commands

```bash
# Dry-run (no changes)
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml \
  -e remediation_dry_run=true

# Apply remediations
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml

# Remediate specific section
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section5

# Remediate with check mode
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --check --diff
```

### Report Analysis

```bash
# View summary
cat ./cis_reports/cis_audit_report_*.json | jq '.summary'

# List all failed controls
cat ./cis_reports/cis_audit_report_*.json | \
  jq '.detailed_results[] | select(.status=="FAIL") | .control_id'

# View specific section results
cat ./cis_reports/cis_audit_report_*.json | \
  jq '.results_by_section.section_1'

# Count controls by status
cat ./cis_reports/cis_audit_report_*.json | \
  jq '.detailed_results | group_by(.status) | map({status: .[0].status, count: length})'
```

## Troubleshooting Quick Fixes

### Issue: Authentication Failed

```bash
# Re-login to cluster
oc login https://api.your-cluster.example.com:6443

# Verify access
oc whoami
oc get nodes
```

### Issue: Permission Denied

```bash
# Check your permissions
oc auth can-i get configmaps -n openshift-kube-apiserver
oc auth can-i list pods --all-namespaces

# Grant cluster-admin (if needed)
oc adm policy add-cluster-role-to-user cluster-admin <your-username>
```

### Issue: Collection Not Found

```bash
# Reinstall collections
ansible-galaxy collection install -r requirements.yml --force

# Verify installation
ansible-galaxy collection list | grep kubernetes.core
```

### Issue: Node Access Denied

```bash
# Test node debug access
oc debug node/$(oc get nodes -o jsonpath='{.items[0].metadata.name}') \
  -- chroot /host ls /etc/kubernetes

# Check privileged SCC access
oc get scc privileged -o yaml | grep -A 5 users
```

### Issue: Slow Execution

```bash
# Run specific section only
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1

# Skip manual controls
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --skip-tags manual
```

## Configuration Quick Reference

### Key Variables (group_vars/all.yml)

```yaml
# Execution mode
cis_mode: "audit"              # Options: audit, remediate, both
cis_level: 1                   # Options: 1, 2

# Cluster details
openshift_cluster_name: "ocp-cluster"
openshift_base_domain: "example.com"

# Reporting
report_output_dir: "./cis_reports"
report_format: "json"          # Options: json, yaml, html

# Remediation
remediation_dry_run: false
remediation_backup_enabled: true
skip_operator_managed: true
```

### Override Variables on Command Line

```bash
# Change CIS level
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e cis_level=2

# Change report format
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_format=yaml

# Enable dry-run
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml \
  -e remediation_dry_run=true

# Multiple overrides
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  -e cis_level=2 \
  -e report_format=yaml \
  -e report_output_dir=/tmp/reports
```

## Available Playbooks

| Playbook | Purpose | Safe for Production |
|----------|---------|---------------------|
| `audit_l1.yml` | Audit Level 1 controls | ✅ Yes (read-only) |
| `audit_l2.yml` | Audit Level 1 + Level 2 controls | ✅ Yes (read-only) |
| `remediate_l1.yml` | Apply Level 1 remediations | ⚠️ Test first |
| `remediate_l2.yml` | Apply Level 1 + Level 2 remediations | ⚠️ Test first |
| `audit_and_remediate.yml` | Combined audit and remediation | ⚠️ Test first |

## CIS Sections Overview

| Section | Description | Typical Audit Time |
|---------|-------------|-------------------|
| Section 1 | Control Plane Components | 5-10 min |
| Section 2 | etcd Configuration | 2-5 min |
| Section 3 | Control Plane Configuration | 3-7 min |
| Section 4 | Worker Nodes | 5-15 min |
| Section 5 | Policies (RBAC, SCCs, Network) | 10-20 min |

## Tag Reference

### Section Tags

```bash
--tags section1    # Control Plane Components
--tags section2    # etcd
--tags section3    # Control Plane Configuration
--tags section4    # Worker Nodes
--tags section5    # Policies
```

### Subsection Tags

```bash
--tags section1.1  # Master Node Configuration Files
--tags section1.2  # API Server
--tags section1.3  # Controller Manager
--tags section1.4  # Scheduler
--tags section5.1  # RBAC and Service Accounts
--tags section5.2  # Pod Security Standards
--tags section5.3  # Network Policies and CNI
--tags section5.4  # Secrets Management
--tags section5.5  # Extensible Admission Control
--tags section5.7  # General Policies
```

### Control Tags

```bash
--tags control_1.1.1   # Specific control
--tags control_5.1.5   # Specific control
```

### Special Tags

```bash
--tags level1      # All Level 1 controls
--tags level2      # All Level 2 controls
--tags manual      # Manual controls only
--skip-tags manual # Skip manual controls
```

## Best Practices

### ✅ DO

- Run audit before remediation
- Test in non-production environment first
- Use dry-run mode before applying changes
- Review audit reports before remediation
- Apply remediations section by section
- Monitor cluster health after remediation
- Keep backups enabled
- Document exceptions and deviations

### ❌ DON'T

- Skip testing in non-production
- Remediate without reviewing audit results
- Modify operator-managed configurations manually
- Apply all remediations at once in production
- Ignore "OPERATOR_MANAGED" warnings
- Disable backup functionality
- Run remediation during peak hours

## Next Steps

After completing the quick start:

1. Review the full [README.md](README.md) for detailed documentation
2. Check [FAQ.md](FAQ.md) for common questions
3. Review [ERROR_HANDLING.md](ERROR_HANDLING.md) for error resolution
4. Read [REPORTING.md](REPORTING.md) for report interpretation
5. See [CONTRIBUTING.md](CONTRIBUTING.md) to contribute

## Support

For detailed troubleshooting, see the main [README.md](README.md) Troubleshooting section.

For issues or questions, [open an issue](link-to-issues) or contact the maintainers.
