# RBAC Configuration Examples

This directory contains example RBAC (Role-Based Access Control) configurations for the CIS OpenShift Ansible Automation suite.

## Overview

The automation requires appropriate permissions to query and modify OpenShift cluster resources. Two ClusterRole examples are provided:

1. **cis-audit-clusterrole.yaml**: Read-only permissions for audit operations
2. **cis-remediation-clusterrole.yaml**: Read and write permissions for remediation operations

## Files

### cis-audit-clusterrole.yaml

Provides minimal permissions required for audit-only operations:
- Read access to all cluster resources
- Ability to create debug pods on nodes
- No write access to cluster configurations

**Use this for:**
- Regular compliance audits
- Read-only security assessments
- Environments where changes are not permitted

### cis-remediation-clusterrole.yaml

Provides full permissions required for both audit and remediation:
- Read access to all cluster resources
- Write access to policies, network policies, and configurations
- Ability to create and modify MachineConfigs and KubeletConfigs
- Limited write access to RBAC resources

**Use this for:**
- Full compliance automation
- Remediation of non-compliant controls
- Test and development environments

## Installation

### Option 1: Using Audit-Only Role

```bash
# Create the ClusterRole, ClusterRoleBinding, and ServiceAccount
oc apply -f rbac-examples/cis-audit-clusterrole.yaml

# Verify creation
oc get clusterrole cis-audit-role
oc get clusterrolebinding cis-audit-binding
oc get serviceaccount cis-automation -n default
```

### Option 2: Using Remediation Role

```bash
# Create the ClusterRole, ClusterRoleBinding, and ServiceAccount
oc apply -f rbac-examples/cis-remediation-clusterrole.yaml

# Verify creation
oc get clusterrole cis-remediation-role
oc get clusterrolebinding cis-remediation-binding
oc get serviceaccount cis-automation -n default
```

### Option 3: Using cluster-admin (Not Recommended for Production)

For testing or development environments, you can use the cluster-admin role:

```bash
# Create service account
oc create serviceaccount cis-automation -n default

# Grant cluster-admin
oc adm policy add-cluster-role-to-user cluster-admin \
  system:serviceaccount:default:cis-automation
```

**Warning**: cluster-admin provides unrestricted access. Use custom roles in production.

## Using the ServiceAccount

### Get ServiceAccount Token

```bash
# Get the token
TOKEN=$(oc sa get-token cis-automation -n default)

# Use token with oc commands
oc --token=$TOKEN get nodes
```

### Create Kubeconfig for ServiceAccount

```bash
# Get cluster info
CLUSTER_NAME=$(oc config view --minify -o jsonpath='{.clusters[0].name}')
CLUSTER_SERVER=$(oc config view --minify -o jsonpath='{.clusters[0].cluster.server}')
TOKEN=$(oc sa get-token cis-automation -n default)

# Create kubeconfig
cat > cis-automation-kubeconfig.yaml <<EOF
apiVersion: v1
kind: Config
clusters:
- cluster:
    server: ${CLUSTER_SERVER}
    insecure-skip-tls-verify: true
  name: ${CLUSTER_NAME}
contexts:
- context:
    cluster: ${CLUSTER_NAME}
    user: cis-automation
  name: cis-automation-context
current-context: cis-automation-context
users:
- name: cis-automation
  user:
    token: ${TOKEN}
EOF

# Test the kubeconfig
oc --kubeconfig=cis-automation-kubeconfig.yaml get nodes
```

### Use with Ansible

Update your `group_vars/all.yml`:

```yaml
openshift_kubeconfig: "/path/to/cis-automation-kubeconfig.yaml"
```

Or pass as extra variable:

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  -e openshift_kubeconfig=/path/to/cis-automation-kubeconfig.yaml
```

## Customization

### Modify Namespace

To use a different namespace than `default`:

```bash
# Edit the YAML files and change namespace
sed -i 's/namespace: default/namespace: cis-automation/g' rbac-examples/*.yaml

# Create the namespace
oc create namespace cis-automation

# Apply the configurations
oc apply -f rbac-examples/cis-audit-clusterrole.yaml
```

### Add Additional Permissions

To add custom permissions, edit the ClusterRole and add new rules:

```yaml
rules:
  # ... existing rules ...
  
  # Add custom rule
  - apiGroups: ["custom.example.com"]
    resources:
      - customresources
    verbs: ["get", "list", "watch"]
```

### Restrict to Specific Namespaces

To limit access to specific namespaces, use Role and RoleBinding instead of ClusterRole:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: cis-audit-role
  namespace: my-namespace
rules:
  # ... same rules as ClusterRole ...
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: cis-audit-binding
  namespace: my-namespace
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: cis-audit-role
subjects:
  - kind: ServiceAccount
    name: cis-automation
    namespace: default
```

## Verification

### Check Permissions

```bash
# Check if service account can list nodes
oc auth can-i list nodes \
  --as=system:serviceaccount:default:cis-automation

# Check if service account can create network policies
oc auth can-i create networkpolicies \
  --as=system:serviceaccount:default:cis-automation

# Check all permissions
oc auth can-i --list \
  --as=system:serviceaccount:default:cis-automation
```

### Test Access

```bash
# Get token
TOKEN=$(oc sa get-token cis-automation -n default)

# Test API access
oc --token=$TOKEN get nodes
oc --token=$TOKEN get configmaps -n openshift-kube-apiserver
oc --token=$TOKEN get scc
```

## Security Considerations

1. **Principle of Least Privilege**: Use audit-only role when remediation is not needed
2. **Token Security**: Protect ServiceAccount tokens as they provide cluster access
3. **Token Rotation**: Regularly rotate ServiceAccount tokens
4. **Audit Logging**: Enable audit logging for ServiceAccount activities
5. **Namespace Isolation**: Consider using dedicated namespace for automation
6. **Review Permissions**: Regularly review and update ClusterRole permissions

## Troubleshooting

### Permission Denied Errors

If you encounter permission errors:

```bash
# Check current permissions
oc auth can-i --list --as=system:serviceaccount:default:cis-automation

# Verify ClusterRoleBinding
oc get clusterrolebinding cis-audit-binding -o yaml

# Check ServiceAccount exists
oc get sa cis-automation -n default
```

### Token Expired

ServiceAccount tokens can expire. Regenerate:

```bash
# Delete old token secret
oc delete secret $(oc get secret -n default | grep cis-automation-token | awk '{print $1}')

# Get new token
TOKEN=$(oc sa get-token cis-automation -n default)
```

### ClusterRole Not Found

Ensure the ClusterRole was created:

```bash
# List ClusterRoles
oc get clusterrole | grep cis

# Recreate if missing
oc apply -f rbac-examples/cis-audit-clusterrole.yaml
```

## Cleanup

To remove the RBAC configurations:

```bash
# Remove audit role
oc delete -f rbac-examples/cis-audit-clusterrole.yaml

# Or remove remediation role
oc delete -f rbac-examples/cis-remediation-clusterrole.yaml

# Verify removal
oc get clusterrole | grep cis
oc get clusterrolebinding | grep cis
oc get sa cis-automation -n default
```

## References

- [OpenShift RBAC Documentation](https://docs.openshift.com/container-platform/latest/authentication/using-rbac.html)
- [Kubernetes RBAC](https://kubernetes.io/docs/reference/access-authn-authz/rbac/)
- [OpenShift Service Accounts](https://docs.openshift.com/container-platform/latest/authentication/understanding-and-creating-service-accounts.html)
