# Frequently Asked Questions (FAQ)

## General Questions

### What is this automation suite?

This is an Ansible-based automation suite that implements CIS Red Hat OpenShift Container Platform Benchmark v1.8.0 compliance controls. It provides both audit (verification) and remediation capabilities for Level 1 and Level 2 controls.

### Which OpenShift versions are supported?

- **Fully Supported**: OpenShift 4.14 and later
- **Supported**: OpenShift 4.13 with minor differences
- **Limited Support**: OpenShift 4.12 and earlier

Version-specific behaviors are automatically detected and handled.

### What is the difference between Level 1 and Level 2?

- **Level 1 (L1)**: Practical and prudent controls that provide clear security benefits without inhibiting functionality
- **Level 2 (L2)**: Controls for high-security environments that may reduce functionality; includes all L1 controls

### Can I run this in production?

Yes, but follow these best practices:
1. Test in non-production environment first
2. Run audit-only mode initially
3. Review audit results before remediation
4. Use dry-run mode for remediation testing
5. Apply remediations incrementally (section by section)
6. Monitor cluster health after changes

## Execution Questions

### How do I run only audit without making changes?

Use the audit playbooks:
```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
```

### How do I test remediation without applying changes?

Use dry-run mode:
```bash
ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml -e remediation_dry_run=true
```


### How do I run specific sections or controls?

Use tags:
```bash
# Run specific section
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1

# Run specific control
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_1.1.1

# Run multiple sections
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags "section1,section2"
```

### How long does a full audit take?

Execution time varies based on:
- Cluster size (number of nodes)
- Network latency
- Number of namespaces and resources
- Parallel execution settings

Typical times:
- Small cluster (3 masters, 3 workers): 10-15 minutes
- Medium cluster (3 masters, 10 workers): 20-30 minutes
- Large cluster (5 masters, 50+ workers): 45-60 minutes

### Can I run this from my laptop?

Yes! Requirements:
- Ansible 2.15+
- Python 3.9+
- OpenShift CLI (oc)
- Network access to OpenShift cluster
- Valid kubeconfig or credentials

## Operator-Managed Configuration Questions

### Why can't some controls be remediated?

OpenShift 4 uses operators to manage cluster configurations. Operators continuously reconcile settings, so manual changes are automatically reverted. This is by design to ensure cluster stability and consistency.

### Which controls are operator-managed?

Most controls in these sections:
- Section 1: Control Plane Components (file permissions, API server settings)
- Section 2: etcd configuration
- Section 4: Worker node file permissions

### How do I properly configure operator-managed settings?

Use operator CRDs and APIs:
- **API Server settings**: Modify `APIServer` resource
- **Kubelet settings**: Use `KubeletConfig` resource
- **Authentication**: Configure `OAuth` resource
- **Network settings**: Use `Network` operator configuration

See the [OpenShift documentation](https://docs.openshift.com/container-platform/latest/operators/operator-reference.html) for details.


### What happens if I manually change operator-managed files?

1. The operator detects the change
2. The operator reports degraded status
3. The change is automatically reverted (usually within minutes)
4. Cluster may experience temporary instability

**Never manually modify operator-managed configurations.**

## Permission and Access Questions

### What permissions are required?

For **audit-only**:
- Read access to all cluster resources
- Ability to create debug pods on nodes
- Access to OpenShift config resources

For **remediation**:
- All audit permissions
- Write access to policies, network policies, SCCs
- Ability to create/modify MachineConfigs and KubeletConfigs

See [rbac-examples/README.md](rbac-examples/README.md) for detailed ClusterRole definitions.

### Can I use a service account instead of my user credentials?

Yes! This is recommended for automation:
```bash
# Create service account
oc create serviceaccount cis-automation -n default

# Apply RBAC
oc apply -f rbac-examples/cis-audit-clusterrole.yaml

# Get token
TOKEN=$(oc sa get-token cis-automation -n default)

# Use in automation
oc --token=$TOKEN get nodes
```

### Do I need cluster-admin role?

- **For audit**: No, custom read-only role is sufficient
- **For remediation**: Recommended, or custom role with write permissions

See [rbac-examples/](rbac-examples/) for custom role examples.

## Reporting Questions

### Where are reports saved?

Default location: `./cis_reports/`

Configure in `group_vars/all.yml`:
```yaml
report_output_dir: "./cis_reports"
```

### What report formats are available?

- **JSON**: Machine-readable, default format
- **YAML**: Human-readable alternative
- **HTML**: Visual reports with charts (requires additional dependencies)


### How do I interpret audit results?

Result statuses:
- **PASS**: Control is compliant
- **FAIL**: Control is non-compliant
- **MANUAL**: Requires manual review or policy decision
- **ERROR**: Audit task failed to execute
- **OPERATOR_MANAGED**: Setting is operator-managed, no action needed

### Can I export results to a compliance tool?

Yes! Reports are in JSON format and can be integrated with:
- SIEM systems
- Compliance management platforms
- Custom dashboards
- Spreadsheet tools (convert JSON to CSV)

## Troubleshooting Questions

### Why am I getting "permission denied" errors?

Common causes:
1. Insufficient RBAC permissions
2. Invalid or expired kubeconfig
3. Service account token expired

Solutions:
```bash
# Check permissions
oc auth can-i list nodes

# Verify login
oc whoami

# Re-login if needed
oc login https://api.cluster.example.com:6443
```

### Why can't I access nodes with "oc debug"?

Requirements for `oc debug node`:
- Permissions to create privileged pods
- Access to nodes resource
- Privileged SCC usage

Verify:
```bash
oc auth can-i create pods
oc auth can-i use scc/privileged
```

### Tasks are failing with timeout errors

Solutions:
1. Increase timeout in `group_vars/all.yml`:
   ```yaml
   oc_command_timeout: 300
   ```
2. Check network connectivity
3. Verify cluster is healthy: `oc get co`

### Reports are empty or missing

Check:
1. Report directory exists and is writable
2. Playbook completed successfully
3. `report_include_details: true` in configuration
4. Review playbook output for errors


## Configuration Questions

### How do I configure for my environment?

1. Copy and edit inventory:
   ```bash
   cp inventory/hosts.example inventory/hosts
   # Edit with your cluster details
   ```

2. Configure variables in `group_vars/all.yml`:
   ```yaml
   openshift_cluster_name: "my-cluster"
   openshift_base_domain: "example.com"
   cis_level: 1
   ```

3. Set kubeconfig:
   ```yaml
   openshift_kubeconfig: "/path/to/kubeconfig"
   ```

### Can I customize which controls are checked?

Yes, using tags:
```bash
# Skip specific section
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --skip-tags section1

# Run only specific controls
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags "control_1.1.1,control_1.1.2"
```

### How do I exclude system namespaces?

Configure in role defaults or `group_vars/all.yml`:
```yaml
exclude_system_namespaces:
  - kube-system
  - openshift-*
  - my-system-namespace
```

## Remediation Questions

### Which controls can be automatically remediated?

Remediable controls include:
- Network policies (Section 5.3)
- Service account token mounting (Section 5.1)
- Seccomp profiles (Section 5.7)
- Some kubelet settings via KubeletConfig (Section 4.2)

Non-remediable controls:
- Operator-managed file permissions
- Identity provider configuration (requires manual setup)
- RBAC reviews (requires policy decisions)

### Will remediation cause downtime?

Most remediations do not cause downtime. However:
- **KubeletConfig changes**: Require node reboots (rolling restart)
- **Network policies**: May temporarily block traffic if misconfigured
- **SCC changes**: May affect running pods

Always test in non-production first!

### How do I rollback remediation changes?

1. **Backups**: Enable automatic backups:
   ```yaml
   remediation_backup_enabled: true
   ```

2. **Version Control**: Store configurations in git

3. **Manual Rollback**: Remove or modify applied resources:
   ```bash
   oc delete networkpolicy <policy-name>
   oc delete kubeletconfig <config-name>
   ```


## Advanced Questions

### Can I run this in a CI/CD pipeline?

Yes! Example GitLab CI:
```yaml
cis_audit:
  stage: compliance
  script:
    - ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
  artifacts:
    paths:
      - cis_reports/
```

### Can I customize the automation for my organization?

Yes! Options:
1. Add custom variables in `group_vars/all.yml`
2. Create custom roles for organization-specific controls
3. Extend filter plugins for custom reporting
4. Add custom modules in `library/` directory

### How do I integrate with external logging?

Configure audit log forwarding in OpenShift:
```bash
# Install OpenShift Logging operator
# Create ClusterLogForwarder resource
oc apply -f cluster-log-forwarder.yaml
```

See [OpenShift Logging documentation](https://docs.openshift.com/container-platform/latest/logging/cluster-logging.html).

### Can I run against multiple clusters?

Yes! Create separate inventory files:
```bash
# Cluster 1
ansible-playbook -i inventory/cluster1.hosts playbooks/audit_l1.yml

# Cluster 2
ansible-playbook -i inventory/cluster2.hosts playbooks/audit_l1.yml
```

Or use dynamic inventory with multiple clusters.

## Best Practices Questions

### What is the recommended workflow?

1. **Initial Assessment**:
   ```bash
   ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
   ```

2. **Review Results**:
   ```bash
   cat cis_reports/cis_audit_report_*.json | jq '.summary'
   ```

3. **Test Remediation** (dry-run):
   ```bash
   ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml -e remediation_dry_run=true
   ```

4. **Apply Remediation** (incrementally):
   ```bash
   ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml --tags section5
   ```

5. **Verify**:
   ```bash
   ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
   ```

6. **Monitor**:
   ```bash
   oc get clusteroperators
   ```

### How often should I run audits?

Recommended frequency:
- **Production**: Weekly or monthly
- **Development**: After significant changes
- **Compliance**: As required by policy (often quarterly)


### Should I remediate all failures?

Not necessarily:
1. **Review each failure**: Understand the impact
2. **Operator-managed**: No action needed
3. **Manual controls**: Requires policy decisions
4. **Business justification**: Some failures may be acceptable with documented exceptions

### How do I document exceptions?

Create an exceptions document:
```yaml
# cis_exceptions.yml
exceptions:
  - control: "5.1.1"
    reason: "Service account X requires cluster-admin for legitimate purpose"
    approved_by: "Security Team"
    review_date: "2025-12-31"
```

## Support Questions

### Where can I get help?

1. **Documentation**: Check README.md and role-specific READMEs
2. **FAQ**: This document
3. **Troubleshooting**: See README.md troubleshooting section
4. **Issues**: Open an issue on the repository
5. **Community**: OpenShift community forums

### How do I report bugs?

Open an issue with:
- OpenShift version
- Ansible version
- Steps to reproduce
- Expected vs actual behavior
- Relevant logs or error messages
- Playbook output (with `-vvv` if possible)

### How do I request new features?

Open an issue with:
- Feature description
- Use case and benefits
- Relevant CIS controls
- Proposed implementation (optional)

## Additional Resources

- [CIS Red Hat OpenShift Benchmark](https://www.cisecurity.org/benchmark/kubernetes)
- [OpenShift Security Documentation](https://docs.openshift.com/container-platform/latest/security/)
- [Ansible Documentation](https://docs.ansible.com/)
- [OpenShift Operators Reference](https://docs.openshift.com/container-platform/latest/operators/operator-reference.html)

## Still Have Questions?

If your question isn't answered here:
1. Check the [README.md](README.md)
2. Review role-specific documentation in `roles/cis_section_X/README.md`
3. Check [CONTRIBUTING.md](CONTRIBUTING.md) for development questions
4. Open an issue for clarification
