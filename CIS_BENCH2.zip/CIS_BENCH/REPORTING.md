# CIS OpenShift Ansible Automation - Reporting Guide

## Overview

This document describes the comprehensive reporting capabilities of the CIS OpenShift compliance automation suite, including error reporting, audit summaries, and detailed compliance reports.

## Report Types

### 1. Audit Reports

Generated after each audit execution, containing:
- Execution metadata (timestamp, OpenShift version, CIS level)
- Summary statistics (total, passed, failed, manual, errors)
- Section-level summaries
- Detailed results for each control
- Error summary (if errors occurred)

**File naming**: `cis_audit_l{1|2}_{timestamp}.{json|yml}`

### 2. Error Reports

Generated when errors occur during execution, containing:
- Total error count and error rate
- Errors categorized by type
- Errors grouped by section
- Critical error list
- Error statistics

**File naming**: `error_report_{timestamp}.json`

### 3. Error Statistics

Comprehensive error metrics including:
- Error counts by type, level, and section
- Critical error count
- Most common error type
- Sections with errors
- Error rate percentage

**File naming**: `error_statistics_{timestamp}.json`

## Report Formats

### JSON Format (Default)

```json
{
  "execution_timestamp": "2025-11-14T10:30:00Z",
  "openshift_version": "4.15.2",
  "cis_benchmark_version": "1.8.0",
  "level": "L1",
  "mode": "audit",
  "summary": {
    "total": 95,
    "passed": 78,
    "failed": 12,
    "manual": 5,
    "errors": 0,
    "compliance_percentage": 82.1
  },
  "error_summary": {
    "total_errors": 0,
    "errors_by_type": {},
    "critical_errors": []
  },
  "results_by_section": {
    "section_1": {
      "total": 35,
      "passed": 30,
      "failed": 3,
      "manual": 2,
      "errors": 0
    }
  },
  "detailed_results": [
    {
      "control": "1.1.1",
      "title": "Ensure that the API server pod specification file permissions are set to 600 or more restrictive",
      "level": "L1",
      "status": "PASS",
      "message": "File permissions are compliant",
      "expected": "600",
      "actual": "600",
      "timestamp": "2025-11-14T10:30:15Z",
      "host": "master-0.example.com"
    }
  ]
}
```

### YAML Format

```yaml
execution_timestamp: '2025-11-14T10:30:00Z'
openshift_version: '4.15.2'
cis_benchmark_version: '1.8.0'
level: L1
mode: audit
summary:
  total: 95
  passed: 78
  failed: 12
  manual: 5
  errors: 0
  compliance_percentage: 82.1
detailed_results:
  - control: '1.1.1'
    title: Ensure that the API server pod specification file permissions are set to 600 or more restrictive
    level: L1
    status: PASS
    message: File permissions are compliant
    expected: '600'
    actual: '600'
    timestamp: '2025-11-14T10:30:15Z'
    host: master-0.example.com
```

## Configuration

### Report Settings

Configure reporting in `group_vars/all.yml`:

```yaml
# Report output directory
report_output_dir: "./cis_reports"

# Report format (json or yaml)
report_format: "json"

# Include detailed results in report
report_include_details: true

# Include timestamp in report filename
report_timestamp_enabled: true

# Save error report to file
save_error_report: true

# Include recovery suggestions in error output
include_recovery_suggestions: true
```

### Report Generation

Reports are automatically generated at the end of playbook execution:

```bash
# Generate JSON report (default)
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml

# Generate YAML report
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_format=yaml

# Custom output directory
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml -e report_output_dir=/tmp/reports
```

## Report Structure

### Audit Report Schema

```json
{
  "execution_timestamp": "string (ISO 8601)",
  "openshift_version": "string",
  "cis_benchmark_version": "string",
  "level": "string (L1 or L2)",
  "mode": "string (audit, remediate, or both)",
  "summary": {
    "total": "integer",
    "passed": "integer",
    "failed": "integer",
    "manual": "integer",
    "errors": "integer",
    "compliance_percentage": "float"
  },
  "error_summary": {
    "total_errors": "integer",
    "errors_by_type": {
      "ERROR_TYPE": "integer"
    },
    "errors_by_section": {
      "section_X": [
        {
          "control": "string",
          "title": "string",
          "error_type": "string",
          "message": "string"
        }
      ]
    },
    "critical_errors": [
      {
        "control": "string",
        "error_type": "string",
        "message": "string"
      }
    ]
  },
  "results_by_section": {
    "section_X": {
      "total": "integer",
      "passed": "integer",
      "failed": "integer",
      "manual": "integer",
      "errors": "integer"
    }
  },
  "detailed_results": [
    {
      "control": "string",
      "title": "string",
      "level": "string (L1 or L2)",
      "assessment": "string (Automated or Manual)",
      "status": "string (PASS, FAIL, MANUAL, or ERROR)",
      "message": "string",
      "expected": "string",
      "actual": "string",
      "timestamp": "string (ISO 8601)",
      "host": "string",
      "error_type": "string (if status is ERROR)",
      "recovery_suggestions": ["string"] (if status is ERROR)
    }
  ]
}
```

### Error Report Schema

```json
{
  "total_errors": "integer",
  "errors_by_type": {
    "CONNECTION_ERROR": "integer",
    "PERMISSION_ERROR": "integer",
    "OPERATOR_MANAGED": "integer",
    "CONFIGURATION_ERROR": "integer",
    "RESOURCE_NOT_FOUND": "integer",
    "TIMEOUT_ERROR": "integer",
    "NOT_APPLICABLE": "integer",
    "UNKNOWN_ERROR": "integer"
  },
  "errors_by_section": {
    "section_1": [
      {
        "control": "string",
        "title": "string",
        "error_type": "string",
        "message": "string"
      }
    ]
  },
  "critical_errors": [
    {
      "control": "string",
      "error_type": "string",
      "message": "string"
    }
  ],
  "summary": "string (formatted summary text)"
}
```

### Error Statistics Schema

```json
{
  "total_controls": "integer",
  "total_errors": "integer",
  "critical_errors": "integer",
  "errors_by_type": {
    "ERROR_TYPE": "integer"
  },
  "errors_by_level": {
    "L1": "integer",
    "L2": "integer"
  },
  "errors_by_section": {
    "section_X": "integer"
  },
  "error_rate": "float (percentage)",
  "most_common_error_type": "string",
  "sections_with_errors": ["string"]
}
```

## Console Output

### Audit Summary

```
==========================================
CIS OpenShift Benchmark Level 1 Audit
Mode: audit
Level: 1
Timestamp: 2025-11-14T10:30:00Z
==========================================
OpenShift Version: 4.15.2

[... execution output ...]

==========================================
Audit Summary
==========================================
Total Controls: 95
Passed: 78
Failed: 12
Manual Review Required: 5
Errors: 0
Compliance: 82.1%
==========================================

Section section_1: 30/35 passed (3 failed, 2 manual)
Section section_2: 7/7 passed (0 failed, 0 manual)
Section section_3: 8/10 passed (1 failed, 1 manual)
Section section_4: 18/23 passed (5 failed, 2 manual)
Section section_5: 15/20 passed (3 failed, 0 manual)

Report saved to: ./cis_reports/cis_audit_l1_1731582600.json
```

### Error Summary

```
================================================================================
CIS OpenShift Compliance - Error Summary
================================================================================
Execution Time: 2025-11-14T10:30:00Z
CIS Level: L1
Mode: audit
================================================================================

Error Statistics:
  Total Controls Checked: 95
  Total Errors: 12
  Critical Errors: 2
  Error Rate: 12.63%
  
Errors by Type:
  - CONNECTION_ERROR: 2
  - PERMISSION_ERROR: 1
  - OPERATOR_MANAGED: 5
  - CONFIGURATION_ERROR: 2
  - RESOURCE_NOT_FOUND: 1
  - UNKNOWN_ERROR: 1

Errors by Level:
  - Level 1: 10
  - Level 2: 2

Sections with Errors: 1, 2, 4

Most Common Error Type: OPERATOR_MANAGED

================================================================================
CRITICAL ERRORS (2)
================================================================================
Control 1.1.1: CONNECTION_ERROR
  Message: Unable to connect to control plane node

Control 4.2.1: PERMISSION_ERROR
  Message: Insufficient permissions to query kubelet configuration

Error reports saved to:
  - ./cis_reports/error_report_1731582600.json
  - ./cis_reports/error_statistics_1731582600.json

================================================================================
Execution completed successfully with 12 errors
================================================================================
```

## Report Analysis

### Parsing Reports with jq

```bash
# Get total compliance percentage
jq '.summary.compliance_percentage' cis_audit_l1_*.json

# List all failed controls
jq '.detailed_results[] | select(.status == "FAIL") | {control, title}' cis_audit_l1_*.json

# Count errors by type
jq '.error_summary.errors_by_type' cis_audit_l1_*.json

# Get all critical errors
jq '.error_summary.critical_errors[]' cis_audit_l1_*.json

# List controls requiring manual review
jq '.detailed_results[] | select(.status == "MANUAL") | .control' cis_audit_l1_*.json

# Get section-level compliance
jq '.results_by_section' cis_audit_l1_*.json

# Extract specific section results
jq '.detailed_results[] | select(.control | startswith("1."))' cis_audit_l1_*.json
```

### Python Report Analysis

```python
import json

# Load report
with open('cis_audit_l1_1731582600.json') as f:
    report = json.load(f)

# Calculate compliance by section
for section, stats in report['results_by_section'].items():
    compliance = (stats['passed'] / stats['total']) * 100
    print(f"{section}: {compliance:.1f}% compliant")

# List failed controls
failed = [r for r in report['detailed_results'] if r['status'] == 'FAIL']
for control in failed:
    print(f"{control['control']}: {control['title']}")

# Analyze error patterns
error_types = report['error_summary']['errors_by_type']
for error_type, count in sorted(error_types.items(), key=lambda x: x[1], reverse=True):
    print(f"{error_type}: {count}")
```

## Report Integration

### CI/CD Integration

```yaml
# GitLab CI example
cis_audit:
  stage: compliance
  script:
    - ansible-playbook -i inventory/hosts playbooks/audit_l1.yml
  artifacts:
    paths:
      - cis_reports/
    reports:
      junit: cis_reports/cis_audit_l1_*.json
  allow_failure: true
```

### Compliance Dashboard

Reports can be ingested into compliance dashboards:

1. **Elasticsearch/Kibana**: Index JSON reports for visualization
2. **Grafana**: Create dashboards from report metrics
3. **Splunk**: Ingest reports for compliance monitoring
4. **Custom Dashboards**: Parse JSON reports with any tool

### Automated Alerting

```bash
# Example: Alert on low compliance
#!/bin/bash
REPORT=$(ls -t cis_reports/cis_audit_l1_*.json | head -1)
COMPLIANCE=$(jq '.summary.compliance_percentage' $REPORT)

if (( $(echo "$COMPLIANCE < 80" | bc -l) )); then
    echo "ALERT: Compliance below 80%: $COMPLIANCE%"
    # Send alert (email, Slack, PagerDuty, etc.)
fi
```

## Report Retention

### Cleanup Old Reports

```bash
# Keep only last 30 days of reports
find cis_reports/ -name "cis_audit_*.json" -mtime +30 -delete
find cis_reports/ -name "error_report_*.json" -mtime +30 -delete
```

### Archive Reports

```bash
# Archive reports by month
MONTH=$(date +%Y-%m)
mkdir -p archives/$MONTH
mv cis_reports/cis_audit_*.json archives/$MONTH/
tar -czf archives/cis_reports_$MONTH.tar.gz archives/$MONTH/
```

## Troubleshooting

### No Report Generated

1. Check playbook completed successfully
2. Verify `report_output_dir` exists and is writable
3. Check for errors in post_tasks section
4. Ensure `cis_results` variable is populated

### Incomplete Report

1. Verify all roles executed
2. Check for task failures in roles
3. Review error summary for issues
4. Ensure `continue_on_error: true` is set

### Report Parsing Errors

1. Validate JSON syntax: `jq . report.json`
2. Check for special characters in messages
3. Verify report schema matches expected structure
4. Review Ansible output for serialization errors

## Best Practices

1. **Regular Audits**: Schedule automated audits (daily/weekly)
2. **Report Retention**: Keep reports for compliance audit trail
3. **Trend Analysis**: Compare reports over time to track improvements
4. **Error Review**: Regularly review error reports and address issues
5. **Documentation**: Document exceptions and manual review results
6. **Integration**: Integrate reports with existing compliance tools
7. **Backup**: Backup reports to secure storage
8. **Access Control**: Restrict access to reports (may contain sensitive info)

## References

- [CIS Benchmark Documentation](https://www.cisecurity.org/benchmark/kubernetes)
- [Ansible Reporting](https://docs.ansible.com/ansible/latest/user_guide/playbooks_intro.html)
- [jq Manual](https://stedolan.github.io/jq/manual/)
