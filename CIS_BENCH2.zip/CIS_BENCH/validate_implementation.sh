#!/bin/bash
# Comprehensive validation script for CIS OpenShift Ansible Automation

# Don't exit on error - we want to collect all test results
set +e

echo "=========================================="
echo "CIS OpenShift Ansible Automation"
echo "Implementation Validation"
echo "=========================================="
echo ""

# Color codes for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
TESTS_PASSED=0
TESTS_FAILED=0

# Function to print test result
print_result() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✓ PASS${NC}: $2"
        ((TESTS_PASSED++))
    else
        echo -e "${RED}✗ FAIL${NC}: $2"
        ((TESTS_FAILED++))
    fi
}

echo "Test 1: Validate directory structure"
echo "--------------------------------------"
REQUIRED_DIRS=(
    "playbooks"
    "roles"
    "group_vars"
    "inventory"
    "library"
    "filter_plugins"
    "roles/cis_section_1"
    "roles/cis_section_2"
    "roles/cis_section_3"
    "roles/cis_section_4"
    "roles/cis_section_5"
)

for dir in "${REQUIRED_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        print_result 0 "Directory exists: $dir"
    else
        print_result 1 "Directory missing: $dir"
    fi
done
echo ""

echo "Test 2: Validate required files"
echo "--------------------------------------"
REQUIRED_FILES=(
    "playbooks/audit_l1.yml"
    "playbooks/audit_l2.yml"
    "playbooks/remediate_l1.yml"
    "playbooks/remediate_l2.yml"
    "playbooks/audit_and_remediate.yml"
    "group_vars/all.yml"
    "inventory/hosts.example"
    ".gitignore"
    "README.md"
    "requirements.yml"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        print_result 0 "File exists: $file"
    else
        print_result 1 "File missing: $file"
    fi
done
echo ""

echo "Test 3: Validate role structure"
echo "--------------------------------------"
for section in 1 2 3 4 5; do
    ROLE_DIR="roles/cis_section_${section}"
    
    # Check tasks directory
    if [ -d "${ROLE_DIR}/tasks" ]; then
        print_result 0 "Role ${section}: tasks directory exists"
    else
        print_result 1 "Role ${section}: tasks directory missing"
    fi
    
    # Check main.yml
    if [ -f "${ROLE_DIR}/tasks/main.yml" ]; then
        print_result 0 "Role ${section}: tasks/main.yml exists"
    else
        print_result 1 "Role ${section}: tasks/main.yml missing"
    fi
    
    # Check audit.yml
    if [ -f "${ROLE_DIR}/tasks/audit.yml" ]; then
        print_result 0 "Role ${section}: tasks/audit.yml exists"
    else
        print_result 1 "Role ${section}: tasks/audit.yml missing"
    fi
    
    # Check remediate.yml
    if [ -f "${ROLE_DIR}/tasks/remediate.yml" ]; then
        print_result 0 "Role ${section}: tasks/remediate.yml exists"
    else
        print_result 1 "Role ${section}: tasks/remediate.yml missing"
    fi
    
    # Check defaults
    if [ -d "${ROLE_DIR}/defaults" ]; then
        print_result 0 "Role ${section}: defaults directory exists"
    else
        print_result 1 "Role ${section}: defaults directory missing"
    fi
    
    # Check vars
    if [ -d "${ROLE_DIR}/vars" ]; then
        print_result 0 "Role ${section}: vars directory exists"
    else
        print_result 1 "Role ${section}: vars directory missing"
    fi
done
echo ""

echo "Test 4: Validate playbook syntax"
echo "--------------------------------------"
PLAYBOOKS=(
    "playbooks/audit_l1.yml"
    "playbooks/audit_l2.yml"
    "playbooks/remediate_l1.yml"
    "playbooks/remediate_l2.yml"
    "playbooks/audit_and_remediate.yml"
)

for playbook in "${PLAYBOOKS[@]}"; do
    if ansible-playbook --syntax-check "$playbook" 2>&1 | grep -q "playbook: $playbook"; then
        print_result 0 "Syntax valid: $playbook"
    else
        print_result 1 "Syntax error: $playbook"
    fi
done
echo ""

echo "Test 5: Validate tag consistency"
echo "--------------------------------------"
# Check that all playbooks have expected tags
EXPECTED_TAGS=("section1" "section2" "section3" "section4" "section5" "audit" "level1")

for playbook in "${PLAYBOOKS[@]}"; do
    TAGS_OUTPUT=$(ansible-playbook "$playbook" --list-tags 2>/dev/null | grep "TASK TAGS")
    
    for tag in "${EXPECTED_TAGS[@]}"; do
        if echo "$TAGS_OUTPUT" | grep -q "$tag"; then
            print_result 0 "Tag '$tag' found in $playbook"
        else
            print_result 1 "Tag '$tag' missing in $playbook"
        fi
    done
done
echo ""

echo "Test 6: Validate configuration files"
echo "--------------------------------------"
# Check group_vars/all.yml has required variables
REQUIRED_VARS=(
    "cis_mode"
    "cis_level"
    "openshift_cluster_name"
    "openshift_base_domain"
    "report_output_dir"
    "control_plane_group"
    "worker_node_group"
)

for var in "${REQUIRED_VARS[@]}"; do
    if grep -q "^${var}:" group_vars/all.yml; then
        print_result 0 "Variable defined: $var"
    else
        print_result 1 "Variable missing: $var"
    fi
done
echo ""

echo "Test 7: Validate .gitignore"
echo "--------------------------------------"
GITIGNORE_PATTERNS=(
    "*.retry"
    "inventory/hosts"
    "cis_reports/"
    "*.log"
)

for pattern in "${GITIGNORE_PATTERNS[@]}"; do
    if grep -q "$pattern" .gitignore; then
        print_result 0 "Pattern in .gitignore: $pattern"
    else
        print_result 1 "Pattern missing in .gitignore: $pattern"
    fi
done
echo ""

echo "Test 8: Validate filter plugins"
echo "--------------------------------------"
if [ -f "filter_plugins/cis_filters.py" ]; then
    print_result 0 "Custom filter plugin exists: cis_filters.py"
    
    # Check for required filter functions
    if grep -q "def cis_format_summary" filter_plugins/cis_filters.py; then
        print_result 0 "Filter function exists: cis_format_summary"
    else
        print_result 1 "Filter function missing: cis_format_summary"
    fi
    
    if grep -q "def cis_group_by_section" filter_plugins/cis_filters.py; then
        print_result 0 "Filter function exists: cis_group_by_section"
    else
        print_result 1 "Filter function missing: cis_group_by_section"
    fi
else
    print_result 1 "Custom filter plugin missing: cis_filters.py"
fi
echo ""

echo "Test 9: Validate inventory example"
echo "--------------------------------------"
if grep -q "\[masters\]" inventory/hosts.example; then
    print_result 0 "Inventory has masters group"
else
    print_result 1 "Inventory missing masters group"
fi

if grep -q "\[workers\]" inventory/hosts.example; then
    print_result 0 "Inventory has workers group"
else
    print_result 1 "Inventory missing workers group"
fi
echo ""

echo "Test 10: Validate role references in playbooks"
echo "--------------------------------------"
for section in 1 2 3 4 5; do
    for playbook in "${PLAYBOOKS[@]}"; do
        if grep -q "role: cis_section_${section}" "$playbook"; then
            print_result 0 "Playbook $(basename $playbook) references cis_section_${section}"
        else
            print_result 1 "Playbook $(basename $playbook) missing cis_section_${section}"
        fi
    done
done
echo ""

echo "=========================================="
echo "Validation Summary"
echo "=========================================="
echo -e "${GREEN}Tests Passed: ${TESTS_PASSED}${NC}"
echo -e "${RED}Tests Failed: ${TESTS_FAILED}${NC}"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}✓ All validation tests passed!${NC}"
    exit 0
else
    echo -e "${YELLOW}⚠ Some validation tests failed. Please review the output above.${NC}"
    exit 1
fi
