#!/usr/bin/env python3
"""
Custom Ansible filter plugins for CIS error handling and categorization
"""

import re
import json
from collections import defaultdict
from datetime import datetime

class FilterModule(object):
    """Custom filters for error handling"""

    def filters(self):
        return {
            'categorize_error': self.categorize_error,
            'count_errors_by_type': self.count_errors_by_type,
            'format_error_summary': self.format_error_summary,
            'check_failure_threshold': self.check_failure_threshold,
            'extract_error_details': self.extract_error_details,
            'get_section_errors': self.get_section_errors,
            'generate_error_report': self.generate_error_report,
            'get_error_recovery_suggestion': self.get_error_recovery_suggestion,
            'is_critical_error': self.is_critical_error,
            'format_error_for_report': self.format_error_for_report,
            'get_error_statistics': self.get_error_statistics
        }

    def categorize_error(self, error_msg, stderr=''):
        """
        Categorize error based on error message content
        
        Args:
            error_msg: Error message string
            stderr: Standard error output (optional)
            
        Returns:
            Error category string
        """
        error_text = (str(error_msg) + ' ' + str(stderr)).lower()
        
        # Timeout errors (check before connection errors as they can overlap)
        if any(keyword in error_text for keyword in [
            'timeout', 'timed out', 'deadline exceeded', 'context deadline'
        ]):
            return 'TIMEOUT_ERROR'
        
        # Connection errors
        if any(keyword in error_text for keyword in [
            'connection refused', 'connection timed out', 'unable to connect',
            'network unreachable', 'no route to host', 'connection reset',
            'could not resolve', 'name resolution failed',
            'dial tcp', 'i/o timeout', 'connection error'
        ]):
            return 'CONNECTION_ERROR'
        
        # Permission errors
        if any(keyword in error_text for keyword in [
            'permission denied', 'forbidden', 'unauthorized', 'access denied',
            'insufficient permissions', 'not authorized', 'authentication failed',
            'user cannot', 'is forbidden', 'error 403', 'error 401',
            'rbac', 'role binding'
        ]):
            return 'PERMISSION_ERROR'
        
        # Operator-managed configuration
        if any(keyword in error_text for keyword in [
            'operator-managed', 'operator managed', 'managed by operator',
            'degraded state', 'cluster operator', 'operator controls',
            'machine config operator', 'mco', 'cannot be modified'
        ]):
            return 'OPERATOR_MANAGED'
        
        # Configuration errors
        if any(keyword in error_text for keyword in [
            'invalid configuration', 'config error', 'configuration not found',
            'missing configuration', 'malformed', 'parse error', 'syntax error',
            'invalid yaml', 'invalid json', 'bad request', 'validation failed'
        ]):
            return 'CONFIGURATION_ERROR'
        
        # Resource not found
        if any(keyword in error_text for keyword in [
            'not found', 'does not exist', 'no such', 'error 404',
            'resource not found', 'notfound'
        ]):
            return 'RESOURCE_NOT_FOUND'
        
        # Not applicable
        if any(keyword in error_text for keyword in [
            'not applicable', 'n/a', 'not supported', 'not available',
            'not implemented', 'not relevant'
        ]):
            return 'NOT_APPLICABLE'
        
        return 'UNKNOWN_ERROR'

    def count_errors_by_type(self, results):
        """
        Count errors by type from results array
        
        Args:
            results: List of result dictionaries
            
        Returns:
            Dictionary with error counts by type
        """
        error_counts = {
            'CONNECTION_ERROR': 0,
            'PERMISSION_ERROR': 0,
            'OPERATOR_MANAGED': 0,
            'CONFIGURATION_ERROR': 0,
            'RESOURCE_NOT_FOUND': 0,
            'TIMEOUT_ERROR': 0,
            'NOT_APPLICABLE': 0,
            'UNKNOWN_ERROR': 0,
            'TOTAL_ERRORS': 0
        }
        
        for result in results:
            if isinstance(result, dict) and result.get('status') == 'ERROR':
                error_type = result.get('error_type', 'UNKNOWN_ERROR')
                if error_type in error_counts:
                    error_counts[error_type] += 1
                else:
                    error_counts['UNKNOWN_ERROR'] += 1
                error_counts['TOTAL_ERRORS'] += 1
        
        return error_counts

    def format_error_summary(self, results, section_name=''):
        """
        Format error summary for display
        
        Args:
            results: List of result dictionaries
            section_name: Name of the section (optional)
            
        Returns:
            Formatted error summary string
        """
        error_counts = self.count_errors_by_type(results)
        
        if error_counts['TOTAL_ERRORS'] == 0:
            return f"Section {section_name}: No errors encountered"
        
        summary_lines = [
            f"Section {section_name} Error Summary:",
            f"  Total Errors: {error_counts['TOTAL_ERRORS']}",
            f"  Connection Errors: {error_counts['CONNECTION_ERROR']}",
            f"  Permission Errors: {error_counts['PERMISSION_ERROR']}",
            f"  Timeout Errors: {error_counts['TIMEOUT_ERROR']}",
            f"  Operator-Managed: {error_counts['OPERATOR_MANAGED']}",
            f"  Configuration Errors: {error_counts['CONFIGURATION_ERROR']}",
            f"  Resource Not Found: {error_counts['RESOURCE_NOT_FOUND']}",
            f"  Not Applicable: {error_counts['NOT_APPLICABLE']}",
            f"  Unknown Errors: {error_counts['UNKNOWN_ERROR']}"
        ]
        
        return '\n'.join(summary_lines)

    def check_failure_threshold(self, results, threshold, section_name=''):
        """
        Check if failure count exceeds threshold
        
        Args:
            results: List of result dictionaries
            threshold: Maximum allowed failures (0 = no limit)
            section_name: Name of the section (optional)
            
        Returns:
            Dictionary with threshold check results
        """
        if threshold == 0:
            return {
                'exceeded': False,
                'message': 'No failure threshold configured'
            }
        
        error_count = sum(1 for r in results if isinstance(r, dict) and r.get('status') == 'ERROR')
        
        return {
            'exceeded': error_count >= threshold,
            'error_count': error_count,
            'threshold': threshold,
            'message': f"Section {section_name}: {error_count}/{threshold} failures" if error_count < threshold 
                      else f"Section {section_name}: Failure threshold exceeded ({error_count}/{threshold})"
        }

    def extract_error_details(self, error_result):
        """
        Extract detailed error information from a result
        
        Args:
            error_result: Error result dictionary
            
        Returns:
            Dictionary with extracted error details
        """
        if not isinstance(error_result, dict):
            return {}
        
        return {
            'control': error_result.get('control', 'unknown'),
            'title': error_result.get('title', 'Unknown control'),
            'error_type': error_result.get('error_type', 'UNKNOWN_ERROR'),
            'message': error_result.get('message', 'No error message'),
            'timestamp': error_result.get('timestamp', ''),
            'host': error_result.get('host', 'N/A')
        }

    def get_section_errors(self, results, section_number):
        """
        Get all errors for a specific section
        
        Args:
            results: List of result dictionaries
            section_number: Section number (e.g., '1', '2', '3')
            
        Returns:
            List of error results for the section
        """
        section_pattern = f"^{section_number}\\."
        section_errors = []
        
        for result in results:
            if isinstance(result, dict) and result.get('status') == 'ERROR':
                control = result.get('control', '')
                if re.match(section_pattern, str(control)):
                    section_errors.append(result)
        
        return section_errors

    def generate_error_report(self, results):
        """
        Generate comprehensive error report
        
        Args:
            results: List of result dictionaries
            
        Returns:
            Dictionary with comprehensive error report
        """
        error_report = {
            'total_errors': 0,
            'errors_by_type': defaultdict(int),
            'errors_by_section': defaultdict(list),
            'critical_errors': [],
            'summary': ''
        }
        
        for result in results:
            if isinstance(result, dict) and result.get('status') == 'ERROR':
                error_report['total_errors'] += 1
                
                # Count by type
                error_type = result.get('error_type', 'UNKNOWN_ERROR')
                error_report['errors_by_type'][error_type] += 1
                
                # Group by section
                control = result.get('control', 'unknown')
                section = control.split('.')[0] if '.' in control else 'unknown'
                error_report['errors_by_section'][f"section_{section}"].append({
                    'control': control,
                    'title': result.get('title', ''),
                    'error_type': error_type,
                    'message': result.get('message', '')
                })
                
                # Identify critical errors (connection/permission)
                if error_type in ['CONNECTION_ERROR', 'PERMISSION_ERROR']:
                    error_report['critical_errors'].append({
                        'control': control,
                        'error_type': error_type,
                        'message': result.get('message', '')
                    })
        
        # Generate summary
        if error_report['total_errors'] == 0:
            error_report['summary'] = "No errors encountered during execution"
        else:
            summary_lines = [
                f"Total Errors: {error_report['total_errors']}",
                f"Critical Errors: {len(error_report['critical_errors'])}",
                "Errors by Type:"
            ]
            for error_type, count in sorted(error_report['errors_by_type'].items()):
                summary_lines.append(f"  - {error_type}: {count}")
            
            error_report['summary'] = '\n'.join(summary_lines)
        
        # Convert defaultdict to regular dict for JSON serialization
        error_report['errors_by_type'] = dict(error_report['errors_by_type'])
        error_report['errors_by_section'] = dict(error_report['errors_by_section'])
        
        return error_report

    def get_error_recovery_suggestion(self, error_type):
        """
        Get recovery suggestions for a specific error type
        
        Args:
            error_type: Error type string
            
        Returns:
            List of recovery suggestions
        """
        suggestions = {
            'CONNECTION_ERROR': [
                'Verify OpenShift cluster is accessible',
                'Check network connectivity to the cluster',
                'Verify kubeconfig is valid and not expired',
                'Ensure oc CLI is properly configured',
                'Check if cluster API endpoint is reachable',
                'Verify firewall rules allow access to cluster'
            ],
            'PERMISSION_ERROR': [
                'Verify service account has required permissions',
                'Check RBAC role bindings',
                'Ensure cluster-admin or appropriate role is assigned',
                'Review audit logs for permission denials',
                'Verify authentication token is valid',
                'Check if user/service account exists'
            ],
            'OPERATOR_MANAGED': [
                'This configuration is managed by OpenShift operators',
                'Manual changes may cause cluster degradation',
                'Use operator CRDs for configuration changes',
                'Refer to OpenShift documentation for proper configuration',
                'Consider using MachineConfig for node-level changes',
                'Review operator status with: oc get co'
            ],
            'CONFIGURATION_ERROR': [
                'Verify configuration syntax',
                'Check for missing required fields',
                'Ensure OpenShift version compatibility',
                'Review configuration documentation',
                'Validate YAML/JSON formatting',
                'Check for typos in resource names'
            ],
            'RESOURCE_NOT_FOUND': [
                'Verify the resource exists in the cluster',
                'Check the namespace/project name',
                'Ensure resource name is spelled correctly',
                'Verify resource has been created',
                'Check if resource was deleted',
                'Review resource creation logs'
            ],
            'TIMEOUT_ERROR': [
                'Increase timeout value in configuration',
                'Check cluster performance and load',
                'Verify network latency is acceptable',
                'Review cluster resource utilization',
                'Check if operation is long-running',
                'Consider running during off-peak hours'
            ],
            'NOT_APPLICABLE': [
                'This control may not apply to your OpenShift version',
                'Review CIS Benchmark version compatibility',
                'Check if feature is enabled in your cluster',
                'Verify cluster configuration matches benchmark assumptions',
                'Consult OpenShift documentation for alternatives'
            ],
            'UNKNOWN_ERROR': [
                'Review error message for specific details',
                'Check Ansible verbose output (-vvv)',
                'Consult CIS Benchmark documentation',
                'Review OpenShift logs for additional context',
                'Check recent cluster changes or updates',
                'Search OpenShift knowledge base for similar issues'
            ]
        }
        
        return suggestions.get(error_type, suggestions['UNKNOWN_ERROR'])

    def is_critical_error(self, error_type):
        """
        Determine if an error type is critical
        
        Args:
            error_type: Error type string
            
        Returns:
            Boolean indicating if error is critical
        """
        critical_errors = [
            'CONNECTION_ERROR',
            'PERMISSION_ERROR',
            'TIMEOUT_ERROR'
        ]
        
        return error_type in critical_errors

    def format_error_for_report(self, error_result):
        """
        Format error result for inclusion in final report
        
        Args:
            error_result: Error result dictionary
            
        Returns:
            Formatted error dictionary for report
        """
        if not isinstance(error_result, dict):
            return {}
        
        return {
            'control': error_result.get('control', 'unknown'),
            'title': error_result.get('title', 'Unknown control'),
            'level': error_result.get('level', 'L1'),
            'status': 'ERROR',
            'error_type': error_result.get('error_type', 'UNKNOWN_ERROR'),
            'is_critical': self.is_critical_error(error_result.get('error_type', 'UNKNOWN_ERROR')),
            'message': error_result.get('message', 'No error message'),
            'expected': error_result.get('expected', 'N/A'),
            'actual': 'N/A',
            'timestamp': error_result.get('timestamp', ''),
            'host': error_result.get('host', 'N/A'),
            'recovery_suggestions': self.get_error_recovery_suggestion(
                error_result.get('error_type', 'UNKNOWN_ERROR')
            ) if error_result.get('include_suggestions', False) else []
        }

    def get_error_statistics(self, results):
        """
        Get comprehensive error statistics
        
        Args:
            results: List of result dictionaries
            
        Returns:
            Dictionary with detailed error statistics
        """
        stats = {
            'total_controls': len(results),
            'total_errors': 0,
            'critical_errors': 0,
            'errors_by_type': defaultdict(int),
            'errors_by_level': {'L1': 0, 'L2': 0},
            'errors_by_section': defaultdict(int),
            'error_rate': 0.0,
            'most_common_error_type': None,
            'sections_with_errors': []
        }
        
        sections_set = set()
        
        for result in results:
            if isinstance(result, dict) and result.get('status') == 'ERROR':
                stats['total_errors'] += 1
                
                # Count by type
                error_type = result.get('error_type', 'UNKNOWN_ERROR')
                stats['errors_by_type'][error_type] += 1
                
                # Count critical errors
                if self.is_critical_error(error_type):
                    stats['critical_errors'] += 1
                
                # Count by level
                level = result.get('level', 'L1')
                if level in stats['errors_by_level']:
                    stats['errors_by_level'][level] += 1
                
                # Count by section
                control = result.get('control', 'unknown')
                section = control.split('.')[0] if '.' in control else 'unknown'
                stats['errors_by_section'][f"section_{section}"] += 1
                sections_set.add(section)
        
        # Calculate error rate
        if stats['total_controls'] > 0:
            stats['error_rate'] = round(
                (stats['total_errors'] / stats['total_controls']) * 100, 2
            )
        
        # Find most common error type
        if stats['errors_by_type']:
            stats['most_common_error_type'] = max(
                stats['errors_by_type'].items(),
                key=lambda x: x[1]
            )[0]
        
        # Convert sets and defaultdicts to regular types for JSON serialization
        stats['errors_by_type'] = dict(stats['errors_by_type'])
        stats['errors_by_section'] = dict(stats['errors_by_section'])
        stats['sections_with_errors'] = sorted(list(sections_set))
        
        return stats
