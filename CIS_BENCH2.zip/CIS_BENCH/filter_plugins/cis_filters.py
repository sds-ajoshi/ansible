#!/usr/bin/env python3
"""
Custom Jinja2 filters for CIS OpenShift Ansible Automation
Provides formatting and aggregation functions for audit results
"""

from typing import List, Dict, Any


class FilterModule:
    """Ansible filter plugin for CIS audit result processing"""

    def filters(self):
        """Return dictionary of available filters"""
        return {
            'cis_format_summary': self.format_summary,
            'cis_group_by_section': self.group_by_section,
            'cis_calculate_compliance_percentage': self.calculate_compliance_percentage,
            'cis_filter_by_status': self.filter_by_status,
            'cis_filter_by_level': self.filter_by_level,
            'cis_format_control_id': self.format_control_id,
        }

    def format_summary(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate summary statistics from audit results
        
        Args:
            results: List of audit result dictionaries
            
        Returns:
            Dictionary with summary statistics
        """
        if not results:
            return {
                'total': 0,
                'passed': 0,
                'failed': 0,
                'manual': 0,
                'errors': 0,
                'compliance_percentage': 0.0
            }
        
        total = len(results)
        passed = sum(1 for r in results if r.get('status') == 'PASS')
        failed = sum(1 for r in results if r.get('status') == 'FAIL')
        manual = sum(1 for r in results if r.get('status') == 'MANUAL')
        errors = sum(1 for r in results if r.get('status') == 'ERROR')
        
        # Calculate compliance percentage (passed / (total - manual - errors))
        testable = total - manual - errors
        compliance_percentage = (passed / testable * 100) if testable > 0 else 0.0
        
        return {
            'total': total,
            'passed': passed,
            'failed': failed,
            'manual': manual,
            'errors': errors,
            'compliance_percentage': round(compliance_percentage, 2)
        }

    def group_by_section(self, results: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Group audit results by CIS section
        
        Args:
            results: List of audit result dictionaries
            
        Returns:
            Dictionary with section numbers as keys and lists of results as values
        """
        grouped = {}
        
        for result in results:
            control = result.get('control', '')
            # Extract section number (e.g., "1.1.1" -> "1")
            section = control.split('.')[0] if control else 'unknown'
            
            if section not in grouped:
                grouped[section] = []
            
            grouped[section].append(result)
        
        return grouped

    def calculate_compliance_percentage(self, results: List[Dict[str, Any]]) -> float:
        """
        Calculate compliance percentage from audit results
        
        Args:
            results: List of audit result dictionaries
            
        Returns:
            Compliance percentage (0-100)
        """
        if not results:
            return 0.0
        
        passed = sum(1 for r in results if r.get('status') == 'PASS')
        manual = sum(1 for r in results if r.get('status') == 'MANUAL')
        errors = sum(1 for r in results if r.get('status') == 'ERROR')
        
        testable = len(results) - manual - errors
        
        if testable <= 0:
            return 0.0
        
        return round((passed / testable) * 100, 2)

    def filter_by_status(self, results: List[Dict[str, Any]], status: str) -> List[Dict[str, Any]]:
        """
        Filter audit results by status
        
        Args:
            results: List of audit result dictionaries
            status: Status to filter by (PASS, FAIL, MANUAL, ERROR)
            
        Returns:
            Filtered list of results
        """
        return [r for r in results if r.get('status') == status.upper()]

    def filter_by_level(self, results: List[Dict[str, Any]], level: str) -> List[Dict[str, Any]]:
        """
        Filter audit results by CIS level
        
        Args:
            results: List of audit result dictionaries
            level: Level to filter by (L1, L2)
            
        Returns:
            Filtered list of results
        """
        return [r for r in results if r.get('level') == level.upper()]

    def format_control_id(self, control: str) -> str:
        """
        Format control ID for display
        
        Args:
            control: Control ID (e.g., "1.1.1")
            
        Returns:
            Formatted control ID (e.g., "CIS 1.1.1")
        """
        return f"CIS {control}" if control else "Unknown"
