# CIS Audit Result Filters

This directory contains custom Jinja2 filters for processing and formatting CIS audit results in Ansible playbooks.

## Available Filters

### cis_format_summary

Generates summary statistics from audit results.

**Usage:**
```yaml
- name: Generate audit summary
  set_fact:
    audit_summary: "{{ cis_results | cis_format_summary }}"
```

**Returns:**
```yaml
{
  'total': 100,
  'passed': 75,
  'failed': 15,
  'manual': 8,
  'errors': 2,
  'compliance_percentage': 83.33
}
```

### cis_group_by_section

Groups audit results by CIS section number.

**Usage:**
```yaml
- name: Group results by section
  set_fact:
    results_by_section: "{{ cis_results | cis_group_by_section }}"
```

**Returns:**
```yaml
{
  '1': [list of section 1 results],
  '2': [list of section 2 results],
  '3': [list of section 3 results],
  ...
}
```

### cis_calculate_compliance_percentage

Calculates compliance percentage from audit results.

**Usage:**
```yaml
- name: Calculate compliance
  set_fact:
    compliance: "{{ cis_results | cis_calculate_compliance_percentage }}"
```

**Returns:** Float value between 0-100

### cis_filter_by_status

Filters audit results by status (PASS, FAIL, MANUAL, ERROR).

**Usage:**
```yaml
- name: Get failed controls
  set_fact:
    failed_controls: "{{ cis_results | cis_filter_by_status('FAIL') }}"
```

**Returns:** List of results matching the specified status

### cis_filter_by_level

Filters audit results by CIS level (L1, L2).

**Usage:**
```yaml
- name: Get Level 1 controls
  set_fact:
    l1_controls: "{{ cis_results | cis_filter_by_level('L1') }}"
```

**Returns:** List of results matching the specified level

### cis_format_control_id

Formats a control ID for display.

**Usage:**
```yaml
- name: Format control ID
  debug:
    msg: "{{ '1.1.1' | cis_format_control_id }}"
```

**Returns:** "CIS 1.1.1"

## Report Structure

The playbooks generate comprehensive reports with the following structure:

### JSON Report Format

```json
{
  "execution_timestamp": "2025-11-14T10:30:00Z",
  "openshift_version": "4.15.2",
  "cis_benchmark_version": "1.8.0",
  "level": "L1",
  "mode": "audit",
  "summary": {
    "total": 100,
    "passed": 75,
    "failed": 15,
    "manual": 8,
    "errors": 2,
    "compliance_percentage": 83.33
  },
  "results_by_section": {
    "1": {
      "total": 35,
      "passed": 30,
      "failed": 3,
      "manual": 2,
      "errors": 0
    },
    "2": {
      "total": 7,
      "passed": 7,
      "failed": 0,
      "manual": 0,
      "errors": 0
    }
  },
  "detailed_results": [
    {
      "control": "1.1.1",
      "title": "Ensure that the API server pod specification file permissions are set to 600 or more restrictive",
      "level": "L1",
      "status": "PASS",
      "message": "File permissions are compliant",
      "expected": "600",
      "actual": "600",
      "timestamp": "2025-11-14T10:30:15Z",
      "host": "master-0.example.com"
    }
  ]
}
```

### YAML Report Format

The YAML format contains the same structure as JSON but in YAML syntax for better human readability.

## Report Locations

Reports are saved to the directory specified by the `report_output_dir` variable (default: `./cis_reports`).

Report filenames include timestamps for easy identification:
- Audit reports: `cis_audit_l1_<timestamp>.json` or `cis_audit_l2_<timestamp>.json`
- Remediation reports: `cis_remediate_l1_<timestamp>.json` or `cis_remediate_l2_<timestamp>.json`
- Combined reports: `cis_audit_remediate_l1_<timestamp>.json` or `cis_audit_remediate_l2_<timestamp>.json`

## Configuration Variables

Control report generation with these variables:

```yaml
# Report output directory
report_output_dir: "./cis_reports"

# Report format (json or yaml)
report_format: "json"

# Include detailed results in report
report_include_details: true

# Include timestamp in report filename
report_timestamp_enabled: true
```

## Examples

### Generate audit report with custom output directory

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  -e report_output_dir=/var/log/cis_reports
```

### Generate YAML format report

```bash
ansible-playbook -i inventory/hosts playbooks/audit_l1.yml \
  -e report_format=yaml
```

### View compliance percentage in playbook

```yaml
- name: Calculate and display compliance
  debug:
    msg: "Compliance: {{ cis_results | cis_calculate_compliance_percentage }}%"
```

### Filter and display only failed controls

```yaml
- name: Display failed controls
  debug:
    msg: "Control {{ item.control }}: {{ item.title }} - {{ item.message }}"
  loop: "{{ cis_results | cis_filter_by_status('FAIL') }}"
```
