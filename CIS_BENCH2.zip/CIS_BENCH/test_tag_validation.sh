#!/bin/bash
# Test script to validate tag filtering works correctly

echo "=========================================="
echo "Testing Tag Filtering"
echo "=========================================="

# Test 1: List tags for audit_l1.yml
echo ""
echo "Test 1: Listing all tags in audit_l1.yml"
ansible-playbook playbooks/audit_l1.yml --list-tags 2>/dev/null | grep -A 100 "play #1"

# Test 2: List tags for audit_l2.yml
echo ""
echo "Test 2: Listing all tags in audit_l2.yml"
ansible-playbook playbooks/audit_l2.yml --list-tags 2>/dev/null | grep -A 100 "play #1"

# Test 3: List tags for remediate_l1.yml
echo ""
echo "Test 3: Listing all tags in remediate_l1.yml"
ansible-playbook playbooks/remediate_l1.yml --list-tags 2>/dev/null | grep -A 100 "play #1"

# Test 4: List tags for audit_and_remediate.yml
echo ""
echo "Test 4: Listing all tags in audit_and_remediate.yml"
ansible-playbook playbooks/audit_and_remediate.yml --list-tags 2>/dev/null | grep -A 100 "play #1"

echo ""
echo "=========================================="
echo "Tag validation complete"
echo "=========================================="
