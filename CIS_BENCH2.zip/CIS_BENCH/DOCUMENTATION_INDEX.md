# Documentation Index

Complete index of all documentation for the CIS OpenShift Ansible Automation suite.

## Quick Start

New to the project? Start here:
1. [README.md](README.md) - Main documentation with installation and usage
2. [FAQ.md](FAQ.md) - Common questions and answers
3. [Quick Start Guide](#quick-start-guide) - Get running in 5 minutes

## Main Documentation

### [README.md](README.md)
Main project documentation covering:
- Overview and features
- Prerequisites and installation
- Quick start guide
- Usage examples (basic, tag-based, advanced)
- Configuration variables
- Troubleshooting
- Important notes about operator-managed configurations
- Version compatibility

### [FAQ.md](FAQ.md)
Frequently asked questions including:
- General questions about the automation
- Execution and usage questions
- Operator-managed configuration explanations
- Permission and access requirements
- Reporting and results interpretation
- Troubleshooting common issues
- Configuration and customization
- Remediation guidance
- Best practices

### [CONTRIBUTING.md](CONTRIBUTING.md)
Guidelines for contributors covering:
- How to contribute
- Development guidelines
- Task naming conventions
- Inline comment structure
- Error handling patterns
- Tagging strategy
- Variable naming conventions
- Testing requirements
- Pull request process

## Specialized Guides

### [ERROR_HANDLING.md](ERROR_HANDLING.md)
Comprehensive error handling documentation:
- Error categorization and types
- Error handling patterns
- Recovery strategies
- Section-level error tracking
- Error reporting

### [REPORTING.md](REPORTING.md)
Report generation and interpretation:
- Report formats (JSON, YAML, HTML)
- Report structure and fields
- Interpreting results
- Integration with compliance tools
- Custom report generation

### [RBAC Examples](rbac-examples/README.md)
RBAC configuration examples:
- ClusterRole definitions for audit and remediation
- ServiceAccount setup
- Permission requirements
- Installation instructions
- Customization options
- Troubleshooting RBAC issues

## Role-Specific Documentation

Each CIS section has dedicated documentation:

### [Section 1: Control Plane Components](roles/cis_section_1/README.md)
- Master node configuration files
- API Server configuration
- Controller Manager configuration
- Scheduler configuration
- Controls 1.1.1 through 1.4.2

### [Section 2: etcd](roles/cis_section_2/README.md)
- etcd security configuration
- Certificate and TLS settings
- Data directory permissions
- Controls 2.1 through 2.7

### [Section 3: Control Plane Configuration](roles/cis_section_3/README.md)
- Authentication and authorization
- Audit logging configuration
- Identity provider setup
- Controls 3.1.1 through 3.2.2

### [Section 4: Worker Nodes](roles/cis_section_4/README.md)
- Worker node configuration files
- Kubelet configuration and security
- TLS and certificate management
- Controls 4.1.1 through 4.2.13

### [Section 5: Policies](roles/cis_section_5/README.md)
- RBAC and service accounts
- Security Context Constraints (SCCs)
- Network policies
- Secrets management
- Admission control
- General policies
- Controls 5.1.1 through 5.7.4

## Configuration Documentation

### [group_vars/all.yml](group_vars/all.yml)
Comprehensive variable documentation with:
- CIS execution configuration
- OpenShift cluster connection settings
- Audit configuration
- Remediation configuration
- Reporting configuration
- Error handling configuration
- Node targeting
- Version-specific settings
- Advanced configuration options

### [inventory/hosts.example](inventory/hosts.example)
Example inventory file showing:
- Control plane node group
- Worker node group
- Connection settings

## Additional Documentation

### [filter_plugins/README.md](filter_plugins/README.md)
Custom Jinja2 filters for:
- CIS result formatting
- Report generation
- Data transformation

## Quick Reference

### Common Tasks

| Task | Command | Documentation |
|------|---------|---------------|
| Run L1 audit | `ansible-playbook -i inventory/hosts playbooks/audit_l1.yml` | [README.md](README.md#quick-start) |
| Run L2 audit | `ansible-playbook -i inventory/hosts playbooks/audit_l2.yml` | [README.md](README.md#quick-start) |
| Dry-run remediation | `ansible-playbook -i inventory/hosts playbooks/remediate_l1.yml -e remediation_dry_run=true` | [README.md](README.md#usage-examples) |
| Run specific section | `ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags section1` | [README.md](README.md#tag-based-filtering) |
| Run specific control | `ansible-playbook -i inventory/hosts playbooks/audit_l1.yml --tags control_1.1.1` | [README.md](README.md#tag-based-filtering) |

### Troubleshooting Quick Links

| Issue | Solution | Documentation |
|-------|----------|---------------|
| Permission denied | Check RBAC permissions | [README.md](README.md#permission-errors), [FAQ.md](FAQ.md#permission-and-access-questions) |
| Cannot access nodes | Verify oc debug access | [README.md](README.md#node-access-issues), [FAQ.md](FAQ.md#why-cant-i-access-nodes-with-oc-debug) |
| Operator-managed settings | Understand operator management | [README.md](README.md#operator-managed-configurations), [FAQ.md](FAQ.md#operator-managed-configuration-questions) |
| Slow execution | Optimize performance | [README.md](README.md#slow-execution), [FAQ.md](FAQ.md#how-long-does-a-full-audit-take) |
| Empty reports | Check configuration | [README.md](README.md#report-generation-issues), [FAQ.md](FAQ.md#reports-are-empty-or-missing) |

## Documentation by Audience

### For Security Engineers
- [README.md](README.md) - Overview and usage
- [FAQ.md](FAQ.md) - Common questions
- [Section-specific READMEs](roles/) - Control details
- [REPORTING.md](REPORTING.md) - Report interpretation

### For DevOps Engineers
- [README.md](README.md) - Installation and execution
- [FAQ.md](FAQ.md) - Troubleshooting
- [group_vars/all.yml](group_vars/all.yml) - Configuration
- [ERROR_HANDLING.md](ERROR_HANDLING.md) - Error management

### For Compliance Officers
- [README.md](README.md) - Capabilities overview
- [REPORTING.md](REPORTING.md) - Report formats
- [Section-specific READMEs](roles/) - Control coverage
- [FAQ.md](FAQ.md) - Compliance questions

### For Developers/Contributors
- [CONTRIBUTING.md](CONTRIBUTING.md) - Development guidelines
- [README.md](README.md) - Project structure
- [Section-specific READMEs](roles/) - Implementation details
- [ERROR_HANDLING.md](ERROR_HANDLING.md) - Error patterns

## External References

### CIS Benchmark
- [CIS Red Hat OpenShift Container Platform Benchmark v1.8.0](https://www.cisecurity.org/benchmark/kubernetes)

### OpenShift Documentation
- [OpenShift Security Documentation](https://docs.openshift.com/container-platform/latest/security/)
- [OpenShift RBAC](https://docs.openshift.com/container-platform/latest/authentication/using-rbac.html)
- [OpenShift Operators Reference](https://docs.openshift.com/container-platform/latest/operators/operator-reference.html)
- [OpenShift Audit Logging](https://docs.openshift.com/container-platform/latest/security/audit-log-policy-config.html)

### Ansible Documentation
- [Ansible Documentation](https://docs.ansible.com/)
- [kubernetes.core Collection](https://docs.ansible.com/ansible/latest/collections/kubernetes/core/)
- [community.general Collection](https://docs.ansible.com/ansible/latest/collections/community/general/)

## Getting Help

1. **Check Documentation**: Start with [README.md](README.md) and [FAQ.md](FAQ.md)
2. **Search Issues**: Look for similar issues in the repository
3. **Open Issue**: Create a new issue with details
4. **Community**: Engage with the OpenShift community

## Documentation Updates

This documentation is maintained alongside the code. When contributing:
- Update relevant documentation for code changes
- Add new sections to role READMEs for new controls
- Update FAQ for common questions
- Follow guidelines in [CONTRIBUTING.md](CONTRIBUTING.md)

Last Updated: 2025-11-14
