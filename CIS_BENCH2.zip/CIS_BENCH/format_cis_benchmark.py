#!/usr/bin/env python3
"""
Script to format CIS Red Hat OpenShift Container Platform Benchmark markdown file.
Handles common formatting issues from PDF-to-markdown conversions.
"""

import re
import sys
from pathlib import Path


def remove_page_breaks(text):
    """Remove page break markers."""
    # Remove "Page X Internal Only - General" lines
    text = re.sub(r'^Page \d+ Internal Only - General\s*$', '', text, flags=re.MULTILINE)
    return text


def fix_headers(text):
    """Convert section numbers to proper markdown headers."""
    lines = text.split('\n')
    formatted_lines = []
    
    for line in lines:
        # Match section headers like "1.1.1 Ensure that..." or "1 Control Plane Components"
        # Level 1: "1 Title" -> "# 1 Title"
        if re.match(r'^\d+\s+[A-Z]', line) and not re.match(r'^\d+\.\d+', line):
            formatted_lines.append(f"# {line}")
        # Level 2: "1.1 Title" -> "## 1.1 Title"
        elif re.match(r'^\d+\.\d+\s+[A-Z]', line) and not re.match(r'^\d+\.\d+\.\d+', line):
            formatted_lines.append(f"## {line}")
        # Level 3: "1.1.1 Title" -> "### 1.1.1 Title"
        elif re.match(r'^\d+\.\d+\.\d+\s+', line):
            formatted_lines.append(f"### {line}")
        else:
            formatted_lines.append(line)
    
    return '\n'.join(formatted_lines)


def format_code_blocks(text):
    """Wrap shell commands in proper code blocks."""
    lines = text.split('\n')
    formatted_lines = []
    in_code_block = False
    
    for i, line in enumerate(lines):
        # Detect command patterns
        is_command = (
            line.strip().startswith('oc ') or
            line.strip().startswith('for i in') or
            line.strip().startswith('do ') or
            line.strip().startswith('done') or
            line.strip().startswith('kubectl ') or
            (line.strip().startswith('stat ') and 'EOF' not in line)
        )
        
        # Start code block
        if is_command and not in_code_block:
            formatted_lines.append('```bash')
            formatted_lines.append(line)
            in_code_block = True
        # Continue code block
        elif in_code_block and (is_command or line.strip() == ''):
            formatted_lines.append(line)
        # End code block
        elif in_code_block and not is_command:
            formatted_lines.append('```')
            formatted_lines.append(line)
            in_code_block = False
        else:
            formatted_lines.append(line)
    
    # Close any open code block
    if in_code_block:
        formatted_lines.append('```')
    
    return '\n'.join(formatted_lines)


def format_sections(text):
    """Add proper spacing and formatting to standard sections."""
    # Bold section labels
    section_labels = [
        'Profile Applicability:',
        'Description:',
        'Rationale:',
        'Impact:',
        'Audit:',
        'Remediation:',
        'Default Value:',
        'References:',
        'CIS Controls:',
        'MITRE ATT&CK Mappings:'
    ]
    
    for label in section_labels:
        text = re.sub(
            rf'^({re.escape(label)})',
            rf'**\1**',
            text,
            flags=re.MULTILINE
        )
    
    return text


def clean_whitespace(text):
    """Clean up excessive whitespace."""
    # Remove multiple blank lines (keep max 2)
    text = re.sub(r'\n{4,}', '\n\n\n', text)
    # Remove trailing whitespace
    text = re.sub(r'[ \t]+$', '', text, flags=re.MULTILINE)
    return text


def wrap_long_lines(text, max_length=100):
    """Wrap long lines that aren't in code blocks or headers."""
    lines = text.split('\n')
    formatted_lines = []
    in_code_block = False
    
    for line in lines:
        # Track code blocks
        if line.strip().startswith('```'):
            in_code_block = not in_code_block
            formatted_lines.append(line)
            continue
        
        # Don't wrap headers, code blocks, or short lines
        if (in_code_block or 
            line.startswith('#') or 
            len(line) <= max_length or
            line.strip().startswith('http')):
            formatted_lines.append(line)
            continue
        
        # Wrap long lines
        words = line.split()
        current_line = []
        current_length = 0
        
        for word in words:
            word_length = len(word) + 1  # +1 for space
            if current_length + word_length > max_length and current_line:
                formatted_lines.append(' '.join(current_line))
                current_line = [word]
                current_length = word_length
            else:
                current_line.append(word)
                current_length += word_length
        
        if current_line:
            formatted_lines.append(' '.join(current_line))
    
    return '\n'.join(formatted_lines)


def format_benchmark(input_file, output_file=None):
    """Main formatting function."""
    print(f"Reading {input_file}...")
    
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    print("Applying formatting...")
    
    # Apply transformations in order
    content = remove_page_breaks(content)
    content = fix_headers(content)
    content = format_sections(content)
    content = format_code_blocks(content)
    content = clean_whitespace(content)
    content = wrap_long_lines(content)
    
    # Determine output file
    if output_file is None:
        input_path = Path(input_file)
        output_file = input_path.parent / f"{input_path.stem}_formatted{input_path.suffix}"
    
    print(f"Writing to {output_file}...")
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("Done!")
    return output_file


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python format_cis_benchmark.py <input_file> [output_file]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    format_benchmark(input_file, output_file)
